<table width="100%" cellspacing="0" cellpadding="0" style="background:url(images/logo_banner.png) no-repeat right top;">
	<tr>
		<td>
			<table width="100%" cellspacing="0" cellpadding="0">
				<tr>
					<td width="30%" align="left" valign="middle">
						<img src="images/logo.png?x=<?php echo uniqid((double)microtime()*1000000, 0); ?>" border="0" alt="" title="" />
					</td>
					<td align="center" valign="middle">
					</td>
					<td width="30%" align="right" valign="bottom">
						<p><font color="#ffffff"><span id="date_time" style="display:none;"></font></span></p>
					</td>
				</tr>
			</table>
		</td>
	<tr>
	<tr height="5" bgcolor="#333333">
		<td></td>
	</tr>	
</table>
<script>
	date_time('date_time');
</script>