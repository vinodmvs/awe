<?php
	require("elms_top_includes.php");
?>

<?php
	$varTotalCount = 0;
	$varRowSize = 10;
	$varStartLimit = 0;
	$varShowPreNav = "No";
	$varDisablePreNav = "Yes";
	$varShowNextNav = "No";
	$varDisableNextNav = "Yes";
	$varDisplayRowSizeText = "";
	$varCurPage = 1;
	$varPaginationStyle = "PRENEXTDDL"; //"PAGELINK" OR "PRENEXT" OR "PRENEXTDDL"
	
	$varSearchKeyWord = "";
	
	$strMessage = "";
	$intTempNum = 0;	
	
	if (isset($_POST["ddRowSize"])) {
		$varRowSize = $_POST["ddRowSize"];
	}
	
	if (isset($_POST["txtCurPage"])) {
		$varCurPage = $_POST["txtCurPage"];
	}
	
	if (isset($_POST["txtSearchWord"])) {
		$varSearchKeyWord = trim($_POST["txtSearchWord"]);
		$varSearchKeyWord = str_replace("'", "\\'", $varSearchKeyWord);
	}	
	
	if ($varSearchKeyWord=="") {
		$tempQuery = "SELECT * FROM elms_category_details ORDER BY category_id";
	} else {
		$tempQuery = "SELECT * FROM elms_category_details WHERE () ORDER BY category_id";
		$varTempSQL = "";
		$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
		for ($i=0; $i<count($varTempKwyWordArray); $i++) {
			if ($i==0) {
				$varTempSQL = "category_name LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			} else {
				$varTempSQL = $varTempSQL . " OR category_name LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			}
		}
		$varTempSQL = "(" . $varTempSQL . ")";
		$tempQuery = str_replace("()", $varTempSQL, $tempQuery);			
	}
	$tCountResult = mysql_query($tempQuery) or die (mysql_error());	
	$varTotalCount = dbNumRows($tCountResult);
	
	if ($varRowSize=="0") {
		$varRowSize = $varTotalCount;
	}	

	if (isset($_POST["txtAction"])) {
		if (isset($_POST["txtStartLimit"])) {
			$varStartLimit = $_POST["txtStartLimit"];
		}
		switch ($_POST["txtAction"]) {
			case "NEXT":
				$varStartLimit = $varStartLimit + $varRowSize;
				break;
			case "LAST":
				$varTempVal = $varTotalCount/$varRowSize;
				$varTempArr = explode(".", $varTempVal);
				$varTempFinalVal = ($varTempArr[0]*$varRowSize);
				if (count($varTempArr)==2) {
					$varStartLimit = $varTempFinalVal;
				} else {
					$varStartLimit = $varTempFinalVal - $varRowSize;
				}
				break;				
			case "PREVIOUS":
				$varStartLimit = $varStartLimit - $varRowSize;
				break;
			case "FIRST":
				$varStartLimit = 0;
				break;			
				
		}
	}	
	
	if ($varSearchKeyWord=="") {
		$tempQuery = "SELECT * FROM elms_category_details ORDER BY category_id LIMIT " . $varStartLimit . ", " . $varRowSize;
	} else {
		$tempQuery = "SELECT * FROM elms_category_details WHERE () ORDER BY category_id LIMIT " . $varStartLimit . ", " . $varRowSize;
		$varTempSQL = "";
		$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
		for ($i=0; $i<count($varTempKwyWordArray); $i++) {
			if ($i==0) {
				$varTempSQL = "category_name LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			} else {
				$varTempSQL = $varTempSQL . " OR category_name LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			}
		}
		$varTempSQL = "(" . $varTempSQL . ")";
		$tempQuery = str_replace("()", $varTempSQL, $tempQuery);
	}
	$categoryResult = mysql_query($tempQuery) or die (mysql_error());
	if (dbNumRows($categoryResult)<=0) {
		$strMessage =  "No course category(s) available.";
	} else {
		$intTempNum = dbNumRows($categoryResult);
		if ($varStartLimit<=0) {
			$varShowPreNav = "No";
			$varDisablePreNav = "Yes";	
		} else {
			$varShowPreNav = "Yes";
			$varDisablePreNav = "No";	
		}		
		
		if ($intTempNum<$varRowSize || ($varStartLimit + $varRowSize)>=$varTotalCount) {
			$varShowNextNav = "No";
			$varDisableNextNav = "Yes";		
		} else {
			$varShowNextNav = "Yes";
			$varDisableNextNav = "No";		
		}		
		$strMessage = "<b> " . $intTempNum . "</b> course category(s) available.";
		$varDisplayRowSizeText = "Displaying " . ($varStartLimit + 1) . " - " . ($varStartLimit + $intTempNum) . " of " . $varTotalCount . " (Course Categories)";
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
	</head>
	<body>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">&nbsp;</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">&nbsp;</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<form id="frmMain" name="frmMain" method="post" action="elms_category_list.php">
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tr>
																				<td colspan="2">
																					<div class="clsPageTopHeader" style="width:100%; display:inline-block;">
																						Course Category
																					</div>																				
																				</td>
																			</tr>
																			<tr height="25">
																				<td width="100%" align="center" colspan="2">
																				</td>
																			</tr>
																			<tr>
																				<td width="50%">
																					<div style="display:inline-block;">
																						<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_category_new.php';">Add New Course Category</div>
																					</div>
																				</td>
																				<td width="50%" align="right">
																					<div style="width:100%; display:inline-block;">
																						Show Category:&nbsp;
																						<select id="ddRowSize" name="ddRowSize" class="clsTextField" style="width:15%;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<?php if ($varRowSize==10) { ?>
																								<option selected value="10">10</option>
																							<?php } else { ?>
																								<option value="10">10</option>
																							<?php } ?>

																							<?php if ($varRowSize==25) { ?>
																								<option selected value="25">25</option>
																							<?php } else { ?>
																								<option value="25">25</option>
																							<?php } ?>

																							<?php if ($varRowSize==50) { ?>
																								<option selected value="50">50</option>
																							<?php } else { ?>
																								<option value="50">50</option>
																							<?php } ?>

																							<?php if ($varRowSize==100) { ?>
																								<option selected value="100">100</option>
																							<?php } else { ?>
																								<option value="100">100</option>
																							<?php } ?>

																							<?php if ($varRowSize==$varTotalCount) { ?>
																								<option selected value="0">All</option>
																							<?php } else { ?>
																								<option value="0">All</option>
																							<?php } ?>																							
																						</select>
																					</div>
																				</td>
																			</tr>
																			<tr height="25">
																				<td width="100%" colspan="2">
																				</td>
																			</tr>																		
																			<tr>
																				<td width="100%" align="right" colspan="2">
																					Search by Category Name:&nbsp;<input type="text" id="txtSearchWord" name="txtSearchWord" class="clsTextField" style="width:400px;" value="<?php echo $varSearchKeyWord; ?>" />
																					<div class="clsActionButton" onclick="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.submit();">&nbsp;Go&nbsp;</div>																				
																				</td>
																			</tr>																			
																			<?php
																				if ($intTempNum>0) { 
																					if ($varPaginationStyle=="PAGELINK") {
																						doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "TOP");
																					} else {
																					if ($varPaginationStyle=="PRENEXT") {
																						doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} else {
																						doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} }
																				}
																			?>																		
																		</table>
																	</td>
																	<input type="hidden" id="txtStartLimit" name="txtStartLimit" value="<?php echo $varStartLimit; ?>" />
																	<input type="hidden" id="txtAction" name="txtAction" value="" />
																	<input type="hidden" id="txtCurPage" name="txtCurPage" value="1" />
																</form>
															</tr>
															<tr height="10">
																<td>
																</td>
															</tr>
															<?php if ($intTempNum<=0) { ?>
																<tr height="25">
																	<td width="100%" align="center" class="clsResErrorMsgText">
																		<?php echo $strMessage; ?>
																	</td>
																</tr>
															<?php } else { ?>															
																<tr>
																	<td width="100%" align="left" valign="top">
																		<div class="clsSingleBorder">
																			<table width="100%" cellspacing="1" cellpadding="2">
																				<tr class="clsTableRowHeadingText">
																					<td width="2%">
																						#
																					</td>
																					<td width="82%">
																						Category Name
																					</td>
																					<td width="10%">
																						Enrolled Courses
																					</td>
																					<td width="6%" colspan="2">
																						Action
																					</td>
																				</tr>
																				<?php
																					$intTempInc = 0;
																					$strColorFilled = "No";
																					while ($row = mysql_fetch_array($categoryResult)) {
																						$intTempInc++;
																				?>
																				<?php
																					if ($strColorFilled=="No") {
																						$strColorFilled = "Yes";

																				?>
																					<tr class="clsAlternateFColor">
																				<?php
																					} else {
																						$strColorFilled = "No";

																				?>
																					<tr class="clsAlternateSColor">
																				<?php
																					}
																				?>
																						<td width="2%">
																							<img src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/groups_icon_small.png" alt="" title="" />
																						</td>
																						<td width="82%">
																							<?php echo $row["category_name"]; ?>
																						</td>
																						<td width="10%">
																							<?php
																								$tQuery = "SELECT course_id FROM elms_course_details WHERE course_cat=" . $row["category_id"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								if (dbNumRows($tResult)>0) {
																									echo dbNumRows($tResult);
																								} else {
																									echo "-";
																								}
																							?>
																						</td>
																						<td width="3%" align="center" valign="middle">
																							<form id="<?php echo "frmEdit_" . $row["category_id"] ?>" name="<?php echo "frmEdit_" . $row["category_id"] ?>" method="post" action="elms_category_edit.php">
																								<a href="javascript:document.<?php echo "frmEdit_" . $row["category_id"] ?>.submit();"><div><img src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/edit_icon.jpg" alt="Edit" title="Edit" /></div></a>
																								<input type="hidden" id="txtCatId" name="txtCatId" value="<?php echo $row["category_id"]; ?>">
																							</form>
																							<?php

																							?>
																						</td>
																						<td width="3%" align="center" valign="middle">
																							<!--
																							<a href="javascript:doShowDeletePanel('<?php echo $row["category_id"]; ?>', 'Course Category', '<?php echo $row["category_name"]; ?>.', 'elms_category_delete_update.php', 'elms_category_list.php');"><div><img src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/delete_icon.jpg" alt="Delete" title="Delete" /></div></a>
																							-->
																						</td>
																					</tr>
																				<?php } ?>
																			</table>
																		</div>
																	</td>
																</tr>
																<?php
																	if ($varPaginationStyle=="PAGELINK") {
																		doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "BOTTOM");
																	} else {
																	if ($varPaginationStyle=="PRENEXT") {
																		doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																	} else {
																		doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																	} }
																?>																
															<?php } ?>
														</table>
													</td>
													<td width="1%">&nbsp;</td>
												</tr>
											</table>
										</td>
										<td width="1%">&nbsp;</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>