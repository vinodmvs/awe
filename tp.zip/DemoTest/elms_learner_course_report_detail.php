<?php
	require("elms_top_includes.php");
?>

<?php
	$varCourseId = "";
	$varCourseName = "";
	$varCatName = "";
	$varCourseSDate = "-";
	$varCourseStatus = "-";
	$varCourseCDate = "-";
	$varCourseAScore = "-";
	$varCourseCertStatus = "-";
	$varCourseLADate = "-";
	$varCourseNumAttempts = "-";
	$varCourseTimeSpent = "-";
	$varCourseImage = "course_thumb_default.png";
	
	if (!isset($_POST["txtCourseId"])) {
		header("Location:index.php");
	} else {
		$varCourseId = $_POST["txtCourseId"];
		$tempQuery = "SELECT status FROM elms_course_scorm_track WHERE course_id=" . $varCourseId . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
		$tCheckResult = mysql_query($tempQuery) or die (mysql_error());
		if (dbNumRows($tCheckResult)>0) {
			$tempQuery = "SELECT ELMSCD.course_id, ELMSCD.course_cat, ELMSCD.course_name, ELMSCD.course_image, ELMSCATD.category_id, ELMSCATD.category_name, ";
			$tempQuery = $tempQuery . "ELMSST.user_id, ELMSST.course_id, ELMSST.status, ELMSST.score_raw, ELMSST.total_time, ELMSST.course_started_date, ELMSST.course_completed_date, ELMSST.course_last_accessed_date, ELMSST.course_num_attempts, ELMSST.course_certificate_sent ";
			$tempQuery = $tempQuery . "FROM elms_course_details ELMSCD INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat ";
			$tempQuery = $tempQuery . "INNER JOIN elms_course_scorm_track ELMSST ON ELMSST.course_id=ELMSCD.course_id ";
			$tempQuery = $tempQuery . "WHERE ELMSCD.course_id=" . $varCourseId . " AND ELMSST.user_id=" . $_SESSION["Elms_LoggedInId"];

			$courseDRResult = mysql_query($tempQuery) or die (mysql_error());
			$courseDRRow = mysql_fetch_array($courseDRResult);
			
			$varCourseName = $courseDRRow["course_name"];
			$varCatName = $courseDRRow["category_name"];
			if ($courseDRRow["course_started_date"]!="") $varCourseSDate = $courseDRRow["course_started_date"];
			switch (strtoupper($courseDRRow["status"])) {
				case "NOT ATTEMPTED":
					$varCourseStatus = "Not Started";
					break;
				case "COMPLETED":
					$varCourseStatus = "Completed";
					break;
				case "PASSED":
					$varCourseStatus = "Completed";
					break;
				case "INCOMPLETE":
					$varCourseStatus = "In Progress";
					break;
				case "FAILED":
					$varCourseStatus = "In Progress";
					break;					
			}
			if ($courseDRRow["course_completed_date"]!="") $varCourseCDate = $courseDRRow["course_completed_date"];
			if ((int)$courseDRRow["score_raw"]>0) $varCourseAScore = $courseDRRow["score_raw"];
			
			$tQuery = "SELECT course_iscert FROM elms_course_details WHERE course_id=" . $varCourseId;
			$tResult = mysql_query($tQuery) or die (mysql_error());
			if (dbNumRows($tResult)>0) {
				if ($courseDRRow["course_certificate_sent"]=="Y") {
					$varCourseCertStatus = "Issued";
				} else {
					$varCourseCertStatus = "-";
				}
			} else {
				$varCourseCertStatus = "-";
			}
			if ($courseDRRow["course_last_accessed_date"]!="") $varCourseLADate = $courseDRRow["course_last_accessed_date"];
			if ((int)$courseDRRow["course_num_attempts"]>0) $varCourseNumAttempts = $courseDRRow["course_num_attempts"];
			if ($courseDRRow["total_time"]!="") $varCourseTimeSpent = gmdate("H:i:s", $courseDRRow["total_time"]);
			$varCourseImage = $courseDRRow["course_image"];
		} else {
			$tempQuery = "SELECT ELMSCD.course_id, ELMSCD.course_cat, ELMSCD.course_name, ELMSCD.course_image, ELMSCATD.category_id, ELMSCATD.category_name ";
			$tempQuery = $tempQuery . "FROM elms_course_details ELMSCD INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat ";
			$tempQuery = $tempQuery . "WHERE ELMSCD.course_id=" . $varCourseId;
			
			$courseDRResult = mysql_query($tempQuery) or die (mysql_error());
			$courseDRRow = mysql_fetch_array($courseDRResult);
			
			$varCourseName = $courseDRRow["course_name"];
			$varCatName = $courseDRRow["category_name"];
			$varCourseImage = $courseDRRow["course_image"];			
		}
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
		</script>
	</head>
	<body>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td width="100%" align="left">
																				<div class="clsPageTopHeader" style="width:100%; display:inline-block;">
																					Course Report
																				</div>
																			</td>
																		</tr>
																	</table>
																</td>
															</tr>
															<tr height="25">
																<td width="100%" align="center" colspan="2">
																</td>
															</tr>														
															<tr>
																<td width="100%" align="center" valign="top">
																	<form name="frmMain" id="frmMain" method="post" enctype="multipart/form-data" action="elms_course_edit_update.php">
																		<table width="60%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="3">Course Detail Report</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Course Name:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php echo $varCourseName; ?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Category:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php echo $varCatName; ?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Started On:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php
																									if ($varCourseSDate=="-") {
																										echo $varCourseSDate;
																									} else {
																										$varTempDate = new DateTime($varCourseSDate);
																										echo $varTempDate->format("d-M-Y");
																									}
																								?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Course Status:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php echo $varCourseStatus; ?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Completed On:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php
																									if ($varCourseCDate=="-") {
																										echo $varCourseCDate;
																									} else {
																										$varTempDate = new DateTime($varCourseCDate);
																										echo $varTempDate->format("d-M-Y");
																									}
																								?>																							
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Assessment Score:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php echo $varCourseAScore; ?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Certification Status:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php echo $varCourseCertStatus; ?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Last Accessed On:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php
																									if ($varCourseLADate=="-") {
																										echo $varCourseLADate;
																									} else {
																										$varTempDate = new DateTime($varCourseLADate);
																										echo $varTempDate->format("d-M-Y");
																									}
																								?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Number of Attempts:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php echo $varCourseNumAttempts; ?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="49%" align="right" valign="top">Time Spent:</td>
																							<td width="2%"></td>
																							<td width="49%" align="left" valign="middle">
																								<?php echo $varCourseTimeSpent; ?>
																							</td>
																						</tr>																						
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="98%" align="left" valign="middle" colspan="3">
																								<table width="99%" cellspacing="0" cellpadding="0">
																									<tr>
																										<td width="99%" align="center" valign="middle">
																											<!--
																											<input type="button" value="E-mail" class="clsActionButton" />
																											<input type="button" value="Print" class="clsActionButton" />
																											<input type="button" value="Download" class="clsActionButton" />
																											-->
																											<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_learner_course_report.php');" />
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="10">
																							<td colspan="3"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtCourseId" name="txtCourseId" type="hidden" value="<?php echo $varCourseId; ?>" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>

<?php
	$_SESSION["Elms_CourseEditId"] = "";
?>