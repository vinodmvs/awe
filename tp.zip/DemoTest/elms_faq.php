<?php
	require("elms_config.php");
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			var strValidFileExtensions = [".jpg", ".jpeg", ".png", ".gif"];
			
			function doInitialize() {
				$("#txtDOB").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true,changeYear: true, yearRange: "-75:+0"});
				document.frmMain.txtFName.focus();
			}

			function doFormValidation() {
				if (document.frmMain.txtFName.value=="") {
					doShowAlertPanel("First Name cannot be blank. Please enter the First Name.", document.frmMain.txtFName);
				} else {
				if (document.frmMain.txtDOB.value=="") {
					doShowAlertPanel("Date of Birth cannot be blank. Please select the Date of Birth.", document.frmMain.txtDOB);
				} else {				
				if (document.frmMain.txtEmail.value=="") {
					doShowAlertPanel("E-mail Id cannot be blank. Please enter the E-mail Id.", document.frmMain.txtEmail);
				} else {
				if (!validEmail(document.frmMain.txtEmail.value)) {
					doShowAlertPanel("Invalid e-mail address format! \nEvery e-mail address must include one @ sign followed by a domain ne. \nEg: User@Server.com.", document.frmMain.txtEmail);
				} else {
				if (document.frmMain.txtProfilePic.value!="" && !doValidFileExtension(document.frmMain.txtProfilePic.value)) {
					doShowAlertPanel("Invalid picture file format! Please choose the valid picture file.", document.frmMain.txtProfilePic);
				} else {
					doShowProccessIcon();
					document.frmMain.submit();
				} } } } }
			}

			function doValidFileExtension(strTemp){
				var varRetVal = false;
				var sCurExtension = "";
				for (var i=0; i<strValidFileExtensions.length; i++) {
					sCurExtension = strValidFileExtensions[i];
					if (strTemp.substr(strTemp.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
						varRetVal = true;
						break;
					}
				}
				return varRetVal;
			}			
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel_loggedout.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<br /><br />
																	<form name="frmMain" id="frmMain" method="post" enctype="multipart/form-data" action="elms_user_signup_update.php">
																		<table width="100%" cellspacing="0" cellpadding="0">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%">Frequently Asked Questions</td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="top">
																								<table width="100%" align="left" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left">
																											<style>
																											<!--
																											 /* Font Definitions */
																											 @font-face
																												{font-family:Calibri;
																												panose-1:2 15 5 2 2 2 4 3 2 4;}
																											 /* Style Definitions */
																											 p.MsoNormal, li.MsoNormal, div.MsoNormal
																												{margin-top:0in;
																												margin-right:0in;
																												margin-bottom:10.0pt;
																												margin-left:0in;
																												line-height:115%;
																												font-size:11.0pt;
																												font-family:"Calibri","sans-serif";}
																											a:link, span.MsoHyperlink
																												{color:blue;
																												text-decoration:underline;}
																											a:visited, span.MsoHyperlinkFollowed
																												{color:purple;
																												text-decoration:underline;}
																											p
																												{margin-right:0in;
																												margin-left:0in;
																												font-size:12.0pt;
																												font-family:"Times New Roman","serif";}
																											span.apple-converted-space
																												{mso-style-name:apple-converted-space;}
																											.MsoChpDefault
																												{font-family:"Calibri","sans-serif";}
																											.MsoPapDefault
																												{margin-bottom:10.0pt;
																												line-height:115%;}
																											@page WordSection1
																												{size:8.5in 11.0in;
																												margin:1.0in 1.0in 1.0in 1.0in;}
																											div.WordSection1
																												{page:WordSection1;}
																											 /* List Definitions */
																											 ol
																												{margin-bottom:0in;}
																											ul
																												{margin-bottom:0in;}
																											-->
																											</style>

																											</head>

																											<body lang=EN-US link=blue vlink=purple>

																											<div class=WordSection1>

																											<p class=MsoNormal style='line-height:13.5pt;background:white'><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>We have
																											developed the FAQ’s based on questions asked by our registered members and are
																											sure that you will find answers to your questions here.&nbsp;</span></b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											<br>
																											<b>If you still cannot find the information you are looking for, please Contact
																											us at&nbsp;</b></span><a href="mailto:admin@glassacademy.in"><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif"'>admin@glassacademy.in</span></b></a></p>

																											<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;line-height:
																											normal'><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'><br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>1.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>How to register/ enroll for Glass Academy eLearning?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											To register, first logon to glass-academy.com. Click on the <b>eLearning</b> in
																											the top page. Clicking on the Sign-Up button will take you the registration
																											page, where you can enter your details and submit. You will then receive an
																											email notification to your registered email-id with your login credentials to
																											access the elearning modules.</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>2.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>Is there any minimum qualification required for enrollment?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											No qualification required for enrollment.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>3.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>Do I need to give proper email address during registration?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Yes. You need to give proper email address to receive proper communication
																											emails.</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>4.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>What is the procedure to get enrolled if I/ We represent from an
																											institution / organization?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Apart from individuals and professionals, organization deciding to train their
																											personnel can also join in. <br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>5.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>How do I login to the Glass-Academy eLearning?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											You can login into the Glass-Academy eLearning using your email-id and password
																											received through an e-mail. You will be required to change your password the
																											first time you login for security reasons.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>6.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>What is the cost of the training and certification?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Nominal fee is charged for all the learners. The cost of the training and
																											certification varies from module to module and from level to level (Competent
																											to Advanced, Advanced to Expert etc,)<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>7.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>Can you give free trial before I make payment?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											In training catalog page, you can go through the available demo curriculums.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>8.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>What payment options are available?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Payments can be made through the following mechanisms:<br>
																											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; • Through PayPal on the internet. All
																											information is 128-bit encrypted, so your data is secure.<br>
																											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; • Through cheque or Demand Drafts.&nbsp;<br>
																											<br>
																											If you wish to send the payment by cheque or demand draft, contact us at&nbsp;</span><a
																											href="mailto:admin@glassacademy.in"><b><span style='font-size:9.0pt;
																											font-family:"Arial","sans-serif"'>admin@glassacademy.in</span></b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif"'>&nbsp;</span></a><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>for
																											assistance.&nbsp;<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>9.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
																											</span></span></b><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>How do I pay using my credit card?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											You need to provide information on your credit card on our payment page at
																											payment gateway website. All details are passed through a SSL 128-bit encrypted
																											layer, so you do not have to worry about the safety of the data that you enter.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>10.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Is there
																											a possibility of a refund?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											There is no provision for a refund. Please contact us if you feel there has
																											been a deficiency of service.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>11.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Is there
																											any discount on your rates?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											There is a certain amount of discount for bulk purchases. Kindly contact us
																											at&nbsp;</span><a href="mailto:admin@glassacademy.in"><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif"'>admin@glassacademy.in</span></a><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'> for
																											further information.&nbsp;<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>12.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>What
																											should I do if the curriculum is not assigned even after the payment is made?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											If you have sent us your payment via demand draft, it is possible that we have
																											not received the payment yet. Curriculum will be assigned as soon as we receive
																											the payment. We will notify you via e-mail once we receive payment for the
																											same.&nbsp;<br>
																											For further assistance, please send e-mail to&nbsp;admin@glassacademy.in&nbsp;indicating
																											the Name, Curriculum(s) subscribed for, Login Name, email address, mode/ place
																											of payment.&nbsp;<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>13.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>I
																											completed my course, but it still says &quot;Not Started&quot; Why?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											While navigating through a course, it is mandatory to close the course window browser
																											to exit the course. In case if the course widow browser is still open, the
																											status does not get stored.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>14.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Can I
																											Sign out when the course is running?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											No, you cannot. You have to close the course window before you sign out,
																											otherwise your course access time will get lost.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>15.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>I have
																											not completed my course, but it says &quot;Course has expired&quot; Why?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											The time period allotted for you to complete the course has expired. Should you
																											wish to take up the same course once again, you would need to subscribe it again
																											like you did the first time.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>16.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Can I
																											send queries to the subject experts?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:0in;
																											margin-left:.5in;margin-bottom:.0001pt;line-height:13.5pt;background:white'><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Yes. You can send us queries at&nbsp;</span><a href="mailto:admin@glassacademy.in"><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif"'>admin@glassacademy.in&nbsp;</span></a><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>and the
																											same would be answered within one working day. Please note that additional
																											support is also provided through discussion forums of glass-academy.com<br>
																											<br>
																											.&nbsp;</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>17.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Not able
																											to play video/flash file?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Make sure that you have installed Flash Player 9/10 or above for the browser
																											(IE/FF) .<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>18.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Can I
																											download the animations or content for my future viewing?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Downloading of animations is not allowed. All images, graphics, text and other
																											materials posted on the website are protected and owned by Saint-Gobain Glass
																											Academy.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>19.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>How many
																											marks are required to pass the exam?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Participants require 80 percent marks to pass the exam. In case you do not pass
																											the exam, you do have the provision to take it again.&nbsp;<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>20.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>How many
																											times I can take the assessment?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											You can take assessment any number of times.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>21.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>If I
																											lose connection while taking the test due to some reason, do I need to start
																											the test again?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Yes. You have to re-log in and take the test.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>22.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>When an
																											Online assessment link will be activated?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											An assessment will be available at the end of each module, once you have
																											completed with the course content you need to take the assessment.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>23.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>When can
																											I view / print an Online Certificate?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											You can view / print an online certificate only after you have completed the
																											curriculum with minimum pass<br>
																											percentage (80%).<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>24.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Will I
																											get a printed copy of the report?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											No. All reports will be available on-line immediately after the test is taken.</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>25.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Can I
																											use the eLearning with my Pop-up Blocker enabled?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											The eLearning requires the use of pop-ups to launch e-Learning courses,
																											complete course evaluations and other common activities. If you are using a
																											pop-up blocker, please disable it when using the eLearning.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>26.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>Do I
																											receive an email communication / e-mailer of Glass Academy eLearning?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											Yes. You will receive communication on new elearning module, curriculum
																											purchase, curriculum completion, course remainder, curriculum expiry mail,
																											glassacademy.com newsletter etc. You can also view the system announcements
																											posted by an administrator.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>27.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>What
																											kind of internet connection do I need?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											A high-speed internet connection like DSL or Cable will work best for elearning
																											sessions. A dial-up connection with throughput better than 32 kbps would also
																											work well.<br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>28.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>On what
																											platform does this portal work?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:12.0pt;
																											margin-left:.5in;line-height:13.5pt;background:white'><span style='font-size:
																											9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											It works on Windows with Internet Explorer 7.0 or higher. <br>
																											<br>
																											</span></p>

																											<p class=MsoNormal style='margin-left:.5in;text-indent:-.25in;line-height:13.5pt;
																											background:white'><b><span style='font-size:9.0pt;font-family:"Arial","sans-serif";
																											color:#676767'>29.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></b><b><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'>In case
																											of any difficulties, whom do I contact?</span></b></p>

																											<p class=MsoNormal style='margin-top:0in;margin-right:0in;margin-bottom:0in;
																											margin-left:.5in;margin-bottom:.0001pt;line-height:13.5pt;background:white'><span
																											style='font-size:9.0pt;font-family:"Arial","sans-serif";color:#676767'><br>
																											If you have any questions, or experience any difficulties while using the LMS,
																											you can put the problem in the eLearning Helpdesk. Alternatively, kindly send
																											an email to&nbsp;admin@glassacademy.in. Please ensure that you explain your
																											problem(s) precisely, so that the issue will be addressed to the right person
																											and a solution will be provided at the earliest. Please specify your Login name
																											and e-mail address.</span></p>

																											<p class=MsoNormal>&nbsp;</p>																										
																										</td>
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>																									
																								</table>
																							</td>
																						</tr>																						
																					</table>
																				</td>
																			</tr>
																		</table>
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>						
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>