<table width="100%" cellpadding="0" cellspacing="0" border="0" class="clsCopyRight">
	<?php 
		$strCurFileName = strlen($_SERVER['QUERY_STRING']) ? basename($_SERVER['PHP_SELF'])."?".$_SERVER['QUERY_STRING'] : basename($_SERVER['PHP_SELF']);
	?>
	<?php if (strtolower($strCurFileName)=="elms_login.php") { ?>
		<tr bgcolor="#49c0f0">
	<?php } else { ?>
		<tr bgcolor="<?php echo $_SESSION["Elms_GeneralBgColor"]; ?>">
	<?php } ?>
		<td height="35"align="right" valign="middle">
			<font color="#cccccc">Powered by MVS Softech Private Limited&nbsp;&nbsp;</font>
		</td>
	</tr>
	<!--
	<tr height="5" bgcolor="#666666">
		<td></td>
	</tr>
	-->
</table>