<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varID = "";
	$varRole = "";
	if (!isset($_POST["ID"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["ID"];

		$tQuery = "SELECT user_role FROM elms_user_details WHERE user_id=" . $varID;
		$tResult = mysql_query($tQuery) or die (mysql_error());
		$tRow = mysql_fetch_row($tResult);

		$varRole = $tRow[0];

		if ($varRole=="Manager") {
			$tQuery = "SELECT user_id FROM elms_user_details WHERE user_head=" . $varID;
			$tResult = mysql_query($tQuery) or die (mysql_error());
			if (dbNumRows($tResult)>0) {
				$strMessage = "This user is a Manager and there are some users belongs to this Manager, so that you can not delete this user.";
			} else {
				$tQuery = "SELECT group_id FROM elms_assigned_groups WHERE user_id=" . $varID;
				$tResult = mysql_query($tQuery) or die (mysql_error());
				while ($tRow = mysql_fetch_array($tResult)) {
					$tempQuery = "UPDATE elms_group_details SET group_assigned='N' WHERE group_id=" . $tRow["group_id"];
					$tempResult = mysql_query($tempQuery);
				}

				$tempQuery = "DELETE FROM elms_assigned_groups WHERE user_id=" . $varID;
				$tempResult = mysql_query($tempQuery);

				$tempQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varID;
				$tempResult = mysql_query($tempQuery);
				
				$tempQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varID;
				$tempResult = mysql_query($tempQuery);

				$tempQuery = "DELETE FROM elms_login_logout_details WHERE user_id=" . $varID;
				$tempResult = mysql_query($tempQuery);

				$tempQuery = "DELETE FROM elms_user_details WHERE user_id=" . $varID;
				$tempResult = mysql_query($tempQuery);

				if ($tempResult) {
					$strMessage = "ELMS_SUCCESS";
				} else {
					$strMessage = "Unfortunately the system could not delete the Manager account.";
				}
			}
		} else {
			$tempQuery = "DELETE FROM elms_assigned_groups WHERE user_id=" . $varID;
			$tempResult = mysql_query($tempQuery);

			$tempQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varID;
			$tempResult = mysql_query($tempQuery);
			
			$tempQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varID;
			$tempResult = mysql_query($tempQuery);

			$tempQuery = "DELETE FROM elms_login_logout_details WHERE user_id=" . $varID;
			$tempResult = mysql_query($tempQuery);

			$tempQuery = "DELETE FROM elms_user_details WHERE user_id=" . $varID;
			$tempResult = mysql_query($tempQuery);

			if ($tempResult) {
				$strMessage = "ELMS_SUCCESS";
			} else {
				$strMessage = "Unfortunately the system could not delete the User account.";
			}
		}
		echo $strMessage;
	}
?>