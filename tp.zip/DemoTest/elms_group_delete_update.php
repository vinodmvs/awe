<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varID = "";
	if (!isset($_POST["ID"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["ID"];

		$tempQuery = "SELECT elms_assigned_groups.user_id, elms_assigned_groups.group_id, elms_user_details.user_role FROM elms_assigned_groups INNER JOIN elms_user_details ON elms_assigned_groups.user_id=elms_user_details.user_id WHERE elms_user_details.user_role<>'Admin' AND elms_user_details.user_role<>'Manager' AND elms_assigned_groups.group_id=" . $varID;
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		while ($tempRow = mysql_fetch_array($tempResult)) {
			$tQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $tempRow["user_id"];
			$tResult = mysql_query($tQuery);
			
			$tQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $tempRow["user_id"];
			$tResult = mysql_query($tQuery);

			$tQuery = "DELETE FROM elms_login_logout_details WHERE user_id=" . $tempRow["user_id"];
			$tResult = mysql_query($tQuery);

			$tQuery = "DELETE FROM elms_user_details WHERE user_id=" . $tempRow["user_id"];
			$tResult = mysql_query($tQuery);			
		}
		
		$tempQuery = "DELETE FROM elms_assigned_courses_group_wise WHERE group_id=" . $varID;
		$tempResult = mysql_query($tempQuery);
		
		$tempQuery = "DELETE FROM elms_assigned_groups WHERE group_id=" . $varID;
		$tempResult = mysql_query($tempQuery);
		
		$tempQuery = "DELETE FROM elms_group_details WHERE group_id=" . $varID;
		$tempResult = mysql_query($tempQuery);		

		if ($tempResult) {
			$strMessage = "ELMS_SUCCESS";
		} else {
			$strMessage = "Unfortunately the system could not delete the Group.";
		}
		echo $strMessage;
	}
?>