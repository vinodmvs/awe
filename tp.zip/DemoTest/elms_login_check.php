<?php
	require("elms_config.php");
	require("elms_db.php");
?>

<?php
	$strMessage = "";
	if (!isset($_POST["txtEmail"])) {
		header("Location:index.php");
	} else {
		$flgFound = "No";
		$tempLoginName = $_POST["txtEmail"];
		$tempLoginPass = $_POST["txtPass"];
		$varTempStatus = "A";

		$tempQuery = "SELECT * FROM elms_user_details";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		while ($tempRow = mysql_fetch_array($tempResult)) {
			if (strtolower($tempRow["user_login"])==strtolower($tempLoginName) && $tempRow["user_pass"]==$tempLoginPass) {
				$flgFound = "Yes";
				$_SESSION["Elms_LoggedInId"] = $tempRow["user_id"];
				$_SESSION["Elms_LoggedInEmail"] = $tempRow["user_email"];
				$_SESSION["Elms_LoggedInUserName"] = $tempRow["user_title"] . " " . $tempRow["user_fname"] . " " . $tempRow["user_lname"];
				$_SESSION["Elms_LoggedInUserType"] = $tempRow["user_role"];
				$_SESSION["Elms_LoggedInIEUserType"] = $tempRow["user_role"];
				$_SESSION["Elms_LoggedInMUPer"] = $tempRow["user_mu_per"];
				$_SESSION["Elms_LoggedInMGPer"] = $tempRow["user_mg_per"];
				$_SESSION["Elms_LoggedInProfilePic"] = $tempRow["user_profile_pic"];
				$_SESSION["Elms_ThemeColor"] = $tempRow["user_theme"];
				$varTempStatus = $tempRow["user_status"];
				break;
			}
		}

		if ($flgFound=="Yes") {
			if ($varTempStatus=="I") {
				$strMessage = "ELMS_DEACTIVE";
			} else {
				$tempQuery = "INSERT INTO elms_login_logout_details(user_id,login_dt,logout_dt) VALUES(" . $_SESSION["Elms_LoggedInId"] . ",'" . date('Y-m-d H:i:s') . "','" . date('Y-m-d H:i:s') . "')";
				$tempResult = mysql_query($tempQuery) or die (mysql_error());

				$_SESSION["Elms_LoggedInTrackId"] = dbInsertId();

				$_SESSION["Elms_ReplyEmail"] = "";
				$_SESSION["Elms_SiteURL"] = "";

				$tempQuery = "SELECT * FROM elms_branding_details";
				$tempResult = mysql_query($tempQuery) or die (mysql_error());
				if ($tempRow = mysql_fetch_array($tempResult)) {
					$_SESSION["Elms_ReplyEmail"] = $tempRow["company_reply_email"];
					$_SESSION["Elms_SiteURL"] = $tempRow["company_site_url"];
				}
				
				switch (strtoupper($_SESSION["Elms_LoggedInUserType"])) {
					case "ADMIN":
						$strMessage = "elms_dash_board.php";
						break;
					case "MANAGER":
						if ($_SESSION["Elms_LoggedInMUPer"]=="Y") {
							$strMessage = "elms_user_list.php";
						} else {
							$strMessage = "elms_course_list.php";
						}
						break;
					case "USER":
						$strMessage = "elms_course_list.php";
						break;
				}
			}
		} else {
			$strMessage = "ELMS_INVALID";
		}
		echo $strMessage;
	}
?>