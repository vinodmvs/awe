<?php
	require("elms_config.php");
	require("elms_db.php");
	require("elms_lib.php");
	if (!isset($_POST["txtData"])) {
		echo "Unfortunately the system could not generate the PDF.";
		exit();
	} else {
		require_once('tcpdf/config/tcpdf_config.php');
		require_once('tcpdf/tcpdf.php');
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, 'A4', true, 'UTF-8', false);
		$pdf->SetHeaderData("", "", "", "");
		$pdf->setPrintHeader(false);
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		$pdf->SetMargins(0, 5, 0);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		$pdf->AddPage();
		
		$image_file = 'images/logo.png';
		$pdf->Image($image_file, 0, 2, 50, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);
		
		
		$varCourseName = $_POST["txtCourseName"];
		$varCategory = $_POST["txtCourseCat"];
		

		$varScoreCardHTML = "";

		$pdf->SetFont('helvetica', 'B', 5);
		$pdf->writeHTML('<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><div style="height:5px; width:100%; background-color:#ffcc00;"></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'B', 3);
		$pdf->writeHTML('<div style="height:3px; width:100%;"></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'B', 11);
		$pdf->writeHTML('<div style="width:100%; height:100%; text-align:right"><font color="#3399ff">' . date("j-M-Y H:m:s") . '</font></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'B', 5);
		$pdf->writeHTML('<div style="height:3px; width:100%;"></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'N', 11);
		$pdf->writeHTML('<div style="height:3px; width:100%; text-align:center;"><font color="#000000"><b><u>Comprehensive Course Result Report</u></b></font></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'N', 5);
		$pdf->writeHTML('<div style="height:3px; width:100%;"></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'N', 10);
		$pdf->writeHTML('<div style="height:1px; width:100%; text-align:left;"><font color="#000000">&nbsp;&nbsp;<b>Course Name:</b>&nbsp;' . $varCourseName . '</font></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'N', 4);
		$pdf->writeHTML('<div style="height:3px; width:100%;"></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'N', 10);
		$pdf->writeHTML('<div style="height:1px; width:100%; text-align:left;"><font color="#000000">&nbsp;&nbsp;<b>Course Category:</b>&nbsp;' . $varCategory . '</font></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'N', 5);
		$pdf->writeHTML('<div style="height:3px; width:100%;"></div>', true, false, false, false, '');
		$pdf->SetFont('helvetica', 'N', 10);		
		$pdf->SetFont('helvetica', 'N', 8);		

		$varTempCSS = "<style>";
		$varTempCSS .= ".clsTableSingleRowHeadingText {height:35px; font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; font-size:10px; font-weight:normal; font-style:normal; color:#ffffff; background-color:" . $_SESSION["Elms_GeneralBgColor"] . "; text-align:left; vertical-align:middle; text-decoration: none;}";
		$varTempCSS .= ".clsTableRowHeadingText {height:35px; font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; font-size:10px; font-weight:normal; font-style:normal; color:#ffffff; background-color:" . $_SESSION["Elms_GeneralBgColor"] . "; text-align:left; vertical-align:middle; text-decoration: none;}";
		$varTempCSS .= ".clsAlternateFColor {background-color:" . $_SESSION["Elms_AlternateFColor"] . "; height:30px; font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; font-size:8px; font-weight:normal; text-align:left; vertical-align:top;}";
		$varTempCSS .= ".clsAlternateSColor {background-color:" . $_SESSION["Elms_AlternateSColor"] . "; height:30px; font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; font-size:8px; font-weight:normal; text-align:left; vertical-align:top;}";
		$varTempCSS .= "</style>";
		
		$varScoreCardHTML .= $varTempCSS;
		$varScoreCardHTML .= "&nbsp;" . $_POST["txtData"];
		
		$pdf->writeHTML($varScoreCardHTML, true, false, false, false, '');	
		
		ob_flush();
		$pdf->Output('Course_Comprehensive_Report_' . date('Y-m-d') . '.pdf', 'I');
	}
?>