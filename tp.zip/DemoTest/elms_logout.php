<?php
	require("elms_config.php");
	require("elms_db.php");
?>
<?php
	if (isset($_SESSION["Elms_LoggedInTrackId"]) && $_SESSION["Elms_LoggedInTrackId"]!="") {
		$tempQuery = "UPDATE elms_login_logout_details SET logout_dt='" . date('Y-m-d H:i:s') . "' WHERE track_id=" . $_SESSION["Elms_LoggedInTrackId"] . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
	}
	header("Location:index.php");
?>