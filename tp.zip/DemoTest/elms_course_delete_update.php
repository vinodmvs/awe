<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varID = "";
	if (!isset($_POST["ID"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["ID"];

		$tempQuery = "DELETE FROM elms_assigned_courses_group_wise WHERE course_id=" . $varID;
		$tempResult = mysql_query($tempQuery);		
		
		$tempQuery = "DELETE FROM elms_assigned_courses WHERE course_id=" . $varID;
		$tempResult = mysql_query($tempQuery);

		$tempQuery = "DELETE FROM elms_course_scorm_track WHERE course_id=" . $varID;
		$tempResult = mysql_query($tempQuery);

		$tempQuery = "DELETE FROM elms_scorm_main WHERE course_id=" . $varID;
		$tempResult = mysql_query($tempQuery);

		$tempQuery = "DELETE FROM elms_course_page_details WHERE course_id=" . $varID;
		$tempResult = mysql_query($tempQuery);

		$tempQuery = "DELETE FROM elms_course_details WHERE course_id=" . $varID;
		$tempResult = mysql_query($tempQuery);

		$strTempDir = $varID;
		switch (strlen($varID)) {
			case 1:
				$strTempDir = "0000" . $varID;
				break;
			case 2:
				$strTempDir = "000" . $varID;
				break;
			case 3:
				$strTempDir = "00" . $varID;
				break;
			case 4:
				$strTempDir = "0" . $varID;
				break;
		}

		$strCourseDir = "course/course_" . $strTempDir . "/";

		if (doRemoveDir($strCourseDir)) {
			$strMessage = "ELMS_SUCCESS";
		} else {
			$strMessage = "Unfortunately the system could not delete the Course.";
		}
		echo $strMessage;
	}
?>

<?php
	function doRemoveDir($dirname) {
        if (is_dir($dirname))
        $dir_handle = opendir($dirname);
        if (!$dir_handle)
        return false;
        while($file = readdir($dir_handle)) {
            if ($file != "." && $file != "..") {
                if (!is_dir($dirname."/".$file))
                unlink($dirname."/".$file);
                else
                {
                    $a=$dirname.'/'.$file;
                    doRemoveDir($a);
                }
            }
        }
        closedir($dir_handle);
        rmdir($dirname);
        return true;
    }
?>