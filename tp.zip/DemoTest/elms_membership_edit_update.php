<?php
	require("elms_top_includes.php");
?>

<?php
	$varID = "";
	$strMessage = "";
	$varName = "";
	$varDesc = "";

	if (!isset($_POST["txtMemId"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["txtMemId"];
		$varName = $_POST["txtName"];
		$varName = trim($varName);
		$varName = str_replace("'", "\\'", $varName);
		$varDesc = $_POST["txtDesc"];
		$varDesc = str_replace("'", "\\'", $varDesc);
		$varType = $_POST["txtMemType"];

		$tempQuery = "SELECT * FROM elms_membership_details WHERE mem_id<>" . $varID . " AND mem_name='" . $varName . "' AND mem_type='" . $varType . "'";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
			$tempQuery = "UPDATE elms_membership_details SET mem_name='" . $varName . "',mem_desc='" . $varDesc . "' WHERE mem_id=" . $varID;
			$tempResult = mysql_query($tempQuery);

			if ($tempResult) {
				$strMessage = "ELMS_SUCCESS";
			} else {
				$strMessage = "Unfortunately the system could not update the Membership details. Please try again!";
			}
		} else {
			$strMessage = "The entered Membership name already exists. Please enter another Membership.";
		}
		echo $strMessage;
	}
?>