<?php
	switch (strtoupper($_SESSION["Elms_ThemeColor"])) {
		case "BLUE":
			$_SESSION["Elms_GeneralBgColor"] = "#49c0f0";
			$_SESSION["Elms_AlternateFColor"] = "#c0e7f9";
			$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";				
			break;
		case "BROWN":
			$_SESSION["Elms_GeneralBgColor"] = "#c37d03";
			$_SESSION["Elms_AlternateFColor"] = "#fee5b8";
			$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";				
			break;
		case "GREEN":
			$_SESSION["Elms_GeneralBgColor"] = "#38b003";
			$_SESSION["Elms_AlternateFColor"] = "#e1fed4";
			$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";				
			break;
		case "GREY":
			$_SESSION["Elms_GeneralBgColor"] = "#626262";
			$_SESSION["Elms_AlternateFColor"] = "#edecec";
			$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";				
			break;
		case "LGREEN":
			$_SESSION["Elms_GeneralBgColor"] = "#adc622";
			$_SESSION["Elms_AlternateFColor"] = "#fbffe4";
			$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";				
			break;
		case "ORANGE":
			$_SESSION["Elms_GeneralBgColor"] = "#f98c2d";
			$_SESSION["Elms_AlternateFColor"] = "#ffe1d1";
			$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";				
			break;
		case "VIOLET":
			$_SESSION["Elms_GeneralBgColor"] = "#7a3ba6";
			$_SESSION["Elms_AlternateFColor"] = "#f1dcff";
			$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";				
			break;					
	}
?>
<style>
	.clsWelcomeMsgText {
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 16px;
		font-weight: normal;
		font-style: normal;
		color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		text-decoration: none;
	}
	.clsPageTopHeader {
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 25px;
		font-weight: normal;
		font-style: normal;
		color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		text-decoration: none;
	}	
	.clsFilterBorderWithBg {
		border: 1px solid #cccccc;
		background-color: <?php echo $_SESSION["Elms_AlternateFColor"]; ?>;
	}
	.clsTableRowHeadingText {
		height: 35px;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 15px;
		font-weight: normal;
		font-style: normal;
		color: #ffffff;
		background: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		text-align: left;
		vertical-align: middle;
		text-decoration: none;
	}
	.clsTableSingleRowHeadingText {
		height: 35px;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 17px;
		font-weight: normal;
		font-style: normal;
		color: #ffffff;
		background: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		text-align: center;
		vertical-align: middle;
		text-decoration: none;
	}
	.clsAlternateFColor {
		background-color: <?php echo $_SESSION["Elms_AlternateFColor"]; ?>;
		height:30px; font-size:14px; font-weight:normal; text-align:left; vertical-align:top;
	}
	.clsAlternateSColor {
		background-color: <?php echo $_SESSION["Elms_AlternateSColor"]; ?>;
		height:30px; font-size:14px; font-weight:normal; text-align:left; vertical-align:top;
	}
	.clsRoleSubLink {
		border:1px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-size:16px;font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; padding: 5px 10px 5px 10px; text-decoration:none; display:inline-block;text-shadow: -1px -1px 0 rgba(0,0,0,0.3);font-weight:normal; color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		cursor: pointer;
	}
	.clsRoleSubLink:hover {
		border:1px solid #333333; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-size:16px;font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; padding: 5px 10px 5px 10px; text-decoration:none; display:inline-block;text-shadow: -1px -1px 0 rgba(0,0,0,0.3);font-weight:normal; color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		cursor: pointer;
	}	
	.clsActionButton {
		border:1px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-size:15px;font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; padding: 5px 10px 5px 10px; text-decoration:none; display:inline-block;text-shadow: -1px -1px 0 rgba(0,0,0,0.3);font-weight:normal; color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		cursor: pointer;
	}
	.clsActionButton:hover {
		border:1px solid #ffffff; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-size:15px;font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; padding: 5px 10px 5px 10px; text-decoration:none; display:inline-block;text-shadow: -1px -1px 0 rgba(0,0,0,0.3);font-weight:normal; color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		cursor: pointer;
	}
	.clsButtonEnable {
		border:1px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-size:15px;font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; padding: 5px 10px 5px 10px; text-decoration:none; display:inline-block;text-shadow: -1px -1px 0 rgba(0,0,0,0.3);font-weight:normal; color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
		filter: alpha(opacity=100);
		-moz-opacity: 1;
		-khtml-opacity: 1;
		opacity: 1;
		cursor: pointer;
	}		
	.clsButtonDisable {
		border:1px solid #ffffff; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-size:15px;font-family:Open Sans, arial, verdana, helvetica, sans-serif, tahoma; padding: 5px 10px 5px 10px; text-decoration:none; display:inline-block;text-shadow: -1px -1px 0 rgba(0,0,0,0.3);font-weight:normal; color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;		
		-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)";
		filter: alpha(opacity=50);
		-moz-opacity: 0.50;
		-khtml-opacity: 0.50;
		opacity: 0.50;
		cursor: default;
	}
	.clsAlertTitle {
		left: 0px;
		top: 0px;
		width: 100%;
		height: 38px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 16px;
		font-weight: normal;
		font-style: normal;
		color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		text-align: left;
		vertical-align: middle;
		text-decoration: none;
		cursor:default;
		display: block;
	}
	.clsDivAlertCloseBtn {
		width: 63px;
		height: 34px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 15px;
		font-weight: bold;
		font-style: normal;
		color: #ffffff;
		vertical-align: middle;
		display: inline-block;
		cursor:pointer;
	}
	.clsDivAlertCloseBtn:hover {
		width: 63px;
		height: 34px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 15px;
		font-weight: bold;
		font-style: normal;
		color: #a4a4a4;
		vertical-align: middle;
		display: inline-block;
		cursor:pointer;
	}
	.clsDeleteTitle {
		left: 0px;
		top: 0px;
		width: 100%;
		height: 38px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 16px;
		font-weight: normal;
		font-style: normal;
		color: #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		text-align: left;
		vertical-align: middle;
		text-decoration: none;
		cursor:default;
		display: block;
	}
	.clsDivDeleteYesBtn {
		width: 63px;
		height: 34px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 15px;
		font-weight: bold;
		font-style: normal;
		color: #ffffff;
		vertical-align: middle;
		display: inline-block;
		cursor:pointer;
	}
	.clsDivDeleteYesBtn:hover {
		width: 63px;
		height: 34px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 15px;
		font-weight: bold;
		font-style: normal;
		color: #a4a4a4;
		vertical-align: middle;
		display: inline-block;
		cursor:pointer;
	}
	.clsDivDeleteNoBtn {
		width: 63px;
		height: 34px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 15px;
		font-weight: bold;
		font-style: normal;
		color: #ffffff;
		vertical-align: middle;
		display: inline-block;
		cursor:pointer;
	}
	.clsDivDeleteNoBtn:hover {
		width: 63px;
		height: 34px;
		-webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		border: 0px solid #ffffff;
		background-color: <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;
		font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
		font-size: 15px;
		font-weight: bold;
		font-style: normal;
		color: #a4a4a4;
		vertical-align: middle;
		display: inline-block;
		cursor:pointer;
	}	
</style>