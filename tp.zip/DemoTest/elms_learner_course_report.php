<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$intTempNum = 0;
	$tempQuery = "SELECT course_id FROM elms_assigned_courses WHERE user_id=" . $_SESSION["Elms_LoggedInId"];
	$courseResult = mysql_query($tempQuery) or die (mysql_error());
	if (dbNumRows($courseResult)<=0) {
		$strMessage =  "No course(s) available.";
	} else {
		$intTempNum = dbNumRows($courseResult);
		$strMessage = "<b> " . $intTempNum . "</b> course(s) available.";
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
	</head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td width="100%" align="left">
																				<div class="clsPageTopHeader" style="width:100%; display:inline-block;">
																					Course Report
																				</div>
																			</td>
																		</tr>
																	</table>
																</td>
															</tr>
															<tr height="25">
																<td width="100%" align="center" colspan="2">
																</td>
															</tr>
															<?php if ($intTempNum<=0) { ?>
																<tr height="25">
																	<td width="100%" align="center" class="clsResErrorMsgText">
																		<?php echo $strMessage; ?>
																	</td>
																</tr>
															<?php } else { ?>
																<tr>
																	<td width="100%" align="left" valign="top">
																		<div class="clsSingleBorder">
																			<table width="100%" cellspacing="1" cellpadding="2">
																				<tr class="clsTableRowHeadingText">
																					<td width="2%">
																					#
																					</td>
																					<td width="48%">
																						Course Name
																					</td>
																					<td width="11%">
																						Course Status
																					</td>
																					<td width="9%">
																						Time Spent
																					</td>
																					<td width="20%">
																						Certificate
																					</td>
																					<td width="10%">
																						Action
																					</td>																					
																				</tr>
																				<?php
																					$intTempInc = 0;
																					$strColorFilled = "No";
																					while ($row = mysql_fetch_array($courseResult)) {
																						$intTempInc++;
																				?>
																				<?php
																					if ($strColorFilled=="No") {
																						$strColorFilled = "Yes";

																				?>
																					<tr class="clsAlternateFColor">
																				<?php
																					} else {
																						$strColorFilled = "No";

																				?>
																					<tr class="clsAlternateSColor">
																				<?php
																					}
																				?>
																						<td width="2%">
																							<?php //echo $intTempInc; ?>
																							<img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/courses_icon_small.png" alt="" title="" />
																						</td>
																						<td width="48%">
																							<?php
																								$varTempCertficate = "Y";
																								$varTempCat = "";
																								$varTempDisplay = "";
																								$tQuery = "SELECT course_name, course_cat, course_iscert FROM elms_course_details WHERE course_id=" . $row["course_id"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								$tRow = mysql_fetch_array($tResult);
																								$varTempDisplay = $tRow["course_name"];
																								$varTempCat = $tRow["course_cat"];
																								$varTempCertficate = $tRow["course_iscert"];
																								echo $varTempDisplay;
																								
																								$varTempCategoryName = "";
																								$tQuery = "SELECT category_name FROM elms_category_details WHERE category_id=" . $tRow["course_cat"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								$tRow = mysql_fetch_row($tResult);
																								$varTempCategoryName = $tRow[0];																								
																							?>
																						</td>
																						<td width="11%" align="center">
																							<?php
																								$varTempDisplay = "-";
																								$tQuery = "SELECT status FROM elms_course_scorm_track WHERE course_id=" . $row["course_id"] . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								if (dbNumRows($tResult)<=0) {
																									$varTempDisplay = "Not Started";
																								} else {
																									$tRow = mysql_fetch_row($tResult);
																									if (strtoupper($tRow[0])=="NOT ATTEMPTED") {
																										$varTempDisplay = "Not Started";
																									} else {
																									if (strtoupper($tRow[0])=="COMPLETED" || strtoupper($tRow[0])=="PASSED") {
																										$varTempDisplay = "Completed";
																									} else {
																										$varTempDisplay = "In Progress";
																									} }
																								}
																								echo $varTempDisplay; 
																							?>
																						</td>
																						<td width="9%" align="center">
																							<?php
																								$varTempDisplay = "-";
																								$tQuery = "SELECT total_time FROM elms_course_scorm_track WHERE course_id=" . $row["course_id"] . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								if (dbNumRows($tResult)<=0) {
																									$varTempDisplay = "-";
																								} else {
																									$tRow = mysql_fetch_array($tResult);
																									$varTempDisplay = gmdate("H:i:s", $tRow["total_time"]);
																								}
																								echo $varTempDisplay; 
																							?>																						
																						</td>
																						<td width="20%" align="center">
																							<?php
																								$varTempDisplay = "";
																								$tQuery = "SELECT status FROM elms_course_scorm_track WHERE course_id=" . $row["course_id"] . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								if (dbNumRows($tResult)<=0) {
																									$varTempDisplay = "Not Started";
																								} else {
																									$tRow = mysql_fetch_row($tResult);
																									$varTempDisplay = $tRow[0];																									
																								}
																							?>
																							<?php if ($varTempCertficate=="Y") { ?>
																								<?php if (strtoupper($varTempDisplay)=="COMPLETED" || strtoupper($varTempDisplay)=="PASSED") { ?>
																									<?php
																										$varTempDisplayUserName = "";
																										$varTempDisplayCourseName = "";
																										$tQuery = "SELECT course_name FROM elms_course_details WHERE course_id=" . $row["course_id"];
																										$tResult = mysql_query($tQuery) or die (mysql_error());
																										$tRow = mysql_fetch_row($tResult);
																										$varTempDisplayCourseName = $tRow[0];
																										
																										$tQuery = "SELECT user_title, user_fname, user_lname FROM elms_user_details WHERE user_id=" . $_SESSION["Elms_LoggedInId"];
																										$tResult = mysql_query($tQuery) or die (mysql_error());
																										$tRow = mysql_fetch_row($tResult);
																										$varTempDisplayUserName = $tRow[0] . " " . $tRow[1] . " " . $tRow[2];
																										
																										$tQuery = "SELECT course_started_date, course_completed_date FROM elms_course_scorm_track WHERE user_id=" . $_SESSION["Elms_LoggedInId"] . " AND course_id=" . $row["course_id"];
																										$tResult = mysql_query($tQuery) or die (mysql_error());
																										$tRow = mysql_fetch_row($tResult);
																										$varTempDisplayCourseSD = $tRow[0];
																										$varTempDisplayCourseCD = $tRow[1];																										
																									?>
																									<div style="vertical-align:middle; display:inline-block;">
																										<img border="0" width="100" height="60" src="images/Certificate.png" />
																									</div>
																									<div style="vertical-align:middle; display:inline-block;">
																										<a class="clsActionButton" href="javascript:document.frmCert_<?php echo $row["course_id"]; ?>.submit();">View Certificate</a>
																									</div>
																									<form id="frmCert_<?php echo $row["course_id"]; ?>" name="frmCert_<?php echo $row["course_id"]; ?>" method="post" action="elms_view_certificate.php">
																										<input type="hidden" id="txtUserName" name="txtUserName" value="<?php echo $varTempDisplayUserName; ?>" />
																										<input type="hidden" id="txtCourseName" name="txtCourseName" value="<?php echo $varTempDisplayCourseName; ?>" />
																										<input type="hidden" id="txtCourseCatName" name="txtCourseCatName" value="<?php echo $varTempCategoryName; ?>" />
																										<input type="hidden" id="txtStartedDate" name="txtStartedDate" value="<?php echo $varTempDisplayCourseSD; ?>" />
																										<input type="hidden" id="txtCompletedDate" name="txtCompletedDate" value="<?php echo $varTempDisplayCourseCD; ?>" />
																										<input type="hidden" id="txtReturnURL" name="txtReturnURL" value="elms_learner_course_report.php" />
																									</form>
																								<?php } else { ?>
																									-
																								<?php } ?>
																							<?php } else { ?>
																								-
																							<?php } ?>
																						</td>
																						<td width="10%" align="center" valign="middle">
																							<form id="frmDetail_<?php echo $row["course_id"]; ?>" name="frmDetail_<?php echo $row["course_id"]; ?>" method="post" action="elms_learner_course_report_detail.php">
																								<a class="clsActionButton" href="javascript:document.frmDetail_<?php echo $row["course_id"]; ?>.submit();">More Detail</a>
																								<input type="hidden" id="txtCourseId" name="txtCourseId" value="<?php echo $row["course_id"]; ?>" />
																							</form>
																						</td>																						
																					</tr>
																				<?php } ?>
																			</table>
																		</div>
																	</td>
																</tr>
																<tr height="10">
																	<td>
																	</td>
																</tr>
																<tr>
																	<td>
																		<table width="100%" cellspacing="0" cellpadding="0">
																			<tr>
																				<td align="left">
																					<?php echo $strMessage; ?>
																				</td>
																			</tr>
																		</table>
																	</td>
																</tr>
															<?php } ?>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>