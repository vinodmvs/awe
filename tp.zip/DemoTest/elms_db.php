<?php
	$strMessage = "";

	/*
	$dbHost = 'localhost';
	$dbUser = 'root';
	$dbPass = '';
	$dbName = 'demo';
	*/
	
	$dbHost = 'localhost';
	$dbUser = 'mvslmsdemo';
	$dbPass = '5mRVM#jrU%';
	$dbName = 'demo';
	
	$dbConn = mysql_connect ($dbHost, $dbUser, $dbPass);

	if (!$dbConn) {
		$strMessage = "<b>Error: </b>MYSQL Server Connection Error: Could not connect to MYSQL SERVER";
	} else {
		$db = mysql_select_db($dbName);
		if (!$db) {
			$strMessage = "<b>Error: </b>MYSQL Server Database Error: Could not select the MYSQL SERVER Database";
		}
	}

	function dbQuery($sql) {
		$result = mysql_query($sql) or die(mysql_error());
		return $result;
	}

	function dbAffectedRows() {
		global $dbConn;
		return mysql_affected_rows($dbConn);
	}

	function dbFetchArray($result, $resultType = MYSQL_NUM) {
		return mysql_fetch_array($result, $resultType);
	}

	function dbFetchAssoc($result) {
		return mysql_fetch_assoc($result);
	}

	function dbFetchRow($result) {
		return mysql_fetch_row($result);
	}

	function dbFreeResult($result) {
		return mysql_free_result($result);
	}

	function dbNumRows($result) {
		return mysql_num_rows($result);
	}

	function dbSelect($dbName) {
		return mysql_select_db($dbName);
	}

	function dbInsertId() {
		return mysql_insert_id();
	}
	if ($strMessage!="") {
		echo $strMessage;
	}
?>