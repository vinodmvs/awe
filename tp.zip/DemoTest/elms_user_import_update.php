<?php
	require("elms_top_includes.php");
	require_once 'classes/PHPExcel.php';
?>

<?php
	$strMessage = "";
	$varExcelFileName = "";
	$varUserListTable = "";
	$varUserTitle = "Mr.";
	$strHead = "";
	$strRole = "";
	$varUserType = "";
	$varGId = "";
	$varGName = "";
	$varDateImported = date('Y-m-d');
	$varUserCreated = $varDateImported;
	$varMemType = "";

	if (isset($_FILES["txtExcelFile"])) {
		$strHead = $_POST["ddManager"];
		$strRole = $_POST["ddUserType"];
		$varMemType = $_POST["ddUserMemType"];

		if ($_POST["ddGroup"] && $_POST["ddGroup"]!="") {
			$varArrT = explode("~", $_POST["ddGroup"]);
			$varGId = $varArrT[0];
			$varGName = $varArrT[1];
			$tQuery = "SELECT group_type FROM elms_group_details WHERE group_id=" . $varGId;
			$tResult = mysql_query($tQuery) or die (mysql_error());
			$tRow = mysql_fetch_array($tResult);
			$varUserType = $tRow["group_type"];
		}

		$strUploadDir = "userdata";
		$varExcelFileName = 'manager_' . str_replace(" ", "", $_SESSION["Elms_LoggedInUserName"]) . "_" . date('Y-m-d') . '_userdata'.'.xlsx';
		if (move_uploaded_file($_FILES['txtExcelFile']['tmp_name'], $strUploadDir . '/' . $varExcelFileName)) {
			$inputFileName = $strUploadDir . '/' . $varExcelFileName;
			$colForTitle = 'A';
			$colForFN = 'B';
			$colForLN = 'C';
			$colForEmail = 'D';
			$colForDOB = 'E';
			$colForMobile = 'F';

			$objReader = PHPExcel_IOFactory::createReader('Excel2007');
			$objReader->setReadDataOnly(true);
			$objPHPExcel = $objReader->load($inputFileName);
			$objWorksheet = $objPHPExcel->getActiveSheet();
			$highestRow = $objWorksheet->getHighestRow();

			$arrUserDetails = array();
			$strEmailOld = "";
			$strContinue = "Yes";
			$intArrIndex = 0;

			for ($row=2; $row<=$highestRow; $row++) {
				$strContinue = "Yes";
				$strTitle = $objPHPExcel->getActiveSheet()->getCell($colForTitle.$row)->getValue();
				$strFN = $objPHPExcel->getActiveSheet()->getCell($colForFN.$row)->getValue();
				$strFN = str_replace("'", "\\'", $strFN);
				$strLN = $objPHPExcel->getActiveSheet()->getCell($colForLN.$row)->getValue();
				$strLN = str_replace("'", "\\'", $strLN);
				$strEmail = $objPHPExcel->getActiveSheet()->getCell($colForEmail.$row)->getValue();
				$strArrPass = explode("@", $strEmail);
				$strPass = $strArrPass[0];
				$strDOB = $objPHPExcel->getActiveSheet()->getCell($colForDOB.$row)->getValue();
				$strMobile = $objPHPExcel->getActiveSheet()->getCell($colForMobile.$row)->getValue();

				if (($strTitle=="" || $strTitle==null) && ($strFN=="" || $strFN==null) && ($strLN=="" || $strLN==null) && ($strEmail=="" || $strEmail==null) && ($strDOB=="" || $strDOB==null) && ($strMobile=="" || $strMobile==null)) {
					$strMessage = "The Excel file contains empty values in row " . $row . ". Please check the Excel file and try again!.";
					$strContinue = "No";
					break;
				} else {
					if ($strTitle=="" || $strFN=="" || $strEmail=="") {
						$strMessage = "The Excel file contains empty values in row " . $row . ". Please check the Excel file and try again!.";
						$strContinue = "No";
						break;
					} else {
					if ($strEmail==$strEmailOld) {
						$strMessage = "The Excel file contains duplicate E-mail values. Please check the Excel file and try again!.";
						$strContinue = "No";
						break;
					} else {
						$tempQuery = "SELECT * FROM elms_user_details WHERE user_email='" . $strEmail . "'";
						$tempResult = mysql_query($tempQuery) or die (mysql_error());
						$tempCheck = mysql_fetch_row($tempResult);
						if ($tempCheck==null || $tempCheck=="") {
							$strContinue = "Yes";
						} else {
							$strContinue = "No";
							$strMessage = "The E-mail Id <b>" . $strEmail . "</b> entered in the Excel Sheet already exists in the Database. Please change the E-mail Id and try again!.";
							break;
						}
					} }
					if ($strContinue=="Yes") {
						$arrUserDetails[$intArrIndex] = $strTitle . "ELMS_SPL" . $strFN . "ELMS_SPL" . $strLN . "ELMS_SPL" . $strEmail . "ELMS_SPL" . $strPass . "ELMS_SPL" . $strDOB . "ELMS_SPL" . $strMobile;
						$intArrIndex++;
						$strEmailOld = $strEmail;
						$strTitle = "";
						$strFN = "";
						$strLN = "";
						$strLN = "";
						$strEmail = "";
						$strPass = "";
						$strDOB = "";
						$strMobile = "";
					} else {
						break;
					}
				}
			}

			if ($strContinue=="Yes" && count($arrUserDetails)>0) {
				$varUserListTable = '<table cellspacing="0" cellpadding="2" width="100%" border="5"><tr><th width="2%">#</th><th width="8%">Title</th><th width="20%">First Name</th><th width="20%">Last Name</th><th width="30%">E-mail</th><th width="20%">Password</th></tr>';
				for ($i=0; $i<count($arrUserDetails); $i++) {
					$tempId = $i+1;
					$arrTempSpl = explode("ELMS_SPL", $arrUserDetails[$i]);
					$strTitle = $arrTempSpl[0];
					$strFN = $arrTempSpl[1];
					$strLN = $arrTempSpl[2];
					$strEmail = $arrTempSpl[3];
					$strPass = $arrTempSpl[4];
					$strDOB = $arrTempSpl[5];
					$strMobile = $arrTempSpl[6];

					$tempQuery = "INSERT INTO elms_user_details(user_title,user_mem_type, user_login, user_dob, user_phone, user_type, user_fname,user_lname,user_email,user_head,user_role,user_status,user_pass,user_created,user_reg_type) VALUES('" . $strTitle . "'," . $varMemType . ",'" . $strEmail . "','" . $strDOB . "','" . $strMobile . "','" . $varUserType . "','" . $strFN . "','" . $strLN . "','" . $strEmail . "','" . $strHead . "','" . $strRole . "','A','" . $strPass . "','" . $varUserCreated . "',2)";
					$tempResult = mysql_query($tempQuery);
					$varTempUserId = dbInsertId();

					if ($varGId!="" && $varGName!="") {
						$tQuery = "SELECT * FROM elms_group_details WHERE group_id=" . $varGId;
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$tempQuery = "INSERT INTO elms_assigned_groups(user_id,group_id,group_name,assigned_date) VALUES(" . $varTempUserId . "," . $tRow["group_id"] . ",'" . $tRow["group_name"] . "','" . $varUserCreated . "')";
						$tempResult = mysql_query($tempQuery) or die (mysql_error());
						if ($strRole=="Manager") {
							$tempQuery = "UPDATE elms_group_details SET group_assigned='Y' WHERE group_id=" . $tRow["group_id"];
							$tempResult = mysql_query($tempQuery) or die (mysql_error());

							$strTQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGId . " AND user_id<>" . $varTempUserId . " AND user_id<>" . $_SESSION["Elms_LoggedInId"];
							$strTResult = mysql_query($strTQuery) or die (mysql_error());
							while ($strTRow = mysql_fetch_array($strTResult)) {
								$strTQuery = "UPDATE elms_user_details SET user_head=" . $varTempUserId . " WHERE user_id=" . $strTRow["user_id"];
								$strTUpdateResult = mysql_query($strTQuery) or die (mysql_error());
							}
						}

						$tAssignCourse = "SELECT course_id, course_name FROM elms_assigned_courses_group_wise WHERE group_id=" . $tRow["group_id"];
						$tAssignResult = mysql_query($tAssignCourse) or die (mysql_error());
						while ($tAssignRow = mysql_fetch_array($tAssignResult)) {
							$tCheckQuery = "SELECT ELMSUD.user_mem_type, ELMSCD.course_id, ELMSCD.course_mem_type FROM elms_user_details ELMSUD INNER JOIN elms_course_details ELMSCD ON ELMSCD.course_mem_type RLIKE CONCAT(  '[[:<:]]', ELMSUD.user_mem_type,  '[[:>:]]' ) WHERE ELMSCD.course_id=" . $tAssignRow["course_id"] . " AND ELMSUD.user_id=" . $varTempUserId;
							$tCheckResult = mysql_query($tCheckQuery) or die (mysql_error());

							$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tAssignRow["course_id"];
							$tDelResult = mysql_query($tDelQuery) or die (mysql_error());							
							if (dbNumRows($tCheckResult)>0) {
								$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tAssignRow["course_id"] . ",'" . $tAssignRow["course_name"] . "','" . $varUserCreated . "')";
								$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
							}						
						}
					}
					
					/* Assigning Courses */
					$tQuery = "SELECT * FROM elms_course_details";
					$tChkResult = mysql_query($tQuery) or die (mysql_error());
					while ($tChkRow = mysql_fetch_array($tChkResult)) {
						if ($tChkRow["course_mem_type"]=="N/A" || $tChkRow["course_mem_type"]=="") {
							if ($tChkRow["course_for"]=="InernalOnly") {
								if ($varUserType=="Internal") {
									$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
									
									$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
											
									$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "')";
									$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());							
								}
							} else {
							if ($tChkRow["course_for"]=="ExternalOnly") {
								if ($varUserType=="External" && $tChkRow["course_isfree"]=="Y") {
									$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
									
									$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
											
									$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "')";
									$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());							
								}
							} else {
								if ($varUserType=="Internal") {
									$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
									
									$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
											
									$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "')";
									$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());							
								} else {
									if ($tChkRow["course_isfree"]=="Y") {
										$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
										$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
												
										$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "')";
										$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
									}							
								}							
							} }			
						} else {
							$varMemTypeFound = "No";
							$varTempMemSpl = explode("~", $tChkRow["course_mem_type"]);
							for ($k=0; $k<count($varTempMemSpl); $k++) {
								if ($varMemType==$varTempMemSpl[$k]) {
									$varMemTypeFound = "Yes";
									break;
								}
							}
							if ($varMemTypeFound=="Yes") {
								$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
								$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
								
								$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
								$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
								$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "')";
								$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());						
							}
						}
					}
					/* Assigning Groups and Courses */				

					$varImageBasePath = "http://demo.mvslms.com/";
					$varLogoHTML = '<img src="' . $varImageBasePath . 'images/logo.png" />';
					$varTodayDate = date('d-m-Y');				
					$varUserFname = $strFN;
					
					$varLoginDetailsHTML = "";
					$varLoginDetailsHTML .= '<table width="350" cellspacing="0" cellpadding="0" border="0">';
						$varLoginDetailsHTML .= '<tr>';
							$varLoginDetailsHTML .= '<td width="100%" align="left">';
								$varLoginDetailsHTML .= '<div id="divPrintArea" name="divPrintArea" style="border:1px solid #cccccc;">';
									$varLoginDetailsHTML .= '<table width="100%" cellspacing="1" cellpadding="2" bgcolor="#e4e4e4">';
										$varLoginDetailsHTML .= '<tr style="background:#04548f; height:35px; font-family:arial; color:#ffffff; font-size:12px; font-weight:normal; text-align:center; vertical-align:middle;">';
											$varLoginDetailsHTML .= '<td width="60%" align="left">';
												$varLoginDetailsHTML .= 'Login Id';
											$varLoginDetailsHTML .= '</td>';
											$varLoginDetailsHTML .= '<td width="40%" align="left">';
												$varLoginDetailsHTML .= 'Password';
											$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '</tr>';
										$varLoginDetailsHTML .= '<tr style="background:#eaffea; height:25px; font-family:arial; color:#000000; font-size:11px; font-weight:normal; text-align:left; vertical-align:middle;">';
											$varLoginDetailsHTML .= '<td width="60%" align="left" valign="middle">';
												$varLoginDetailsHTML .= $strEmail;
											$varLoginDetailsHTML .= '</td>';
											$varLoginDetailsHTML .= '<td width="40%" align="left" valign="middle">';
												$varLoginDetailsHTML .= $strPass;
											$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '</tr>';
									$varLoginDetailsHTML .= '</table>';
								$varLoginDetailsHTML .= '</div>';
							$varLoginDetailsHTML .= '</td>';
						$varLoginDetailsHTML .= '</tr>';
					$varLoginDetailsHTML .= '</table>';

					$varSubject = "MVSLMS: New User Registration Login Details";
					$varMessage = <<<EOF
<html>
	<head></head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<table width="100%" cellspacing="0" cellpadding="0" bordercolor="#004080" border="5">
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%" align="left" valign="center">
									$varLogoHTML
								</td>
							</tr>
							<tr height="5" bgcolor="#ffcc00">
								<td></td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
							<tr>
								<td width="100%" align="center" valign="top">
									<table width="98%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="100%" align="right" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Date: $varTodayDate</b>
												</font>
											</td>
										</tr>
										<tr height="5">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Dear $varUserTitle $varUserFname,</b>
												</font>
												<br /><br />
												<font face="arial" size="2" color="#000000">
													Thank you for registering at <a href="http://www.mvslms.com" target="_blank">www.mvslms.com</a>. It is our immense pleasure to welcome you to the MVSLMS Family.
													<br /><br />
													$varLoginDetailsHTML
													<br /><br />
													Should you encounter any problems, have questions or comments, please email us at: mvssoftech@gmail.com													
													<br /><br />
													Happy Learning!!
													<br /><br />
													Regards,
													<br /><br />
													MVSLMS
													<br />
													<a href="http://www.mvslms.com" target="_blank">www.mvslms.com</a>
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>
EOF;
					$varEmailTo = $strEmail;
					$varEmailFrom = "";
					$varEmailFromName = "";
					$tQuery = "SELECT company_name, company_reply_email FROM elms_branding_details";
					$tResult = mysql_query($tQuery) or die (mysql_error());
					if ($tRow = mysql_fetch_array($tResult)) {
						$varEmailFrom = $tRow["company_reply_email"];
						$varEmailFromName = $tRow["company_name"];
					}
					$varEmailFrom = $varEmailFrom;
					$varEmailFromName = "MVSLMS";
					$mail = new PHPMailer();
					$mail->From = $varEmailFrom;
					$mail->FromName = $varEmailFromName;
					$mail->AddAddress($varEmailTo, $varUserFname);
					$mail->AddReplyTo($varEmailFrom, $varEmailFromName);
					$mail->IsHTML(true);
					$mail->Subject = $varSubject;
					$mail->Body = $varMessage;
					$mail->AltBody = "Here is your Login details.";

					if($varEmailFrom!="" && $mail->Send()) {
					} else {
						$strMessage = "Unfortunately the system could not send an email to recipient.";
					}
					$varUserListTable = $varUserListTable . '<tr><td width="2%">' . ($i+1) . '</td><td width="8%">' . $strTitle . '</td><td width="20%">' . $strFN . '</td><td width="20%">' . $strLN . '</td><td width="30%">' . $strEmail . '</td><td width="20%">' . $strPass . '</td></tr>';
				}

				$varUserListTable = $varUserListTable . '</table>';

				$varImageBasePath = "http://demo.mvslms.com/";
				$varLogoHTML = '<img src="' . $varImageBasePath . 'images/logo.png" />';
				$varTodayDate = date('d-m-Y');
				$varUserFname = $_SESSION["Elms_LoggedInUserName"];
			
				
				$varLoginDetailsHTML = $varUserListTable;
				$varSubject = "MVSLMS: Import User Details for " . $varGName;
				$varMessage = <<<EOF
<html>
	<head></head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<table width="100%" cellspacing="0" cellpadding="0" bordercolor="#004080" border="5">
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%" align="left" valign="center">
									$varLogoHTML
								</td>
							</tr>
							<tr height="5" bgcolor="#ffcc00">
								<td></td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
							<tr>
								<td width="100%" align="center" valign="top">
									<table width="98%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="100%" align="right" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Date: $varTodayDate</b>
												</font>
											</td>
										</tr>
										<tr height="5">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Dear $varUserFname,</b>
												</font>
												<br /><br />
												<font face="arial" size="2" color="#000000">
													Below is the Imported User Details for <b>$varGName</b> on $varTodayDate.													
													<br /><br />
													$varLoginDetailsHTML
													<br /><br />
													Regards,
													<br /><br />
													MVSLMS
													<br />
													<a href="www.mvslms.com" target="_blank">www.mvslms.com</a>
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>
EOF;
				$varEmailTo = $_SESSION["Elms_LoggedInEmail"];
				$varEmailFrom = "";
				$varEmailFromName = "";
				$tQuery = "SELECT company_name, company_reply_email FROM elms_branding_details";
				$tResult = mysql_query($tQuery) or die (mysql_error());
				if ($tRow = mysql_fetch_array($tResult)) {
					$varEmailFrom = $tRow["company_reply_email"];
					$varEmailFromName = $tRow["company_name"];
				}
				$varEmailFrom = $varEmailFrom;
				$varEmailFromName = "MVSLMS";
				$mail = new PHPMailer();
				$mail->From = $varEmailFrom;
				$mail->FromName = $varEmailFromName;
				$mail->AddAddress($varEmailTo, $varUserFname);
				$mail->AddReplyTo($varEmailFrom, $varEmailFromName);
				$mail->IsHTML(true);
				$mail->Subject = $varSubject;
				$mail->Body = $varMessage;
				$mail->AltBody = "Here is your Imported User Details.";
				
				if($varEmailFrom!="" && $mail->Send()) {
					$strMessage = "ELMS_SUCCESS";
				} else {
					$strMessage = "Unfortunately the system could not send an email to recipient.";
				}
			}
		} else {
			$strMessage = "Unfortunately the system could not upload the Excel file. Please check the Excel file and try again!";
		}
		echo $strMessage;
	} else {
		header("Location:index.php");
	}
?>