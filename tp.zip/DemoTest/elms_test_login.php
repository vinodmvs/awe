<!doctype html>
<html>
	<head>
	</head>
	<body>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tr>
				<td width="100%" align="center" valign="middle">
					<div style="font-size:35px;">Sign In</div>
				</td>
			</tr>
		</table>
		<table width="100%" align="left" valign="top" cellspacing="0" cellpadding="0" border="0">
			<tr>
				<td width="100%" align="left" valign="top">
					<form name="frmMain" id="frmMain" method="post" action="elms_login_check.php">
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tr>
								<td width="100%" align="left" valign="middle">
									<table border="0">
										<tr height="38">
											<td valign="middle">
												<img src="images/Mail_icon.png" alt="" title="" />
											</td>
											<td>
											</td>
											<td valign="top">
												<font size="5">E-mail</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" align="left" valign="middle">
									<input type="text" id="txtEmail" name="txtEmail" style="width:350px; height:30px; font-size:15px;" />
								</td>
							</tr>
							<tr height="25">
								<td>
								</td>
							</tr>
							<tr>
								<td width="100%" align="left" valign="middle">
									<table border="0">
										<tr height="37">
											<td valign="middle">
												<img src="images/lock_icon.png" alt="" title="" />
											</td>
											<td>
											</td>
											<td valign="top">
												<font size="5">Password</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td width="100%" align="left" valign="middle">
									<input type="password" id="txtPass" name="txtPass" style="width:350px; height:30px; font-size:15px;" />
								</td>
							</tr>
							<tr height="15">
								<td>
								</td>
							</tr>
							<tr>
								<td width="100%" align="left" valign="middle">
									<table width="48%" border="0">
										<tr>
											<td align="right">
												<a href="#"><font color="#000000" size="5">Forgot Password</font></a>
											</td>
										</tr>
									</table>

								</td>
							</tr>
							<tr height="25">
								<td>
								</td>
							</tr>
							<tr>
								<td width="100%" align="left" valign="middle">
									<input type="button" value="Sign In" style="width:355px; height:45px; font-size:25px;" />
								</td>
							</tr>
						</table>
					</form>
				</td>
			</tr>
		</table>								
	</body>
</html>