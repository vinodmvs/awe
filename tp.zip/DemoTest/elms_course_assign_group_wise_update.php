<?php
	require("elms_top_includes.php");
?>

<?php
	$strUserId = null;
	$strMessage = null;
	$varGroupId = null;
	$varCourses = null;
	$varRMCourses = null;
	$varAssignedDate = null;

	if (!isset($_POST["ddGroup"])) {
		header("Location:index.php");
	} else {
		$strUserId = $_POST["txtUser"];
		$varGroupId = $_POST["ddGroup"];
		$varCourses = $_POST["txtCourses"];
		$varRMCourses = $_POST["txtTempRMCourses"];
		$varAssignedDate = date('Y-m-d');

		$tempQuery = "DELETE FROM elms_assigned_courses_group_wise WHERE group_id=" . $varGroupId;
		$tempResult = mysql_query($tempQuery);

		if ($varRMCourses!=null && $varRMCourses!="") {
			$arrTemp = explode("~", $varRMCourses);
			for ($i=0; $i<count($arrTemp); $i++) {
				$tQuery = "SELECT * FROM elms_course_details WHERE course_id=" . $arrTemp[$i];
				$tResult = mysql_query($tQuery) or die (mysql_error());
				$tRow = mysql_fetch_array($tResult);

				$tempQueryT = "SELECT elms_assigned_groups.user_id FROM elms_assigned_groups INNER JOIN elms_user_details ON elms_user_details.user_id=elms_assigned_groups.user_id WHERE elms_user_details.user_role<>'Admin' AND elms_user_details.user_role<>'Manager' AND elms_assigned_groups.group_id=" . $varGroupId;
				$tempResultT = mysql_query($tempQueryT) or die (mysql_error());
				while ($tempRowT = mysql_fetch_array($tempResultT)) {
					$tempQuery = "DELETE FROM elms_assigned_courses WHERE course_id=" . $tRow["course_id"] . " AND user_id=" . $tempRowT["user_id"];
					$tempResult = mysql_query($tempQuery);
				}
			}
		}


		if ($varCourses!=null && $varCourses!="") {
			$arrTemp = explode("~", $varCourses);
			for ($i=0; $i<count($arrTemp); $i++) {
				$tQuery = "SELECT * FROM elms_course_details WHERE course_id=" . $arrTemp[$i];
				$tResult = mysql_query($tQuery) or die (mysql_error());
				$tRow = mysql_fetch_array($tResult);
				$tempQuery = "INSERT INTO elms_assigned_courses_group_wise(group_id,course_id,course_name,assigned_date) VALUES(" . $varGroupId . "," . $tRow["course_id"] . ",'" . $tRow["course_name"] . "','" . $varAssignedDate . "')";
				$tempResult = mysql_query($tempQuery);
			}
		}

		if ($varCourses!=null && $varCourses!="") {
			$arrTemp = explode("~", $varCourses);
			for ($i=0; $i<count($arrTemp); $i++) {
				$tQuery = "SELECT * FROM elms_course_details WHERE course_id=" . $arrTemp[$i];
				$tResult = mysql_query($tQuery) or die (mysql_error());
				$tRow = mysql_fetch_array($tResult);

				//$tempQueryT = "SELECT elms_assigned_groups.user_id FROM elms_assigned_groups INNER JOIN elms_user_details ON elms_user_details.user_id=elms_assigned_groups.user_id WHERE elms_user_details.user_role<>'Admin' AND elms_user_details.user_role<>'Manager' AND elms_assigned_groups.group_id=" . $varGroupId;
				$tempQueryT = "SELECT elms_assigned_groups.user_id FROM elms_assigned_groups INNER JOIN elms_user_details ON elms_user_details.user_id=elms_assigned_groups.user_id WHERE elms_assigned_groups.group_id=" . $varGroupId;
				$tempResultT = mysql_query($tempQueryT) or die (mysql_error());
				while ($tempRowT = mysql_fetch_array($tempResultT)) {
					$tCheckQuery = "SELECT course_id FROM elms_assigned_courses WHERE user_id=" . $tempRowT["user_id"] . " AND course_id=" . $arrTemp[$i];
					$tCheckResult = mysql_query($tCheckQuery) or die (mysql_error());
					if (dbNumRows($tCheckResult)<=0) {
						$tempQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $tempRowT["user_id"] . "," . $tRow["course_id"] . ",'" . $tRow["course_name"] . "','" . $varAssignedDate . "')";
						$tempResult = mysql_query($tempQuery);
					}
				}
			}
		}

		if ($tempResult) {
			$strMessage = "ELMS_SUCCESS";
		} else {
			$strMessage = "<b>Error: </b>Error occured while adding the Courses into the Database.";
		}

		echo $strMessage;
	}
?>