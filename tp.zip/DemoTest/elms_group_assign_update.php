<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = null;
	$varUserId = null;
	$varRole = null;
	$varGroups = null;
	$varRMGroups = null;
	$varAssignedDate = null;

	if (!isset($_POST["ddUser"])) {
		header("Location:index.php");
	} else {
		$varUserId = $_POST["ddUser"];
		$varRole = $_POST["txtUserRole"];
		$varGroups = $_POST["txtGroups"];
		$varRMGroups = $_POST["txtRMGroups"];
		$varAssignedDate = date('Y-m-d');

		if ($varRole=="Manager") {
			if ($varRMGroups!=null && $varRMGroups!="") {
				$arrTemp = explode("~", $varRMGroups);
				for ($i=0; $i<count($arrTemp); $i++) {
					$tempQuery = "UPDATE elms_group_details SET group_assigned='N' WHERE group_id=" . $arrTemp[$i];
					$tempResult = mysql_query($tempQuery);

					$strTQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $arrTemp[$i] . " AND user_id<>" . $varUserId . " AND user_id<>" . $_SESSION["Elms_LoggedInId"];
					$strTResult = mysql_query($strTQuery) or die (mysql_error());
					while ($strTRow = mysql_fetch_array($strTResult)) {
						$strTQuery = "UPDATE elms_user_details SET user_head=" . $_SESSION["Elms_LoggedInId"] . " WHERE user_id=" . $strTRow["user_id"];
						$strTUpdateResult = mysql_query($strTQuery) or die (mysql_error());
					}
				}
			}
		}

		$tempQuery = "DELETE FROM elms_assigned_groups WHERE user_id=" . $varUserId;
		$tempResult = mysql_query($tempQuery);
		if ($varGroups!=null && $varGroups!="") {
			$arrTemp = explode("~", $varGroups);
			for ($i=0; $i<count($arrTemp); $i++) {
				$tQuery = "SELECT * FROM elms_group_details WHERE group_id=" . $arrTemp[$i];
				$tResult = mysql_query($tQuery) or die (mysql_error());
				$tRow = mysql_fetch_array($tResult);
				$tempQuery = "INSERT INTO elms_assigned_groups(user_id,group_id,group_name,assigned_date) VALUES(" . $varUserId . "," . $tRow["group_id"] . ",'" . $tRow["group_name"] . "','" . $varAssignedDate . "')";
				$tempResult = mysql_query($tempQuery);
				if ($varRole=="Manager") {
					$tempQuery = "UPDATE elms_group_details SET group_assigned='Y' WHERE group_id=" . $tRow["group_id"];
					$tempResult = mysql_query($tempQuery);

					$strTQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $arrTemp[$i] . " AND user_id<>" . $varUserId . " AND user_id<>" . $_SESSION["Elms_LoggedInId"];
					$strTResult = mysql_query($strTQuery) or die (mysql_error());
					while ($strTRow = mysql_fetch_array($strTResult)) {
						$strTQuery = "UPDATE elms_user_details SET user_head=" . $varUserId . " WHERE user_id=" . $strTRow["user_id"];
						$strTUpdateResult = mysql_query($strTQuery) or die (mysql_error());
					}
				}

				$tAssignCourse = "SELECT course_id, course_name FROM elms_assigned_courses_group_wise WHERE group_id=" . $tRow["group_id"];
				$tAssignResult = mysql_query($tAssignCourse) or die (mysql_error());
				$tChkResult = mysql_query($tAssignCourse) or die (mysql_error());
				$tempCheck = mysql_fetch_row($tChkResult);
				if ($tempCheck!=null && $tempCheck!="") {
					while ($tAssignRow = mysql_fetch_array($tAssignResult)) {
						$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varUserId . " AND course_id=" . $tAssignRow["course_id"];
						$tDelResult = mysql_query($tDelQuery) or die (mysql_error());

						$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varUserId . "," . $tAssignRow["course_id"] . ",'" . $tAssignRow["course_name"] . "','" . date('Y-m-d') . "')";
						$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
					}
				}
			}
		}

		if ($tempResult) {
			$strMessage = "ELMS_SUCCESS";
		} else {
			$strMessage = "<b>Error: </b>Error occured while adding the Groups into the Database.";
		}

		echo $strMessage;
	}
?>