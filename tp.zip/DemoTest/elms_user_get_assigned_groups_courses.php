<?php
	require("elms_top_includes.php");
?>

<?php
	$strUserId = "";
	$strRole = "";
	$strType = "";
	$strMessage = "";
	$strDispGroups = "";
	$strDispCourses = "";

	if (!isset($_POST["UserId"])) {
		header("Location:index.php");
	} else {
		$strUserId = $_POST["UserId"];
		$strRole = $_POST["UserRole"];
		$strType = $_POST["UserType"];
		if ($strRole=="Manager") {
			$tQuery = "SELECT ELMSGD.group_assigned, ELMSAG.group_id, ELMSAG.group_name, ELMSAG.user_id FROM elms_group_details ELMSGD INNER JOIN elms_assigned_groups ELMSAG ON ELMSGD.group_id=ELMSAG.group_id WHERE (ELMSGD.group_assigned='N' AND ELMSAG.user_id=" . $strUserId . ") ORDER BY ELMSAG.group_name";
		} else {
			$tQuery = "SELECT * FROM elms_assigned_groups WHERE user_id=" . $strUserId;
		}
		$tResult = mysql_query($tQuery) or die (mysql_error());
		$tempResult = mysql_query($tQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
		} else {
			while ($tRow = mysql_fetch_array($tResult)) {
				$tCheckQuery = "SELECT group_type FROM elms_group_details WHERE group_id=" . $tRow["group_id"];
				$tCheckResult = mysql_query($tCheckQuery) or die (mysql_error());
				$tCheckRow = mysql_fetch_array($tCheckResult);
				if ($tCheckRow["group_type"]==$strType) {				
					if ($strDispGroups=="") {
						$strDispGroups = $tRow["group_id"] . "~" . $tRow["group_name"];
					} else {
						$strDispGroups = $strDispGroups. "ELMS_SPL" . $tRow["group_id"] . "~" . $tRow["group_name"];
					}
				}
			}
		}

		$tQuery = "SELECT * FROM elms_assigned_courses WHERE user_id=" . $strUserId;

		$tResult = mysql_query($tQuery) or die (mysql_error());
		$tempResult = mysql_query($tQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
		} else {
			while ($tRow = mysql_fetch_array($tResult)) {
				if ($strDispCourses=="") {
					$strDispCourses = $tRow["course_id"] . "~" . $tRow["course_name"];
				} else {
					$strDispCourses = $strDispCourses. "ELMS_SPL" . $tRow["course_id"] . "~" . $tRow["course_name"];
				}
			}
		}

		if ($strDispGroups=="") $strDispGroups = "NoGroups";
		if ($strDispCourses=="") $strDispCourses = "NoCourses";
		$strMessage = $strDispGroups . "ELMS_SPLMAIN" . $strDispCourses;

		echo $strMessage;
	}
?>