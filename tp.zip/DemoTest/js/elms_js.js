var objElement = null;
var strObjId = "";
var strAjaxReturnTrimed = "";
var strTempGroups = "";
var strTempCourses = "";
var strTempAvailGroups = "";
var strTempAssignedGroups = "";
var strOldPass = "";
var strValidFileExtensions = [".zip"];
var strDelURL = "";
var strDelRetURL = "";
var strProccessingText = "Processing please wait...";

function validEmail(email) {
	invalidChars = "~`!#$%^&*()=+[]{}:;\/\"'?<>, "
	if (email == "") {
		return false
	}
	for (i=0; i<invalidChars.length; i++) {
		badChar = invalidChars.charAt(i)
		if (email.indexOf(badChar,0) > -1) {
			return false
		}
	}
	atPos = email.indexOf("@",1)
	if (atPos == -1) {
		return false
	}
	if (email.indexOf("@",atPos+1) != -1) {
		return false
	}
	aftat = (email.indexOf("@",atPos))
	aftat = aftat + 1
	if ((aftat == email.indexOf("."))) {
		return false
	}
	//tot_length = email.indexOf("@")+2;
	periodPos = email.indexOf(".",atPos)
	if (periodPos == -1) {
		return false
	}

	if (periodPos+3 > email.length)	{
		return false
	}
	return true
}

function date_time(id) {
	date = new Date;
	year = date.getFullYear();
	month = date.getMonth();
	months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'Jully', 'August', 'September', 'October', 'November', 'December');
	d = date.getDate();
	day = date.getDay();
	days = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
	h = date.getHours();
	if(h<10)
	{
			h = "0"+h;
	}
	m = date.getMinutes();
	if(m<10)
	{
			m = "0"+m;
	}
	s = date.getSeconds();
	if(s<10)
	{
			s = "0"+s;
	}
	result = ''+days[day]+' '+months[month]+' '+d+' '+year+'&nbsp;&nbsp;&nbsp;'+h+':'+m+':'+s;
	document.getElementById(id).innerHTML = result;
	setTimeout('date_time("'+id+'");','1000');
	return true;
}

function doShowProccessIcon() {
	getScrollTop();
	if (strProccessingText = "Processing please wait...") {
	} else {
		strProccessingText = "Processing please wait...";
	}
	$('#divProccess').html(strProccessingText);
	$('#divDisableBG').css('display', 'block');
	$('#divProccess').css('display', 'block');
}

function doHideProccessIcon() {
	$('#divDisableBG').css('display', 'none');
	$('#divProccess').css('display', 'none');
}

function getScrollTop() {
	top.window.scrollTo(0,0);
	if ($("#divMainContainer").height()>$(window).height()) {
		$('#divDisableBG').css('height', $("#divMainContainer").css('height'));
		$('#divLoginDisableBG').css('height', $("#divMainContainer").css('height'));
	} else {
		$('#divDisableBG').css('height', '100%');
		$('#divLoginDisableBG').css('height', '100%');
	}
}

function doShowAlertPanel(strTemp, objTemp) {
	getScrollTop();
	objElement = objTemp;
	$('#divAlertText').html(strTemp);
	$('#divDisableBG').css('display', 'block');
	$('#divAlertPanel').css('display', 'block');
}

function doCloseAlertPanel() {
	$('#divDisableBG').css('display', 'none');
	$('#divAlertPanel').css('display', 'none');
	if (objElement!=null && objElement!='') {
		objElement.focus();
	}
}

function doShowDeletePanel(strId, strObj, strName, strPostURL, strReturnURL) {
	getScrollTop();
	strObjId = strId;
	strDelURL = strPostURL;
	strDelRetURL = strReturnURL;
	if (strObj=="Group") {
		strDelConfirmText = "Do you really want to delete the " + strObj + " <b>" + strName + "</b>?<br />All users enrolled under this group<br />will be deleted permanently<br />and the respective user data<br />will be lost.";
	} else {
		strDelConfirmText = "Do you really want to delete the " + strObj + " <b>" + strName + "</b>?";
	}
	$('#divDelConfirmText').html(strDelConfirmText);
	$('#divDisableBG').css('display', 'block');
	$('#divDeletePanel').css('display', 'block');
}

function doCloseDeletePanel() {
	$('#divDeletePanel').css('display', 'none');
	$('#divDisableBG').css('display', 'none');
}

function doSubmitDelete() {
	doCloseDeletePanel();
	doShowProccessIcon();
	$.ajax({
		type: "post",
		url:  strDelURL,
		data: {ID:strObjId}
	}).done(function(responseText) {
		doHideProccessIcon();
		strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
		if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
			document.location.href = strDelRetURL;
		} else {
			doShowAlertPanel(strAjaxReturnTrimed, '');
		}
	});
}

function doCancel(strReturnURL) {
	document.location.href = strReturnURL;;
}

function doUpdateUserReportFilter(strTemp, strUpdateURL, strReturnURL) {
	doShowProccessIcon();
	$.ajax({
		type: "post",
		url: strUpdateURL,
		data: {UserRole:strTemp}
	}).done(function(responseText) {
		doHideProccessIcon();
		strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
		if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
			document.location.href = strReturnURL;
		} else {
			doShowAlertPanel(strAjaxReturnTrimed, '');
		}
	});
}

function doShowGroupsFilterByManager() {
	doShowProccessIcon();
	$("#ddGroup").empty();
	document.frmFilter.ddGroup.options[document.frmFilter.ddGroup.options.length] = new Option("--Select the Group--", "");
	strTempGroups = "";
	if (strTempGroups=="") strTempGroups = "NoGroups";
	$.ajax({
		type: "post",
		url: "elms_filter_get_assigned_manager_groups.php",
		data: {UserId:document.frmFilter.ddManager.value}
	}).done(function(responseText) {
		doHideProccessIcon();
		var strTempReturnVal, arrTempSplGC, arrTempGroups, arrTempCourses, arrTemp;
		strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
		strTempReturnVal = strAjaxReturnTrimed;
		if (strTempReturnVal!="NoGroups") {
			arrTempGroups = strTempReturnVal.split("ELMS_SPL");
			for (i=0; i<arrTempGroups.length; i++) {
				arrTemp = arrTempGroups[i].split("~");
				document.frmFilter.ddGroup.options[document.frmFilter.ddGroup.options.length] = new Option(arrTemp[1], arrTemp[0]);
			}
		}
	});
}

function doPutStatusVal(objThis, strTempVal) {
	document.frmMain.rdStatusA.checked = false;
	document.frmMain.rdStatusI.checked = false;
	objThis.checked = true;
	document.frmMain.txtStatus.value = strTempVal;
}

function doPutUserType(objThis, strTempVal) {
	document.frmMain.rdUIO.checked = false;
	document.frmMain.rdUEO.checked = false;
	document.frmMain.rdUBoth.checked = false;
	objThis.checked = true;
	document.frmMain.txtUserType.value = strTempVal;
	if (strTempVal=="InternalOnly") {
		$("#divInternalMemList").css('display', 'block');
		$("#divExternalMemList").css('display', 'none');
		$("#divInternalAndExternalMemList").css('display', 'none');
		$("#divOffer").css('display', 'none');
	} else {
	if (strTempVal=="ExternalOnly") {
		$("#divInternalMemList").css('display', 'none');
		$("#divExternalMemList").css('display', 'block');
		$("#divInternalAndExternalMemList").css('display', 'none');
		$("#divOffer").css('display', 'block');
	} else {	
		$("#divInternalMemList").css('display', 'none');
		$("#divExternalMemList").css('display', 'none');
		$("#divInternalAndExternalMemList").css('display', 'block');
		$("#divOffer").css('display', 'block');
	} }	
}

function doPutOfferType(objThis, strTempVal) {
	document.frmMain.rdFree.checked = false;
	document.frmMain.rdNoFree.checked = false;
	objThis.checked = true;
	document.frmMain.txtOfferType.value = strTempVal;
	if (strTempVal=="Y") {
		$("#divCourseSubInfo").css('display', 'none');
	} else {
		$("#divCourseSubInfo").css('display', 'block');
	}
}

function doPutCertificateYN(objThis, strTempVal) {
	document.frmMain.rdCertY.checked = false;
	document.frmMain.rdCertN.checked = false;
	objThis.checked = true;
	document.frmMain.txtCertYN.value = strTempVal;
}

function doEnableNewCategory() {
	if (document.frmMain.ddCat.value=="") {
		document.frmMain.txtCat.value = "";
		$("#txtCat").removeAttr("readonly");
	} else {
		document.frmMain.txtCat.value = document.frmMain.ddCat.options[document.frmMain.ddCat.selectedIndex].text;
		$("#txtCat").attr("readonly", "readonly");
	}
}

function doImgMouseOver(objImage) {
	var img=objImage;
	img.imgRolln=img.src;
	img.src=img.lowsrc?img.lowsrc:img.getAttribute?img.getAttribute('lowsrc'):img.src;
}

function doImgMouseOut(objImage) {
	var img=objImage;
	img.src=img.imgRolln;
}

function doSetBottom() {
	if ($("#divMainContainer").height()>$(window).height()) {
		$("#divBottomPanel").css('position', 'relative');
	} else {
		$("#divBottomPanel").css('position', 'fixed');
		$("#divBottomPanel").css('bottom', '0px');
	}
}
$( document ).ready(function() {
	$("#divDisableBG").css('display', 'none');
	$("#divLoginDisableBG").css('display', 'none');
	$("#divProccess").html(strProccessingText);
	$("#divProccess").css('display', 'none');
	$("#divDeletePanel").css('display', 'none');
	$("#divAlertPanel").css('display', 'none');
	$("#divAddNewsMBPanel").css('display', 'none');
	doSetBottom();
});