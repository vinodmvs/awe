<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	
	$varUserTitle = "Mr.";
	$varUserHead = "";
	$varUserRole = "";
	$varUserType = "";
	$varUserEmail = "";
	$varUserLogin = "";
	$varUserPass = "";
	$varUserFname = "";
	$varUserLname = "";
	$varUserDOB = "";
	$varUserPhone = "";
	$varUserStatus = "";
	$varUserProfilePic = "user_profile_default.png";
	$varUserCreated = date('Y-m-d');
	$varUserTheme = "blue";
	$varUserMUPer = "N";
	$varUserMGPer = "N";
	$varUserGroups = "";
	$varUserMemType = "";
	$varAssignCourse = "No";

	if (!isset($_POST["txtFName"])) {
		header("Location:elms_login.php");
	} else {
		$varUserEmail = strtolower($_POST["txtEmail"]);
		$tempQuery = "SELECT * FROM elms_user_details WHERE user_email='" . $varUserEmail . "'";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		if (dbNumRows($tempResult)>0) {
			$strMessage = "The entered E-mail id already exists. Please enter another E-mail id.";
		} else {
			$tQuery = "SELECT current_id FROM elms_temp_inc";
			$tResult = mysql_query($tQuery) or die (mysql_error());
			$tRow = mysql_fetch_array($tResult);
			$varTempInc = $tRow["current_id"];
			$tQuery = "UPDATE elms_temp_inc SET current_id=" . ($varTempInc + 1);
			$tResult = mysql_query($tQuery) or die (mysql_error());

			$varUserTitle = $_POST["ddUserTitle"];
			$varUserType = $_POST["ddUserIEType"];
			$varUserRole = $_POST["ddUserType"];
			$varUserHead = $_POST["ddManager"];
			$varUserLogin = $varUserEmail;
			$varArrTempPass = explode("@", $varUserLogin);
			$varUserPass = $varArrTempPass[0];
			$varUserFname = str_replace("'", "\\'", $_POST["txtFName"]);
			$varUserLname = str_replace("'", "\\'", $_POST["txtLName"]);
			$varUserDOB = $_POST["txtDOB"];
			$varUserPhone = $_POST["txtPhone"];
			$varUserStatus = $_POST["txtStatus"];
			$varUserMemType = $_POST["ddUserMemType"];
			if (isset($_POST["chkMGPer"]) && $_POST["chkMGPer"]!="") {
				$varUserMGPer = $_POST["chkMGPer"];
			}
			if (isset($_POST["chkMUPer"]) && $_POST["chkMUPer"]!="") {
				$varUserMUPer = $_POST["chkMUPer"];
			}
			
			if (isset($_POST["lstGroupsAssigned"])) {
				$varUserGroups = $_POST["lstGroupsAssigned"];
			}
			
			$tempQuery = "INSERT INTO elms_user_details(user_title,user_head,user_role,user_type,user_email,user_login,user_pass,user_fname,user_lname,user_dob,user_phone,user_status,user_profile_pic,user_created,user_theme,user_mu_per,user_mg_per,user_mem_type,user_reg_type)";
			$tempQuery .= " VALUES('" . $varUserTitle . "'," . $varUserHead . ",'" . $varUserRole . "','" . $varUserType . "','" . $varUserEmail . "','" . $varUserLogin . "','" . $varUserPass . "','" . $varUserFname . "','" . $varUserLname . "','" . $varUserDOB . "','" . $varUserPhone . "','" . $varUserStatus . "','" . $varUserProfilePic . "','" . $varUserCreated . "','" . $varUserTheme . "','" . $varUserMUPer . "','" . $varUserMGPer . "'," . $varUserMemType . ",1)";
			$tempResult = mysql_query($tempQuery) or die (mysql_error());
			if (!$tempResult) {
				$strMessage = "Unfortunately the system could not update the User details. Please try again.";
			} else {
				$varTempUserId = dbInsertId();
				/* Assigning Groups and Courses */
				/* Assigning Groups with Courses */
				if ($varUserGroups!=null && $varUserGroups!="") {
					$arrTemp = $varUserGroups;
					for ($i=0; $i<count($arrTemp); $i++) {
						$tQuery = "SELECT * FROM elms_group_details WHERE group_id=" . $arrTemp[$i];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$tempQuery = "INSERT INTO elms_assigned_groups(user_id,group_id,group_name,assigned_date) VALUES(" . $varTempUserId . "," . $tRow["group_id"] . ",'" . $tRow["group_name"] . "','" . $varUserCreated . "')";
						$tempResult = mysql_query($tempQuery) or die (mysql_error());
						if ($varUserRole=="Manager") {
							$tempQuery = "UPDATE elms_group_details SET group_assigned='Y' WHERE group_id=" . $tRow["group_id"];
							$tempResult = mysql_query($tempQuery) or die (mysql_error());

							$strTQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $arrTemp[$i] . " AND user_id<>" . $varTempUserId . " AND user_id<>" . $_SESSION["Elms_LoggedInId"];
							$strTResult = mysql_query($strTQuery) or die (mysql_error());
							while ($strTRow = mysql_fetch_array($strTResult)) {
								$strTQuery = "UPDATE elms_user_details SET user_head=" . $varTempUserId . " WHERE user_id=" . $strTRow["user_id"];
								$strTUpdateResult = mysql_query($strTQuery) or die (mysql_error());
							}
						}

						/*$tAssignCourse = "SELECT course_id, course_name FROM elms_assigned_courses_group_wise WHERE group_id=" . $tRow["group_id"];
						$tAssignResult = mysql_query($tAssignCourse) or die (mysql_error());
						while ($tAssignRow = mysql_fetch_array($tAssignResult)) {
							$tCheckQuery = "SELECT ELMSUD.user_mem_type, ELMSCD.course_id, ELMSCD.course_mem_type FROM elms_user_details ELMSUD INNER JOIN elms_course_details ELMSCD ON ELMSCD.course_mem_type RLIKE CONCAT(  '[[:<:]]', ELMSUD.user_mem_type,  '[[:>:]]' ) WHERE ELMSCD.course_id=" . $tAssignRow["course_id"] . " AND ELMSUD.user_id=" . $varTempUserId;
							$tCheckResult = mysql_query($tCheckQuery) or die (mysql_error());

							$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tAssignRow["course_id"];
							$tDelResult = mysql_query($tDelQuery) or die (mysql_error());							
							if (dbNumRows($tCheckResult)>0) {
								$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tAssignRow["course_id"] . ",'" . $tAssignRow["course_name"] . "','" . $varUserCreated . "')";
								$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
							}
						}*/
					}
				}
				
				/* Assigning Courses */
				if ($varAssignCourse=="Yes") {
					$tQuery = "SELECT * FROM elms_course_details";
					$tChkResult = mysql_query($tQuery) or die (mysql_error());
					while ($tChkRow = mysql_fetch_array($tChkResult)) {
						if ($tChkRow["course_mem_type"]=="N/A" || $tChkRow["course_mem_type"]=="") {
							if ($tChkRow["course_for"]=="InternalOnly") {
								if ($varUserType=="Internal") {
									$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
									
									$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
											
									$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "','A')";
									$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());							
								}
							} else {
							if ($tChkRow["course_for"]=="ExternalOnly") {
								if ($varUserType=="External" && $tChkRow["course_isfree"]=="Y") {
									$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
									
									$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
											
									$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "','A')";
									$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());							
								}
							} else {
								if ($varUserType=="Internal") {
									$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
									
									$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
									$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
											
									$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "','A')";
									$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());							
								} else {
									if ($tChkRow["course_isfree"]=="Y") {
										$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
										$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
												
										$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "','A')";
										$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
									}							
								}							
							} }			
						} else {
							$varMemTypeFound = "No";
							$varTempMemSpl = explode("~", $tChkRow["course_mem_type"]);
							for ($k=0; $k<count($varTempMemSpl); $k++) {
								if ($varUserMemType==$varTempMemSpl[$k]) {
									$varMemTypeFound = "Yes";
									break;
								}
							}
							if ($varMemTypeFound=="Yes") {
								$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
								$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
								
								$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tChkRow["course_id"];
								$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
								$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varTempUserId . "," . $tChkRow["course_id"] . ",'" . str_replace("'", "\\'", $tChkRow["course_name"]) . "','" . $varUserCreated . "','A')";
								$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());						
							}
						}
					}
				}
				/* Assigning Groups and Courses */
			
				$varImageBasePath = "http://demo.mvslms.com/";
				$varLogoHTML = '<img src="' . $varImageBasePath . 'images/logo.png" />';
				$varTodayDate = date('d-m-Y');				
			
				$varLoginDetailsHTML = "";
				$varLoginDetailsHTML .= '<table width="350" cellspacing="0" cellpadding="0" border="0">';
					$varLoginDetailsHTML .= '<tr>';
						$varLoginDetailsHTML .= '<td width="100%" align="left">';
							$varLoginDetailsHTML .= '<div id="divPrintArea" name="divPrintArea" style="border:1px solid #cccccc;">';
								$varLoginDetailsHTML .= '<table width="100%" cellspacing="1" cellpadding="2" bgcolor="#e4e4e4">';
									$varLoginDetailsHTML .= '<tr style="background:#04548f; height:35px; font-family:arial; color:#ffffff; font-size:12px; font-weight:normal; text-align:center; vertical-align:middle;">';
										$varLoginDetailsHTML .= '<td width="60%" align="left">';
											$varLoginDetailsHTML .= 'Login Id';
										$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '<td width="40%" align="left">';
											$varLoginDetailsHTML .= 'Password';
										$varLoginDetailsHTML .= '</td>';
									$varLoginDetailsHTML .= '</tr>';
									$varLoginDetailsHTML .= '<tr style="background:#eaffea; height:25px; font-family:arial; color:#000000; font-size:11px; font-weight:normal; text-align:left; vertical-align:middle;">';
										$varLoginDetailsHTML .= '<td width="60%" align="left" valign="middle">';
											$varLoginDetailsHTML .= $varUserLogin;
										$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '<td width="40%" align="left" valign="middle">';
											$varLoginDetailsHTML .= $varUserPass;
										$varLoginDetailsHTML .= '</td>';
									$varLoginDetailsHTML .= '</tr>';
								$varLoginDetailsHTML .= '</table>';
							$varLoginDetailsHTML .= '</div>';
						$varLoginDetailsHTML .= '</td>';
					$varLoginDetailsHTML .= '</tr>';
				$varLoginDetailsHTML .= '</table>';

				$varSubject = "MVSLMS: New User Registration Login Details";
				$varMessage = <<<EOF
<html>
	<head></head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<table width="100%" cellspacing="0" cellpadding="0" bordercolor="#004080" border="5">
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%" align="left" valign="center">
									$varLogoHTML
								</td>
							</tr>
							<tr height="5" bgcolor="#ffcc00">
								<td></td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
							<tr>
								<td width="100%" align="center" valign="top">
									<table width="98%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="100%" align="right" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Date: $varTodayDate</b>
												</font>
											</td>
										</tr>
										<tr height="5">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Dear $varUserTitle $varUserFname,</b>
												</font>
												<br /><br />
												<font face="arial" size="2" color="#000000">
													Thank you for registering at <a href="http://www.mvslms.com" target="_blank">www.mvslms.com</a>. It is our immense pleasure to welcome you to the MVSLMS Family.
													<br /><br />
													$varLoginDetailsHTML
													<br /><br />
													Should you encounter any problems, have questions or comments, please email us at: mvssoftech@gmail.com
													<br /><br />
													Happy Learning!!
													<br /><br />
													Regards,
													<br /><br />
													MVSLMS
													<br />
													<a href="http://www.mvslms.com" target="_blank">www.mvslms.com</a>
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>
EOF;
				$varEmailTo = $varUserEmail;
				$varEmailFrom = "";
				$varEmailFromName = "";
				$tQuery = "SELECT company_name, company_reply_email FROM elms_branding_details";
				$tResult = mysql_query($tQuery) or die (mysql_error());
				if ($tRow = mysql_fetch_array($tResult)) {
					$varEmailFrom = $tRow["company_reply_email"];
					$varEmailFromName = $tRow["company_name"];
				}
				$varEmailFromName = "MVSLMS";
				$mail = new PHPMailer();
				$mail->From = $varEmailFrom;
				$mail->FromName = $varEmailFromName;
				$mail->AddAddress($varEmailTo, $varUserFname);
				$mail->AddCC($varEmailFrom, $varEmailFromName);
				$mail->AddReplyTo($varEmailFrom, $varEmailFromName);
				$mail->IsHTML(true);
				$mail->Subject = $varSubject;
				$mail->Body = $varMessage;
				$mail->AltBody = "Here is your Login details.";

				if($varEmailFrom!="" && $mail->Send()) {
					$strMessage = "ELMS_SUCCESS";
				} else {
					$strMessage = "Unfortunately the system could not send an email to recipient.";
				}
			}
		}
		echo $strMessage;
	}
?>