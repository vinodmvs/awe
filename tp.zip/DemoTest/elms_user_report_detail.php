<?php
	require("elms_top_includes.php");
?>

<?php
	$varID = "";
	if (!isset($_POST["txtUserId"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["txtUserId"];
		$tempQuery = "SELECT * FROM elms_user_details WHERE user_id=" . $varID;
		$userResult = mysql_query($tempQuery) or die (mysql_error());
		$userRow = mysql_fetch_array($userResult);
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doConvertPDF() {
				document.frmPDF.txtData.value = document.getElementById('divPrintData').innerHTML;
				document.frmPDF.action = "elms_user_report_detail_print.php";
				document.frmPDF.submit();
			}			
		</script>		
	</head>
	<body>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td width="60%">
																				<div style="display:inline-block;">
																					<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_statistic_report.php';">Statistic Reports</div>
																					<div class="clsRoleSubLinkSelected" onclick="javascript:document.location.href='elms_user_report.php';">User Reports</div>
																					<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_course_report.php';">Course Reports</div>
																				</div>
																			</td>
																			<td width="40%" align="right">
																				<input type="button" value="Print / Download" class="clsActionButton" onclick="javascript:doConvertPDF();" />
																				<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_user_report.php');" />
																			</td>
																		</tr>
																	</table>
																</td>
															</tr>
															<tr height="25">
																<td>
																</td>
															</tr>
															<tr>
																<td width="100%" align="left" valign="top">
																	<div id="divPrintData" name="divPrintData" style="text-align:center;">
																		<table width="99.5%" align="center" cellspacing="0" cellpadding="0" style="border:1px solid #cccccc;">
																			<tr class="clsTableSingleRowHeadingText">
																				<td width="100%" align="center">
																					Comprehensive User Report
																				</td>
																			</tr>

																			<tr>
																				<td width="100%" align="center" valign="top">
																					<table width="98%" cellspacing="0" cellpadding="2">
																						<tr height="10">
																							<td></td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="middle">
																								<table width="100%">
																									<tr>
																										<td width="100%">
																											<table width="100%" cellspacing="0" cellpadding="2">
																												<tr>
																													<td width="49%" align="left" valign="top">
																														<table width="100%" cellspacing="0" cellpadding="0" border="0">
																															<tr height="25">
																																<td width="18%" align="left" valign="top">
																																	<b>Name</b>
																																</td>
																																<td width="82%" align="left" valign="top">
																																	<b>:</b>&nbsp;&nbsp;<?php echo $userRow["user_fname"] . " " . $userRow["user_lname"]; ?>
																																</td>																																
																															</tr>
																															<tr height="25">
																																<td width="18%" align="left" valign="top">
																																	<b>Membership</b>
																																</td>
																																<td width="82%" align="left" valign="top">
																																	<b>:</b>&nbsp;
																																	<?php 
																																		$tQuery = "SELECT mem_name FROM elms_membership_details WHERE mem_id=" . $userRow["user_mem_type"];
																																		$tResult = mysql_query($tQuery) or die (mysql_error());
																																		$tRow = mysql_fetch_array($tResult) or die (mysql_error());
																																		echo $tRow["mem_name"]; 
																																	?>
																																</td>																																
																															</tr>
																															<tr height="25">
																																<td width="18%" align="left" valign="top">
																																	<b>E-mail Id</b>
																																</td>
																																<td width="82%" align="left" valign="top">
																																	<b>:</b>&nbsp;&nbsp;<?php echo $userRow["user_email"]; ?>
																																</td>																																
																															</tr>
																															<tr height="25">
																																<td width="18%" align="left" valign="top">
																																	<b>Mobile</b>
																																</td>
																																<td width="82%" align="left" valign="top">
																																	<b>:</b>&nbsp;&nbsp;<?php echo $userRow["user_phone"]; ?>
																																</td>																																
																															</tr>
																														</table>
																													</td>
																													<td width="2%">
																													</td>	
																													<td width="49%" align="left" valign="top">
																														<table width="100%" cellspacing="0" cellpadding="0" border="0">
																															<tr height="25">
																																<td width="25%" align="left" valign="top">
																																	<b>Role</b>
																																</td>
																																<td width="75%" align="left" valign="top">
																																	<b>:</b>&nbsp;&nbsp;<?php echo $userRow["user_role"]; ?>
																																</td>																																
																															</tr>
																															<tr height="25">
																																<td width="25%" align="left" valign="top">
																																	<b>Reporting To</b>
																																</td>
																																<td width="75%" align="left" valign="top">
																																	<b>:</b>&nbsp;
																																	<?php 
																																		$tQuery = "SELECT user_fname, user_lname FROM elms_user_details WHERE user_id=" . $userRow["user_head"];
																																		$tResult = mysql_query($tQuery) or die (mysql_error());
																																		$tRow = mysql_fetch_array($tResult) or die (mysql_error());
																																	?>
																																	<?php echo $tRow["user_fname"] . " " . $tRow["user_lname"]; ?>
																																</td>																																
																															</tr>
																															<tr height="25">
																																<td width="25%" align="left" valign="top">
																																	<b>Enrolled Date</b>
																																</td>
																																<td width="75%" align="left" valign="top">
																																	<b>:</b>&nbsp;
																																	<?php
																																		if ($userRow["user_created"]=="-" || $userRow["user_created"]=="") {
																																			echo $userRow["user_created"];
																																		} else {
																																			$varTempDate = new DateTime($userRow["user_created"]);
																																			echo $varTempDate->format("d-M-Y");
																																		}																															
																																	?>
																																</td>																																
																															</tr>
																															<tr height="25">
																																<td width="25%" align="left" valign="top">
																																	<b>Status</b>
																																</td>
																																<td width="75%" align="left" valign="top">
																																	<b>:</b>&nbsp;
																																	<?php
																																		$strStatus = "";
																																		if ($userRow["user_status"]=="A") {
																																			$strStatus = "Active";
																																		} else {
																																			$strStatus = "Inactive";
																																		}
																																		echo $strStatus;
																																	?>
																																</td>																																
																															</tr>
																														</table>																													
																													</td>																													
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>

																							</td>
																						</tr>
																						<tr height="25">
																							<td></td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="middle">
																								<b>Groups Details</b>
																								<?php
																									$tQuery = "SELECT ELMSAG.group_name, ELMSGD.group_desc, ELMSGD.group_status, ELMSGD.group_created FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $varID . " ORDER BY ELMSGD.group_name";
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																								?>
																								<?php
																									if (dbNumRows($tResult)<=0) {
																								?>
																									<div class="clsSingleBorder">
																										There is no Group details for this User.
																									</div>
																								<?php
																									} else {
																								?>
																									<div class="clsSingleBorder">
																										<table width="100%" cellspacing="1" cellpadding="2">
																											<tr class="clsTableRowHeadingText">
																												<td width="4%">
																													#
																												</td>
																												<td width="73%">
																													Name
																												</td>
																												<td width="10%">
																													Status
																												</td>
																												<td width="13%">
																													Assigned Date
																												</td>
																											</tr>
																											<?php
																												$intTempInc = 0;
																												$strColorFilled = "No";
																												while ($tRow = mysql_fetch_array($tResult)) {
																													$intTempInc++;
																											?>
																											<?php
																												if ($strColorFilled=="No") {
																													$strColorFilled = "Yes";

																											?>
																												<tr class="clsAlternateFColor">
																											<?php
																												} else {
																													$strColorFilled = "No";

																											?>
																												<tr class="clsAlternateSColor">
																											<?php
																												}
																											?>
																													<td width="4%">
																														<?php echo $intTempInc; ?>
																													</td>
																													<td width="73%">
																														<?php echo $tRow["group_name"]; ?>
																													</td>
																													<td width="10%">
																														<?php
																															if ($tRow["group_status"]=="A") {
																																echo "Active";
																															} else {
																																echo "Inactive";
																															}
																														?>
																													</td>
																													<td width="13%">
																														<?php 
																															if ($tRow["group_created"]=="-" || $tRow["group_created"]=="") {
																																echo $tRow["group_created"];
																															} else {
																																$varTempDate = new DateTime($tRow["group_created"]);
																																echo $varTempDate->format("d-M-Y");
																															}																														
																														?>
																													</td>
																												</tr>
																											<?php } ?>
																										</table>
																									</div>
																								<?php
																									}
																								?>
																							</td>
																						</tr>
																						<tr height="25">
																							<td></td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="middle">
																								<b>Courses Details</b>
																								<?php
																									$tQuery = "SELECT course_id, course_name, assigned_date FROM elms_assigned_courses WHERE user_id=" . $varID . " ORDER BY course_name";
																									$tCourse = mysql_query($tQuery) or die (mysql_error());
																								?>
																								<?php
																									if (dbNumRows($tCourse)<=0) {
																								?>
																									<div class="clsSingleBorder">
																										There is no Course details for this User.
																									</div>
																								<?php
																									} else {
																								?>																								
																									<div class="clsSingleBorder">
																										<table width="100%" cellspacing="1" cellpadding="2">
																											<tr class="clsTableRowHeadingText">
																												<td width="4%">
																													#
																												</td>
																												<?php
																													if ($userRow["user_role"]=="User") {
																												?>
																													<td width="26%">
																														Name
																													</td>
																													<td width="9%">
																														Status
																													</td>
																													<td width="10%">
																														Time Spent
																													</td>
																													<td width="9%">
																														Total Attempts
																													</td>
																													<td width="9%">
																														Started On
																													</td>
																													<td width="11%">
																														Completed On
																													</td>
																													<td width="11%">
																														Last Accessed On
																													</td>
																													<td width="11%">
																														Certification
																													</td>
																												<?php
																													} else {
																												?>
																													<td width="85%">
																														Name
																													</td>
																													<td width="13%">
																														Assigned Date
																													</td>
																												<?php
																													}
																												?>
																												
																											</tr>
																											<?php
																												$intTempInc = 0;
																												$strColorFilled = "No";
																												while ($rowCourse = mysql_fetch_array($tCourse)) {
																													$intTempInc++;
																											?>
																											<?php
																												if ($strColorFilled=="No") {
																													$strColorFilled = "Yes";

																											?>
																												<tr class="clsAlternateFColor">
																											<?php
																												} else {
																													$strColorFilled = "No";

																											?>
																												<tr class="clsAlternateSColor">
																											<?php
																												}
																											?>
																													<td width="4%">
																														<?php echo $intTempInc; ?>
																													</td>
																													<?php
																														if ($userRow["user_role"]=="User") {
																													?>
																														<td width="26%">
																															<?php echo $rowCourse["course_name"]; ?>
																														</td>
																														<?php
																															$varTempStatus = "-";
																															$varTempTimeSpent = "-";
																															$varTempAttempts = "-";
																															$varTempSD = "-";
																															$varTempCD = "-";
																															$varTempLAD = "-";
																															$varTempCert = "-";
																															$tQuery = "SELECT status,total_time,course_num_attempts,course_started_date,course_completed_date,course_last_accessed_date,course_certificate_sent FROM elms_course_scorm_track WHERE course_id=" . $rowCourse["course_id"] . " AND user_id=" . $varID;
																															$tResult = mysql_query($tQuery) or die (mysql_error());
																															if (dbNumRows($tResult)<=0) {
																																$varTempStatus = "Not Started";
																															} else {
																																$tRow = mysql_fetch_array($tResult);
																																$varTempStatus = $tRow["status"];
																																$varTempTimeSpent = $tRow["total_time"];
																																$varTempAttempts = $tRow["course_num_attempts"];
																																$varTempSD = $tRow["course_started_date"];
																																$varTempCD = $tRow["course_completed_date"];
																																$varTempLAD = $tRow["course_last_accessed_date"];
																																$varTempCert = $tRow["course_certificate_sent"];
																																
																																if (strtoupper($varTempStatus)=="NOT ATTEMPTED") {
																																	$varTempStatus = "Not Started";
																																} else {
																																if (strtoupper($varTempStatus)=="COMPLETED" || strtoupper($varTempStatus)=="PASSED") {
																																	$varTempStatus = "Completed";
																																} else {
																																	$varTempStatus = "In Progress";
																																} }
																															}
																														?>																														
																														<td width="9%">
																															<?php echo $varTempStatus; ?>
																														</td>
																														<td width="10%">
																															<?php
																																if ((int)$varTempTimeSpent<=0) {
																																	$varTempDisplay = "-";
																																} else {
																																	$varTempDisplay = gmdate("H:i:s", $varTempTimeSpent);
																																}
																																echo $varTempDisplay;
																															?>
																														</td>
																														<td width="9%">
																															<?php echo $varTempAttempts; ?>
																														</td>
																														<td width="9%">
																															<?php 
																																if ($varTempSD=="-" || $varTempSD=="") {
																																	echo "-";
																																} else {
																																	$varTempDate = new DateTime($varTempSD);
																																	echo $varTempDate->format("d-M-Y");
																																}																														
																															?>
																														</td>
																														<td width="11%">
																															<?php 
																																if ($varTempCD=="-" || $varTempCD=="") {
																																	echo "-";
																																} else {
																																	$varTempDate = new DateTime($varTempCD);
																																	echo $varTempDate->format("d-M-Y");
																																}																														
																															?>
																														</td>
																														<td width="11%">
																															<?php
																																if ($varTempLAD=="-" || $varTempLAD=="") {
																																	echo "-";
																																} else {
																																	$varTempDate = new DateTime($varTempLAD);
																																	echo $varTempDate->format("d-M-Y");
																																}																														
																															?>
																														</td>
																														<td width="11%">
																															<?php
																																if ($varTempCert=="-" || $varTempCert=="N") {
																																	echo "-";
																																} else {
																																	echo "Issued";
																																}
																															?>
																														</td>
																													<?php
																														} else {
																													?>
																														<td width="85%">
																															<?php echo $rowCourse["course_name"]; ?>
																														</td>
																														<td width="13%">
																															<?php 
																																if ($rowCourse["assigned_date"]=="-" || $rowCourse["assigned_date"]=="") {
																																	echo "-";
																																} else {
																																	$varTempDate = new DateTime($rowCourse["assigned_date"]);
																																	echo $varTempDate->format("d-M-Y");
																																}																														
																															?>	
																														</td>
																													<?php
																														}
																													?>
																												</tr>
																											<?php } ?>
																										</table>
																									</div>
																								<?php
																									}
																								?>
																							</td>
																						</tr>
																						<tr height="25">
																							<td></td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="middle">
																								<b>Attendance Details</b>
																								<?php
																									$tQuery = "SELECT * FROM elms_login_logout_details WHERE user_id=" . $varID;
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																								?>
																								<?php
																									if (dbNumRows($tResult)<=0) {
																								?>
																									<div class="clsSingleBorder">
																										There is no Attendance details for this User.
																									</div>
																								<?php
																									} else {
																								?>																								
																									<div class="clsSingleBorder">
																										<table width="100%" cellspacing="1" cellpadding="2">
																											<tr class="clsTableRowHeadingText">
																												<td width="4%">
																													#
																												</td>
																												<td width="17%">
																													Login Date
																												</td>
																												<td width="17%">
																													Login Time
																												</td>
																												<td width="17%">
																													Logout Date
																												</td>
																												<td width="17%">
																													Logout Time
																												</td>
																												<td width="10%">
																													Time Spent
																												</td>
																											</tr>
																											<?php
																												$intTempInc = 0;
																												$strColorFilled = "No";
																												while ($tRow = mysql_fetch_array($tResult)) {
																													$intTempInc++;
																											?>
																											<?php
																												if ($strColorFilled=="No") {
																													$strColorFilled = "Yes";

																											?>
																												<tr class="clsAlternateFColor">
																											<?php
																												} else {
																													$strColorFilled = "No";

																											?>
																												<tr class="clsAlternateSColor">
																											<?php
																												}
																											?>
																													<td width="4%">
																														<?php echo $intTempInc; ?>
																													</td>
																													<?php
																														if ($tRow["login_dt"]=="-" || $tRow["login_dt"]=="") {
																															echo $tRow["login_dt"];
																													?>
																															<td width="17%">
																																-
																															</td>																													
																															<td width="17%">
																																-
																															</td>																												
																													<?php
																														} else {
																													?>
																													<?php
																															$varTempDisplayDate = explode(" ", $tRow["login_dt"]);
																															$varTempDate = new DateTime($varTempDisplayDate[0]);
																													?>
																															<td width="17%">
																																<?php echo $varTempDate->format("d-M-Y"); ?>
																															</td>																													
																															<td width="17%">
																																<?php echo $varTempDisplayDate[1]; ?>
																															</td>
																													<?php
																														}																													
																													?>
																													
																													<?php
																														if ($tRow["logout_dt"]=="-" || $tRow["logout_dt"]=="") {
																													?>
																															<td width="17%">
																																-
																															</td>																													
																															<td width="17%">
																																-
																															</td>																												
																													<?php
																														} else {
																													?>
																													<?php
																															$varTempDisplayDate = explode(" ", $tRow["logout_dt"]);
																															$varTempDate = new DateTime($varTempDisplayDate[0]);
																													?>
																															<td width="17%">
																																<?php echo $varTempDate->format("d-M-Y"); ?>
																															</td>																													
																															<td width="17%">
																																<?php echo $varTempDisplayDate[1]; ?>
																															</td>
																													<?php
																														}																													
																													?>																												
																													<td width="10%">
																														<?php
																															echo doGetDateTimeDiff($tRow["logout_dt"], $tRow["login_dt"], "T");
																														?>
																													</td>
																												</tr>
																											<?php } ?>
																										</table>
																									</div>
																								<?php
																									}
																								?>
																							</td>
																						</tr>
																						<tr height="10">
																							<td></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																	</div>
																</td>
															</tr>
															<tr height="10">
																<td>
																</td>
															</tr>
															<tr>
																<td align="right">
																	<input type="button" value="Print / Download" class="clsActionButton" onclick="javascript:doConvertPDF();" />
																	<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_user_report.php');" />
																	<form id="frmPDF" name="frmPDF" method="post" target="_blank">
																		<input type="hidden" id="txtData" name="txtData" value="" />
																	</form>																	
																</td>
															</tr>
															<tr height="10">
																<td>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>