<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varRole = "";
	$varGroup = "";
	$varHead = "";
	$varCoursesEnrolled = "";
	$varRegFDate = "";
	$varRegEDate = "";
	$varLoginFDate = "";
	$varLoginEDate = "";

	if (!isset($_POST["UserRole"])) {
		header("Location:index.php");
	} else {
		$varRole = $_POST["UserRole"];

		$tempQuery = "UPDATE elms_admin_user_report_filter SET user_role='" . $varRole . "',user_group='" . $varGroup . "',user_head='" . $varHead . "',user_course='" . $varCoursesEnrolled . "',user_reg_fdate='" . $varRegFDate . "',user_reg_edate='" . $varRegEDate . "',user_login_fdate='" . $varLoginFDate . "',user_login_edate='" . $varLoginEDate . "'";
		$tempResult = mysql_query($tempQuery);

		if ($tempResult) {
			$strMessage = "ELMS_SUCCESS";
		} else {
			$strMessage = "<b>Error: </b>Error occured while getting the Report Details from the Database.";
		}

		echo $strMessage;
	}
?>