<?php
	require("elms_top_includes.php");
?>

<?php
	$varCourseId = "";
	if (!isset($_POST["txtCourseId"])) {
		header("Location:index.php");
	} else {
		$varCourseId = $_POST["txtCourseId"];
		$varCourseName = "";
		$varCatName = "";
		
		$tempQuery = "SELECT elms_course_details.course_name, elms_course_details.course_cat, elms_category_details.category_id, elms_category_details.category_name ";
		$tempQuery .= "FROM elms_course_details INNER JOIN elms_category_details ON elms_category_details.category_id=elms_course_details.course_cat WHERE elms_course_details.course_id=" . $varCourseId;
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		$tempRow = mysql_fetch_array($tempResult);
		
		$varCourseName = $tempRow["course_name"];
		$varCatName = $tempRow["category_name"];
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script type="text/javascript" src="https://www.google.com/jsapi"></script>
		<script language="javascript">
      		google.load("visualization", "1", {packages:["corechart"]});
      		function drawChart() {
				arrL = document.getElementById('txtArrLData').value.split("~");
				arrC = document.getElementById('txtArrCData').value.split("~");
				var data = new google.visualization.DataTable();
				data.addColumn('string', 'Activity');
				data.addColumn('number', 'Learner');
				data.addColumn({type: 'string', role: 'style'});
				data.addRows(arrL.length);
				for (i=0; i<arrL.length; i++) {
					data.setValue(i, 0, arrL[i]);
					data.setValue(i, 1, arrC[i]);
					switch (i) {
						case 0:
							data.setValue(i, 2, 'color: #49c0f0');
							break;
						case 1:
							data.setValue(i, 2, 'color: #ff0000');
							break;
						case 2:
							data.setValue(i, 2, 'color: #00ff00');
							break;
						case 3:
							data.setValue(i, 2, 'color: #ffff00');
							break;
					}
				}
        		var options = {
          			title: '',
          			is3D: true,
          			legend: { position: "none" },
          			orientation: 'horizontal',
          			vAxis: {title: '',  titleTextStyle: {color: 'red'}}
        		};
        		var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        		chart.draw(data, options);
      		}

			function doGetCourseResult(strId) {
				if (strId=="") {
					doShowAlertPanel("Please select the valid Course.", "");
				} else {
					doShowProccessIcon();
					$.ajax({
						type: "post",
						url:  "elms_course_report_get_course_result.php",
						data: {ID:strId}
					}).done(function(responseText) {
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed=="ELMS_NODATA") {
							$("#chart_div").css('display', 'none');
						} else {
							document.getElementById('txtArrLData').value = strAjaxReturnTrimed.split("ELMS_SPL")[0];
							document.getElementById('txtArrCData').value = strAjaxReturnTrimed.split("ELMS_SPL")[1];
							document.getElementById('txtArrName').value = strAjaxReturnTrimed.split("ELMS_SPL")[2];
							document.getElementById('txtArrResult').value = strAjaxReturnTrimed.split("ELMS_SPL")[3];
							$("#chart_div").css('display', 'block');
							drawChart();
						}
						var arrTempName = document.getElementById('txtArrName').value.split("~");
						if (arrTempName=="") {
							$("#divFilterPanel").css('display', 'none');
							$("#divResultPanel").css('display', 'none');
							$("#divBtnPanel").css('display', 'none');
						} else {
							document.frmFilter.ddGroup.selectedIndex = 0;
							document.frmFilter.ddResult.selectedIndex = 0;
							$("#divFilterPanel").css('display', 'block');
							$("#divResultPanel").css('display', 'block');
							$("#divBtnPanel").css('display', 'block');
							var strColorFilled = "No";
							var arrTempResult = document.getElementById('txtArrResult').value.split("~");
							strResultInnerHTML = '<table cellspacing="0" cellpadding="0" width="100%"><tr><td width="100%" align="center" valign="middle"><table width="100%" cellspacing="1" cellpadding="2" align="center"><tr class="clsTableSingleRowHeadingText"><td width="3%">#</td><td width="49%" align="left">Learner Name</td><td width="48%" align="left">Result</td></tr>';
							for (i=0; i<arrTempName.length; i++) {
								if (strColorFilled=="No") {
									strResultInnerHTML = strResultInnerHTML + '<tr class="clsAlternateFColor"><td width="3%" align="center">' + (i+1) + '</td><td width="49%">' + arrTempName[i] + '</td><td width="48%">' + arrTempResult[i] + '</td></tr>';
									strColorFilled = "Yes";
								} else {
									strResultInnerHTML = strResultInnerHTML + '<tr class="clsAlternateSColor"><td width="3%" align="center">' + (i+1) + '</td><td width="49%">' + arrTempName[i] + '</td><td width="48%">' + arrTempResult[i] + '</td></tr>';
									strColorFilled = "No";
								}
							}
							strResultInnerHTML = strResultInnerHTML + '</table></td></tr></table>';
							$("#divResultPanel").html(strResultInnerHTML);
							$("#divResultPanel").css('display', 'block');
							$("#divBtnPanel").css('display', 'block');
						}
						doSetBottom();
						getScrollTop();
						doHideProccessIcon();
					});
				}
			}

			function doGetCourseResultFilter(strId, strManager, strGroup, strResult, strAction) {
				doShowProccessIcon();
				if (strAction=="Reset") {
					document.frmFilter.ddGroup.selectedIndex = 0;
					document.frmFilter.ddResult.selectedIndex = 0;
					doShowGroupsFilterByManager();
				}
				$.ajax({
					type: "post",
					url:  "elms_course_report_get_course_result_filter.php",
					data: {ID:strId, Manager:strManager, Group:strGroup, Result:strResult}
				}).done(function(responseText) {
					strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
					if (strAjaxReturnTrimed=="ELMS_NODATA") {
						$("#divResultPanel").css('display', 'none');
						$("#divBtnPanel").css('display', 'none');
					} else {
						document.getElementById('txtArrName').value = strAjaxReturnTrimed.split("ELMS_SPL")[0];
						document.getElementById('txtArrResult').value = strAjaxReturnTrimed.split("ELMS_SPL")[1];
						$("#divResultPanel").css('display', 'block');
						$("#divBtnPanel").css('display', 'block');
						var strColorFilled = "No";
						var arrTempName = document.getElementById('txtArrName').value.split("~");
						var arrTempResult = document.getElementById('txtArrResult').value.split("~");
						strResultInnerHTML = '<table cellspacing="0" cellpadding="0" width="100%"><tr><td width="100%" align="center" valign="middle"><table width="100%" cellspacing="1" cellpadding="2" align="center"><tr class="clsTableSingleRowHeadingText"><td width="3%">#</td><td width="49%" align="left">Learner Name</td><td width="48%" align="left">Result</td></tr>';
						for (i=0; i<arrTempName.length; i++) {
							if (strColorFilled=="No") {
								strResultInnerHTML = strResultInnerHTML + '<tr class="clsAlternateFColor"><td width="3%" align="center">' + (i+1) + '</td><td width="49%">' + arrTempName[i] + '</td><td width="48%">' + arrTempResult[i] + '</td></tr>';
								strColorFilled = "Yes";
							} else {
								strResultInnerHTML = strResultInnerHTML + '<tr class="clsAlternateSColor"><td width="3%" align="center">' + (i+1) + '</td><td width="49%">' + arrTempName[i] + '</td><td width="48%">' + arrTempResult[i] + '</td></tr>';
								strColorFilled = "No";
							}
						}
						strResultInnerHTML = strResultInnerHTML + '</table></td></tr></table>';
						$("#divResultPanel").html(strResultInnerHTML);
						$("#divResultPanel").css('display', 'block');
						$("#divBtnPanel").css('display', 'block');
					}
					doSetBottom();
					getScrollTop();
					doHideProccessIcon();
				});
			}

			function doConvertPDF() {
				document.frmPDF.txtData.value = document.getElementById('divResultPanel').innerHTML;
				document.frmPDF.action = "elms_course_report_detail_print.php";
				document.frmPDF.submit();
			}			
		</script>
	</head>
	<?php
		if ($varCourseId=="") {
	?>
			<body>
	<?php
		} else {
	?>
		<body onload="javascript:doGetCourseResult(document.getElementById('ddCourse').value);">
	<?php
		}
	?>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%">
																	<table width="100%" cellspacing="0" cellpadding="0" border="0">
																		<tr>
																			<td width="60%">
																				<div style="display:inline-block;">
																					<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_statistic_report.php';">Statistic Reports</div>
																					<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_user_report.php';">User Reports</div>
																					<div class="clsRoleSubLinkSelected" onclick="javascript:document.location.href='elms_course_report.php';">Course Reports</div>
																				</div>
																			</td>
																			<td width="40%" align="right">
																				<input type="button" value="Print / Download" class="clsActionButton" onclick="javascript:doConvertPDF();" />
																				<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_course_report.php');" />
																			</td>
																		</tr>
																	</table>
																</td>
															</tr>
															<!--
															<tr height="25">
																<td>
																</td>
															</tr>
															<tr>
																<td align="right">
																	Select the Course:
																	<select id="ddCourse" name="ddCourse" size="1" class="clsTextField" style="width:50%;" onchange="javascript:doGetCourseResult(this.value);">
																		<option selected value="">---Select the Course---</option>
																		<?php
																			$tQuery = "SELECT course_id, course_name FROM elms_assigned_courses WHERE user_id=" . $_SESSION["Elms_LoggedInId"];
																			$tResult = mysql_query($tQuery) or die (mysql_error());
																			while ($tRow = mysql_fetch_array($tResult)) {
																		?>
																				<?php if ($varCourseId==$tRow["course_id"]) { ?>
																					<option selected value="<?php echo $tRow["course_id"]; ?>"><?php echo $tRow["course_name"]; ?></option>
																				<?php } else { ?>
																					<option value="<?php echo $tRow["course_id"]; ?>"><?php echo $tRow["course_name"]; ?></option>
																				<?php } ?>
																		<?php
																			}
																		?>
																	</select>																
																</td>
															</tr>
															-->															
															<tr height="25">
																<td>
																</td>
															</tr>
															<tr>
																<td>
																	<font color="red">Note:</font>&nbsp;The system will print only the Result Panel and not the Graph
																</td>
															</tr>															
															<tr height="10">
																<td>
																</td>
															</tr>															
															<tr>
																<td width="100%" align="left" valign="top">
																	<div class="clsSingleBorder">
																		<table width="100%" align="center" cellspacing="0" cellpadding="0">
																			<tr class="clsTableSingleRowHeadingText">
																				<td width="100%">
																					Comprehensive Course Report
																				</td>
																			</tr>
																			<tr height="5">
																				<td></td>
																			</tr>
																			<tr>
																				<td align="center">
																					<b>Course Name:</b>&nbsp;<?php echo $varCourseName; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Course Category:</b>&nbsp;<?php echo $varCatName; ?>
																					<input type="hidden" id="ddCourse" name="ddCourse" value="<?php echo $varCourseId; ?>" />
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="center" valign="middle">
																					<div id="chart_div" style="width: 75%; height: 300px;"></div>
																				</td>
																			</tr>
																			<tr>
																				<td align="center">
																					<div id="divFilterPanel" name="divFilterPanel" style="position:relative; width:70%; display:none;">
																						<fieldset style="padding:5px 5px 5px 5px; border:1px solid #cccccc; text-align:left;">
																							<legend style="position: relative; padding:5px 5px 5px 5px; font-size:12px; top: 0px; left: 0px; color:#000000; border:1px solid #000000;"><b>Filter By</b></legend>
																							<table width="100%">
																								<tr>
																									<td align="center">
																										<table width="100%" cellspacing="5" cellpadding="5">
																											<tr>
																												<td>
																													<form name="frmFilter" id="frmFilter">
																															<input type="hidden" id="ddManager" name="ddManager" value="" />
																															Group:
																															<select id="ddGroup" name="ddGroup" size="1" class="clsTextField" style="width:20%;">
																																<option selected value="">---Select---</option>
																																<?php
																																	$tQuery = "SELECT group_id, group_name FROM elms_assigned_groups WHERE user_id=" . $_SESSION["Elms_LoggedInId"];
																																	$tResult = mysql_query($tQuery) or die (mysql_error());
																																	while ($tRow = mysql_fetch_array($tResult)) {
																																?>
																																		<option value="<?php echo $tRow["group_id"]; ?>"><?php echo $tRow["group_name"]; ?></option>
																																<?php
																																	}
																																?>
																															</select>
																															&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																															Result:
																															<select id="ddResult" name="ddResult" size="1" class="clsTextField" style="width:20%;">
																																<option selected value="">---Select---</option>
																																<option value="COMPLETED">Completed</option>
																																<option value="INCOMPLETE">In Progress</option>
																																<option value="NOTATTEMPTED">Not Started</option>
																															</select>
																															<br /><br />
																															<input type="button" id="btnFinish" name="btnFinish" value="&nbsp;Apply&nbsp;" class="clsActionButton" onclick="javascript:doGetCourseResultFilter(document.getElementById('ddCourse').value, document.frmFilter.ddManager.value, document.frmFilter.ddGroup.value, document.frmFilter.ddResult.value, 'Filter');" />
																															<input type="button" id="btnReset" name="btnReset" value="&nbsp;Reset&nbsp;" class="clsActionButton" onclick="javascript:doGetCourseResultFilter(document.getElementById('ddCourse').value, '', '', '', 'Reset');" />
																													</form>
																												</td>
																											</tr>
																										</table>
																									</td>
																								</tr>
																							</table>
																						</fieldset>
																					</div>
																				</td>
																			</tr>
																			<tr height="25">
																				<td>
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="center">
																					<div id="divResultPanel" name="divResultPanel" class="clsSingleBorder" style="position:relative; text-align:center; width:850px; display:none;">
																					</div>
																				</td>
																			</tr>
																			<tr height="25">
																				<td>
																				</td>
																			</tr>
																		</table>
																	</div>
																</td>
															</tr>
															<tr height="10">
																<td>
																</td>
															</tr>
															<tr>
																<td align="right">
																	<input type="button" value="Print / Download" class="clsActionButton" onclick="javascript:doConvertPDF();" />
																	<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_course_report.php');" />
																	<form id="frmPDF" name="frmPDF" method="post" target="_blank">
																		<input type="hidden" id="txtData" name="txtData" value="" />
																		<input type="hidden" id="txtCourseName" name="txtCourseName" value="<?php echo $varCourseName; ?>" />
																		<input type="hidden" id="txtCourseCat" name="txtCourseCat" value="<?php echo $varCatName; ?>" />
																	</form>																	
																</td>
															</tr>
															<tr height="10">
																<td>
																</td>
															</tr>															
															<input type="hidden" id="txtArrLData" name="txtArrLData" value="" />
															<input type="hidden" id="txtArrCData" name="txtArrCData" value="" />
															<input type="hidden" id="txtArrName" name="txtArrName" value="" />
															<input type="hidden" id="txtArrResult" name="txtArrResult" value="" />
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>