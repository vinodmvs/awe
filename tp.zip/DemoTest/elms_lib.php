<?php
	function showAdminWelcome() {
?>
		<table width="100%" cellspacing="0" cellpadding="0" class="clsWelcomeMsgText">
			<tr>
				<td width="1%">&nbsp;</td>
				<td>
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr height="10">
							<td></td>
						</tr>
						<tr>
							<td width="35%" align="left" valign="middle">
								Welcome <b><?php echo $_SESSION["Elms_LoggedInUserName"]; ?></b>
							</td>
							<td width="2%">
							</td>
							<td width="63%" align="right" valign="middle">
								<?php
									if ($_SESSION["Elms_LoggedInUserType"]=="Admin") {
								?>
										<a href="elms_dash_board.php" class="clsTopLink">Dashboard</a>
										&nbsp;|&nbsp;<a href="elms_membership_list.php" class="clsTopLink">Membership</a>
										&nbsp;|&nbsp;<a href="elms_category_list.php" class="clsTopLink">Course Category</a>
										&nbsp;|&nbsp;<a href="elms_course_catalog.php" class="clsTopLink">Course Catalog</a>
										&nbsp;|&nbsp;<a href="elms_account_details.php" class="clsTopLink">Account</a>
										&nbsp;|&nbsp;<a href="elms_branding_details.php" class="clsTopLink">Branding</a>
								<?php
									} else {
									if ($_SESSION["Elms_LoggedInUserType"]=="Manager") {
								?>
										<a href="elms_course_catalog.php" class="clsTopLink">Course Catalog</a>
								<?php
									} else {
								?>
										<a href="elms_course_catalog.php" class="clsTopLink">Course Catalog</a>
								<?php
									} }
								?>
								<!--&nbsp;|&nbsp;<a href="elms_faq.php" class="clsTopLink" target="_blank">FAQ</a>&nbsp;|&nbsp;<a href="elms_profile.php" class="clsTopLink">Profile</a>&nbsp;|&nbsp;<a href="elms_logout.php" class="clsTopLink">Logout</a>-->
								&nbsp;|&nbsp;<a href="elms_profile.php" class="clsTopLink">Profile</a>&nbsp;|&nbsp;<a href="elms_logout.php" class="clsTopLink">Logout</a>
							</td>
						</tr>
						<tr height="10">
							<td></td>
						</tr>
					</table>
				</td>
				<td width="1%">&nbsp;</td>
			</tr>
		</table>
		<?php
			showRoleMainLinks();
		?>
<?php
	}
?>


<?php
	function showMainLinksNormal() {
?>
		<td>&nbsp;</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMGPer"]=="Y") { ?>
				<a href="elms_group_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/groups_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMUPer"]=="Y") { ?>
				<a href="elms_user_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/users_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInUserType"]=="Admin") { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/courses_link_icon.png" /></a>
			<?php } else { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/mycourses_link_icon.png" /></a>
			<?php } ?>
		</td>
		<?php if ($_SESSION["Elms_LoggedInUserType"]=="User") { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_learner_course_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>
		<?php } else { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_statistic_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>		
		<?php } ?>
<?php
	}
?>

<?php
	function showMainLinksGroupsSelected() {
?>
		<td>&nbsp;</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMGPer"]=="Y") { ?>
				<a href="elms_group_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/groups_link_icon_selected.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMUPer"]=="Y") { ?>
				<a href="elms_user_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/users_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInUserType"]=="Admin") { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/courses_link_icon.png" /></a>
			<?php } else { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/mycourses_link_icon.png" /></a>
			<?php } ?>
		</td>
		<?php if ($_SESSION["Elms_LoggedInUserType"]=="User") { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_learner_course_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>
		<?php } else { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_statistic_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>		
		<?php } ?>
<?php
	}
?>

<?php
	function showMainLinksUsersSelected() {
?>
		<td>&nbsp;</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMGPer"]=="Y") { ?>
				<a href="elms_group_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/groups_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMUPer"]=="Y") { ?>
				<a href="elms_user_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/users_link_icon_selected.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInUserType"]=="Admin") { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/courses_link_icon.png" /></a>
			<?php } else { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/mycourses_link_icon.png" /></a>
			<?php } ?>
		</td>
		<?php if ($_SESSION["Elms_LoggedInUserType"]=="User") { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_learner_course_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>
		<?php } else { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_statistic_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>		
		<?php } ?>
<?php
	}
?>

<?php
	function showMainLinksCoursesSelected() {
?>
		<td>&nbsp;</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMGPer"]=="Y") { ?>
				<a href="elms_group_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/groups_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMUPer"]=="Y") { ?>
				<a href="elms_user_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/users_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInUserType"]=="Admin") { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/courses_link_icon_selected.png" /></a>
			<?php } else { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/mycourses_link_icon_selected.png" /></a>
			<?php } ?>
		</td>
		<?php if ($_SESSION["Elms_LoggedInUserType"]=="User") { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_learner_course_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>
		<?php } else { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_statistic_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon.png" /></a>
			</td>		
		<?php } ?>
<?php
	}
?>

<?php
	function showMainLinksReportsSelected() {
?>
		<td>&nbsp;</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMGPer"]=="Y") { ?>
				<a href="elms_group_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/groups_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInMUPer"]=="Y") { ?>
				<a href="elms_user_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/users_link_icon.png" /></a>
			<?php } ?>
		</td>
		<td width="20%" align="center" valign="top">
			<?php if ($_SESSION["Elms_LoggedInUserType"]=="Admin") { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/courses_link_icon.png" /></a>
			<?php } else { ?>
				<a href="elms_course_list.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/mycourses_link_icon.png" /></a>
			<?php } ?>
		</td>
		<?php if ($_SESSION["Elms_LoggedInUserType"]=="User") { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_learner_course_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon_selected.png" /></a>
			</td>
		<?php } else { ?>
			<td width="20%" align="center" valign="top">
				<a href="elms_statistic_report.php"><img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/reports_link_icon_selected.png" /></a>
			</td>		
		<?php } ?>
<?php
	}
?>

<?php
	function showRoleMainLinks() {
?>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tr height="10">
				<td colspan="3"></td>
			</tr>
			<tr>
				<td width="1%"></td>
				<td align="left" valign="top">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tr>
							<td width="45%" height="110" align="left" valign="top">
								<table width="100%" cellspacing="0" cellpadding="0" class="clsRoleNormalText" border="0">
									<tr>
										<td width="100%" align="left" valign="top">
											<img border="0" width="125" height="93" src="images/user_profile/<?php echo $_SESSION["Elms_LoggedInProfilePic"]; ?>?x=<?php echo uniqid((double)microtime()*1000000, 0); ?>" />
										</td>
									</tr>
								</table>
							</td>
							<td width="55%" height="110" align="left" valign="top" >
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<?php
											$strCurFileName = strlen($_SERVER['QUERY_STRING']) ? basename($_SERVER['PHP_SELF'])."?".$_SERVER['QUERY_STRING'] : basename($_SERVER['PHP_SELF']);
											if (strtolower($strCurFileName)=="elms_group_list.php" || strtolower($strCurFileName)=="elms_group_new.php" || strtolower($strCurFileName)=="elms_group_edit.php" || strtolower($strCurFileName)=="elms_group_assign.php") {
												showMainLinksGroupsSelected();
											} else {
											if (strtolower($strCurFileName)=="elms_user_list.php" || strtolower($strCurFileName)=="elms_user_new.php" || strtolower($strCurFileName)=="elms_user_edit.php" || strtolower($strCurFileName)=="elms_user_import.php" || strtolower($strCurFileName)=="elms_user_assign_course.php" || strtolower($strCurFileName)=="elms_user_group_assign.php" || strtolower($strCurFileName)=="elms_user_course_assign.php") {
												showMainLinksUsersSelected();
											} else {
											if (strtolower($strCurFileName)=="elms_course_list.php" || strtolower($strCurFileName)=="elms_course_new.php" || strtolower($strCurFileName)=="elms_course_edit.php" || strtolower($strCurFileName)=="elms_course_assign.php") {
												showMainLinksCoursesSelected();
											} else {
											if (strtolower($strCurFileName)=="elms_statistic_report.php" || strtolower($strCurFileName)=="elms_user_report.php" || strtolower($strCurFileName)=="elms_user_report_detail.php" || strtolower($strCurFileName)=="elms_course_report.php" || strtolower($strCurFileName)=="elms_learner_course_report.php" || strtolower($strCurFileName)=="elms_view_certificate.php") {
												showMainLinksReportsSelected();
											} else {
												showMainLinksNormal();
											} } } }
										?>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
				<td width="1%">&nbsp;</td>
			</tr>
			<tr height="25">
				<td valign="top" colspan="3"><hr /></td>
			</tr>
		</table>
<?php
	}
?>

<?php
	function doRenderListPagination($varTotalCountTemp, $varRowSizeTemp, $varCurPageTemp, $varDisplayRowSizeTextTemp, $varLoacTemp) {
?>
	<?php if ($varLoacTemp=="TOP") { ?>
		<tr height="20">
			<td width="100%" align="center" colspan="2">
			</td>
		</tr>
	<?php } else { ?>
		<tr height="20">
			<td>
			</td>
		</tr>
		<tr>
			<td width="100%" align="center">
				<font color="#333333"><b><?php echo $varDisplayRowSizeTextTemp; ?></b></font>
			</td>
		</tr>
		<tr height="10">
			<td>
			</td>
		</tr>	
	<?php } ?>
	<tr>
		<?php if ($varLoacTemp=="TOP") { ?>
			<td width="100%" align="center" colspan="2">
		<?php } else { ?>
			<td width="100%" align="center">
		<?php } ?>
			<div style="padding:10px 0px 10px 0px; border:1px solid <?php echo $_SESSION["Elms_AlternateFColor"]; ?>; background-color:<?php echo $_SESSION["Elms_AlternateFColor"]; ?>; width:100%; display:inline-block; text-align:center;">
			<?php
				$varTempPageCount = $varTotalCountTemp/$varRowSizeTemp;
				$varTempArrPageCount = explode(".", $varTempPageCount);
				for ($j=1; $j<=$varTempArrPageCount[0]; $j++) {
					if (count(explode(".", ($j / 15)))==1) {
			?>
						<?php if ($varCurPageTemp==$j) { ?>
							<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnableSelected" />
						<?php } else { ?>
							<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtCurPage.value=<?php echo $j; ?>; document.frmMain.txtStartLimit.value=<?php echo ($varRowSizeTemp*$j) - $varRowSizeTemp; ?>; document.frmMain.submit();" />
						<?php } ?>
						<div style="height:5px;"></div>
					<?php } else { ?>
						<?php if ($varCurPageTemp==$j) { ?>
							<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnableSelected" />
						<?php } else { ?>
							<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtCurPage.value=<?php echo $j; ?>; document.frmMain.txtStartLimit.value=<?php echo ($varRowSizeTemp*$j) - $varRowSizeTemp; ?>; document.frmMain.submit();" />
						<?php } ?>
			<?php
					}
				}
			?>
			<?php if (count($varTempArrPageCount)==2) { ?>
				<?php if (count(explode(".", (($j) / 15)))==1) { ?>
					<?php if ($varCurPageTemp==$j) { ?>
						<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnableSelected" />
					<?php } else { ?>
						<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtCurPage.value=<?php echo $j; ?>; document.frmMain.txtStartLimit.value=<?php echo ($varRowSizeTemp*$j) - $varRowSizeTemp; ?>; document.frmMain.submit();" />
					<?php } ?>
					<div style="height:5px;"></div>																							
				<?php } else { ?>
					<?php if ($varCurPageTemp==$j) { ?>
						<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnableSelected" />
					<?php } else { ?>
						<input type="button" value="&nbsp;&nbsp;<?php echo $j; ?>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtCurPage.value=<?php echo $j; ?>; document.frmMain.txtStartLimit.value=<?php echo ($varRowSizeTemp*$j) - $varRowSizeTemp; ?>; document.frmMain.submit();" />
					<?php } ?>
				<?php } ?>
			<?php } ?>
			</div>
		</td>
	</tr>
	<?php if ($varLoacTemp=="TOP") { ?>
		<tr height="10">
			<td width="100%" align="center" colspan="2">
			</td>
		</tr>
		<tr>
			<td width="100%" align="center" colspan="2">
				<font color="#333333"><b><?php echo $varDisplayRowSizeTextTemp; ?></b></font>
			</td>
		</tr>																				
		<tr height="10">
			<td width="100%" align="center" colspan="2">
			</td>
		</tr>
	<?php } else { ?>
		<tr height="10">
			<td width="100%" align="center">
			</td>
		</tr>	
	<?php } ?>
<?php	
	}
?>

<?php
	function doRenderListPreNextNavigation($varDisablePreNavTemp, $varDisableNextNavTemp, $varDisplayRowSizeTextTemp, $varLoacTemp) {
?>
	<?php if ($varLoacTemp=="TOP") { ?>
		<tr height="20">
			<td width="100%" align="center" colspan="2">
			</td>
		</tr>
	<?php } else { ?>
		<tr height="10">
			<td>
			</td>
		</tr>	
	<?php } ?>
	<tr>
		<?php if ($varLoacTemp=="TOP") { ?>
			<td width="100%" align="center" colspan="2">
		<?php } else { ?>
			<td width="100%" align="center">
		<?php } ?>
			<div style="padding:10px 0px 10px 0px; border:1px solid <?php echo $_SESSION["Elms_AlternateFColor"]; ?>; background-color:<?php echo $_SESSION["Elms_AlternateFColor"]; ?>; width:100%; display:inline-block; text-align:center;">
				<?php if ($varDisablePreNavTemp=="No") { ?>
					<input type="button" value="&nbsp;&nbsp;<<&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='FIRST'; document.frmMain.submit();" />
					<input type="button" value="&nbsp;&nbsp;<&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='PREVIOUS'; document.frmMain.submit();" />
				<?php } else { ?>
					<input type="button" value="&nbsp;&nbsp;<<&nbsp;&nbsp;" class="clsButtonDisable" />
					<input type="button" value="&nbsp;&nbsp;<&nbsp;&nbsp;" class="clsButtonDisable" />
				<?php } ?>
				&nbsp;&nbsp;<font color="#333333"><b><?php echo $varDisplayRowSizeTextTemp; ?></b></font>&nbsp;&nbsp;
				<?php if ($varDisableNextNavTemp=="No") { ?>
					<input type="button" value="&nbsp;&nbsp;>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='NEXT'; document.frmMain.submit();" />
					<input type="button" value="&nbsp;&nbsp;>>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='LAST'; document.frmMain.submit();" />
				<?php } else { ?>
					<input type="button" value="&nbsp;&nbsp;>&nbsp;&nbsp;" class="clsButtonDisable" />
					<input type="button" value="&nbsp;&nbsp;>>&nbsp;&nbsp;" class="clsButtonDisable" />
				<?php } ?>
			</div>
		</td>
	</tr>
	<?php if ($varLoacTemp=="TOP") { ?>
	<?php } else { ?>
		<tr height="10">
			<td width="100%" align="center">
			</td>
		</tr>	
	<?php } ?>
<?php	
	}
?>

<?php
	function doRenderListPreNextNavigationWithDDL($varTotalCountTemp, $varRowSizeTemp, $varCurPageTemp, $varDisablePreNavTemp, $varDisableNextNavTemp, $varDisplayRowSizeTextTemp, $varLoacTemp) {
?>
	<?php if ($varLoacTemp=="TOP") { ?>
		<tr height="20">
			<td width="100%" align="center" colspan="2">
			</td>
		</tr>
	<?php } else { ?>
		<tr height="10">
			<td>
			</td>
		</tr>	
	<?php } ?>
	<tr>
		<?php if ($varLoacTemp=="TOP") { ?>
			<td width="100%" align="center" colspan="2">
		<?php } else { ?>
			<td width="100%" align="center">
		<?php } ?>
			<div style="padding:10px 0px 10px 0px; border:1px solid <?php echo $_SESSION["Elms_AlternateFColor"]; ?>; background-color:<?php echo $_SESSION["Elms_AlternateFColor"]; ?>; width:100%; display:inline-block; text-align:center;">
				<?php if ($varDisablePreNavTemp=="No") { ?>
					<input type="button" value="&nbsp;&nbsp;<<&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='FIRST'; document.frmMain.txtCurPage.value=Number(document.frmMain.ddPaginationList.options[0].value); document.frmMain.submit();" />
					<input type="button" value="&nbsp;&nbsp;<&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='PREVIOUS'; document.frmMain.txtCurPage.value=Number(document.frmMain.ddPaginationList.value)-1; document.frmMain.submit();" />
				<?php } else { ?>
					<input type="button" value="&nbsp;&nbsp;<<&nbsp;&nbsp;" class="clsButtonDisable" />
					<input type="button" value="&nbsp;&nbsp;<&nbsp;&nbsp;" class="clsButtonDisable" />
				<?php } ?>
				&nbsp;&nbsp;
				<select id="ddPaginationList" name="ddPaginationList" size="1" class="clsTextField" style="height:30px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtCurPage.value=this.value; document.frmMain.txtStartLimit.value=(<?php echo $varRowSizeTemp; ?>*this.value) - <?php echo $varRowSizeTemp; ?>; document.frmMain.submit();">
					<?php
						$varTempPageCount = $varTotalCountTemp/$varRowSizeTemp;
						$varTempArrPageCount = explode(".", $varTempPageCount);
						if (count($varTempArrPageCount)==2) {
							$varTempDDPageCount = (int)$varTempArrPageCount[0];
						} else {
							$varTempDDPageCount = (int)$varTempArrPageCount[0] + 1;
						}
						for ($j=1; $j<=$varTempArrPageCount[0]; $j++) {
					?>
							<?php if ($varCurPageTemp==$j) { ?>
								<option selected value="<?php echo $j; ?>"><?php echo $j; ?></option>
							<?php } else { ?>
								<option value="<?php echo $j; ?>"><?php echo $j; ?></option>
							<?php } ?>
					<?php
						}
					?>
					<?php if (count($varTempArrPageCount)==2) { ?>
						<?php if ($varCurPageTemp==$j) { ?>
							<option selected value="<?php echo $j; ?>"><?php echo $j; ?></option>
						<?php } else { ?>
							<option value="<?php echo $j; ?>"><?php echo $j; ?></option>
						<?php } ?>
					<?php } ?>
				</select>
				&nbsp;&nbsp;<font color="#333333"><b><?php echo $varDisplayRowSizeTextTemp; ?></b></font>&nbsp;&nbsp;				
				<?php if ($varDisableNextNavTemp=="No") { ?>
					<input type="button" value="&nbsp;&nbsp;>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='NEXT'; document.frmMain.txtCurPage.value=Number(document.frmMain.ddPaginationList.value)+1; document.frmMain.submit();" />
					<input type="button" value="&nbsp;&nbsp;>>&nbsp;&nbsp;" class="clsButtonEnable" onclick="javascript:doShowProccessIcon(); document.frmMain.txtAction.value='LAST'; document.frmMain.txtCurPage.value=Number(document.frmMain.ddPaginationList.options[document.frmMain.ddPaginationList.options.length-1].value); document.frmMain.submit();" />
				<?php } else { ?>
					<input type="button" value="&nbsp;&nbsp;>&nbsp;&nbsp;" class="clsButtonDisable" />
					<input type="button" value="&nbsp;&nbsp;>>&nbsp;&nbsp;" class="clsButtonDisable" />
				<?php } ?>
			</div>
		</td>
	</tr>
	<?php if ($varLoacTemp=="TOP") { ?>
	<?php } else { ?>
		<tr height="10">
			<td width="100%" align="center">
			</td>
		</tr>	
	<?php } ?>
<?php	
	}
?>

<?php
	function doGenerateLoginIdAndPass($length = 5, $add_dashes = false, $available_sets = 'd', $varTempInc) {
		$sets = array();
		if(strpos($available_sets, 'l') !== false)
			$sets[] = 'abcdefghjkmnpqrstuvwxyz';
		if(strpos($available_sets, 'u') !== false)
			$sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
		if(strpos($available_sets, 'd') !== false)
			$sets[] = '23456789' . $varTempInc;
		if(strpos($available_sets, 's') !== false)
			$sets[] = '!@#$%&*?';

		$all = '';
		$password = '';
		foreach($sets as $set) {
			$password .= $set[array_rand(str_split($set))];
			$all .= $set;
		}

		$all = str_split($all);
		for($i = 0; $i < $length - count($sets); $i++)
			$password .= $all[array_rand($all)];

		$password = str_shuffle($password);

		if(!$add_dashes)
			return $password;

		$dash_len = floor(sqrt($length));
		$dash_str = '';
		while(strlen($password) > $dash_len) {
			$dash_str .= substr($password, 0, $dash_len) . '-';
			$password = substr($password, $dash_len);
		}
		$dash_str .= $password;
		return $dash_str;
	}
	
	function doGenerateRNDNum($length = 5, $add_dashes = false, $available_sets = 'd') {
		$sets = array();
		if(strpos($available_sets, 'l') !== false)
			$sets[] = 'abcdefghjkmnpqrstuvwxyz';
		if(strpos($available_sets, 'u') !== false)
			$sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
		if(strpos($available_sets, 'd') !== false)
			$sets[] = '23456789';
		if(strpos($available_sets, 's') !== false)
			$sets[] = '!@#$%&*?';

		$all = '';
		$password = '';
		foreach($sets as $set) {
			$password .= $set[array_rand(str_split($set))];
			$all .= $set;
		}

		$all = str_split($all);
		for($i = 0; $i < $length - count($sets); $i++)
			$password .= $all[array_rand($all)];

		$password = str_shuffle($password);

		if(!$add_dashes)
			return $password;

		$dash_len = floor(sqrt($length));
		$dash_str = '';
		while(strlen($password) > $dash_len) {
			$dash_str .= substr($password, 0, $dash_len) . '-';
			$password = substr($password, $dash_len);
		}
		$dash_str .= $password;
		return $dash_str;
	}	
	
	function doGetDateTimeDiff($strTemp1, $strTemp2, $strRequired="") {
		$strReturnVal = "";
		$strDate1 = $strTemp1;
		$strDate2 = $strTemp2;
		$strDiff = abs(strtotime($strDate2) - strtotime($strDate1));
		$years = floor($strDiff / (365*60*60*24));
		$months = floor(($strDiff - $years * 365*60*60*24) / (30*60*60*24));
		$days = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
		$hours = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60));
		$minuts = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60);
		$seconds = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minuts*60));
		if (strlen($hours)==1) $hours = "0" . $hours;
		if (strlen($minuts)==1) $minuts = "0" . $minuts;
		if (strlen($seconds)==1) $seconds = "0" . $seconds;
		if ($strRequired=="D") {
			$strReturnVal = $years . "-" . $months . "-" . $days;
		} else {
			$strReturnVal = $hours . ":" . $minuts . ":" . $seconds;
		}
		return $strReturnVal;
	}
?>