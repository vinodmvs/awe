<div id="divDisableBG" name="divDisableBG" class="clsDivDisableBG"></div>
<div id="divProccess" name="divProccess" class="clsDivProccess">
	Processing please wait...
</div>
<div id="divDeletePanel" name="divDeletePanel" class="clsDivDeletePanel">
	<div class="clsDeleteTitle">
		<div style="display:table-cell; width:95%; padding:6px 0px 0px 0px; text-align:left;">
			&nbsp;MVSLMS
		</div>
		<div style="display:table-cell; width:5%; padding:0px 2px 0px 0px; text-align:right;">
			<div class="clsDivDeleteClose" onclick="javascript:doCloseDeletePanel();"><div style="width:100%; height:100%; text-align:center; vertical-align:middle;"><font size="4">x</font></div></div>
		</div>
	</div>
	<div style="width:100%; height:5px;">
	</div>	
	<div id="divDelConfirmText" name="divDelConfirmText" class="clsDivDeleteText">
	</div>
	<div style="width:100%;">
		<hr style="border: 1px solid #cccccc;" />
	</div>
	<div style="width:100%; text-align:center;">
		<div class="clsDivDeleteYesBtn" onclick="javascript:doSubmitDelete();">
			<div style="padding-top:6px; text-align:center; vertical-align:middle;">Yes</div>
		</div>
		<div class="clsDivDeleteNoBtn" onclick="javascript:doCloseDeletePanel();">
			<div style="padding-top:6px; text-align:center; vertical-align:middle;">No</div>
		</div>		
	</div>
	<div style="width:100%;">
		<hr style="border: 1px solid #cccccc;" />
	</div>	
	<div style="width:100%; text-align:center;">
		<font size="2" color="red"><b>Note:</b></font> <font size="2" color="black">Once deleted cannot be retrieved.</font>
	</div>	
	<div style="width:100%; height:5px;">
	</div>	
</div>
<div id="divAlertPanel" name="divAlertPanel" class="clsDivAlertPanel">
	<div class="clsAlertTitle">
		<div style="display:table-cell; width:95%; padding:6px 0px 0px 0px; text-align:left;">
			&nbsp;MVSLMS
		</div>
		<div style="display:table-cell; width:5%; padding:0px 2px 0px 0px; text-align:right;">
			<div class="clsDivAlertClose" onclick="javascript:doCloseAlertPanel();"><div style="width:100%; height:100%; text-align:center; vertical-align:middle;"><font size="4">x</font></div></div>
		</div>
	</div>
	<div style="width:100%; height:5px;">
	</div>	
	<div id="divAlertText" name="divAlertText" class="clsDivAlertText">
	</div>
	<div style="width:100%;">
		<hr style="border: 1px solid #cccccc;" />
	</div>
	<div style="width:100%; text-align:center;">
		<div class="clsDivAlertCloseBtn" onclick="javascript:doCloseAlertPanel();">
			<div style="padding-top:6px; text-align:center; vertical-align:middle;">Ok</div>
		</div>
	</div>
	<div style="width:100%; height:5px;">
	</div>	
</div>