<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";

	$varUserId = "";
	$varUserLogin = "";
	$varUserPass = "";
	$varUserFname = "";
	$varUserLname = "";
	$varUserDOB = "";
	$varUserPhone = "";
	$varUserProfilePic = "user_profile_default.png";
	$varUserTheme = "blue";

	if (!isset($_POST["txtUserId"])) {
		header("Location:index.php");
	} else {
		$varUserId = $_POST["txtUserId"];
		$varUserLogin = $_POST["txtLoginId"];
		$varFlgExists = "No";
		$tempQuery = "SELECT * FROM elms_user_details WHERE user_login<>'" . $varUserLogin . "'";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		while ($tempRow = mysql_fetch_array($tempResult)) {
			if (strtolower($tempRow["user_login"])==strtolower($varUserLogin)) {
				$varFlgExists = "Yes";
				break;
			}			
		}
		if ($varFlgExists=="Yes") {
			$_SESSION["Elms_ResMsg"] = "ELMS_EXISTS";
			header("Location:elms_profile.php");
		} else {
			$varUserPass = $_POST["txtPass"];
			$varUserFname = str_replace("'", "\\'", $_POST["txtFName"]);
			$varUserLname = str_replace("'", "\\'", $_POST["txtLName"]);
			$varUserDOB = $_POST["txtDOB"];
			$varUserPhone = $_POST["txtPhone"];
			$varUserProfilePic = $_POST["txtProfileOldPic"];
			$varUserTheme = $_POST["txtTheme"];
			
			if (isset($_FILES["txtProfilePic"]) && $_FILES["txtProfilePic"]["name"]) {
				$strUploadMaxFileSize = ini_get('upload_max_filesize');
				$intUploadMaxFileSize = (int)substr($strUploadMaxFileSize, 0, -1);
				$intSourceFileSize = (int)(($_FILES['txtProfilePic']['size']/1024)/1024);		
				if ($intSourceFileSize < $intUploadMaxFileSize) {
					$strFilename = $_FILES["txtProfilePic"]["name"];
					$strSource = $_FILES["txtProfilePic"]["tmp_name"];
					$strType = $_FILES["txtProfilePic"]["type"];
					$strName = explode(".", $strFilename);
					if ($varUserProfilePic=="user_profile_default.png") {
						$varRndId = doGenerateRNDNum(5, false, 'd');
						$tempFile = "profile_" . $varRndId . "_" . $strName[0] . "." . $strName[1];
					} else {
						$tempFile = $varUserProfilePic;
					}
					$strUploadPath = dirname(__FILE__) . "/images/user_profile/" . $tempFile;
					if (move_uploaded_file($strSource, $strUploadPath)) {
						$varUserProfilePic = $tempFile;
					} else {
						$_SESSION["Elms_ResMsg"] = "ELMS_UPLOADERROR";
						header("Location:elms_profile.php");
					}
				} else {
					$_SESSION["Elms_ResMsg"] = "ELMS_TOOLARGEERROR";
					header("Location:elms_profile.php");
				}
			}			
			if ($varFileUploadError=="") {
				$tempQuery = "UPDATE elms_user_details SET user_fname='" . $varUserFname . "',user_lname='" . $varUserLname . "',user_dob='" . $varUserDOB . "',user_phone='" . $varUserPhone . "',user_login='" . $varUserLogin . "',user_pass='" . $varUserPass . "',user_theme='" . $varUserTheme . "',user_profile_pic='" . $varUserProfilePic . "' WHERE user_id=" . $varUserId;
				$tempResult = mysql_query($tempQuery) or die (mysql_error());
				if ($tempResult) {
					$_SESSION["Elms_ResMsg"] = "ELMS_SUCCESS";
					$_SESSION["Elms_ThemeColor"] = $varUserTheme;
					$_SESSION["Elms_LoggedInProfilePic"] = $varUserProfilePic;
					header("Location:elms_profile.php");
				} else {
					$_SESSION["Elms_ResMsg"] = "ELMS_DBERROR";
					header("Location:elms_profile.php");										
				}
			} else {
			}
		}
	}
?>