<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varGroup = "";
	$varHead = "";
	$varCoursesEnrolled = "";
	$varRegFDate = "";
	$varRegEDate = "";
	$varLoginFDate = "";
	$varLoginEDate = "";

	if (!isset($_POST["ddGroup"])) {
		header("Location:index.php");
	} else {
		$varGroup = $_POST["ddGroup"];
		if (isset($_POST["ddManager"])) {
			$varHead = $_POST["ddManager"];
		}
		$varCoursesEnrolled = $_POST["ddCoursesEnrolled"];
		$varRegFDate = $_POST["txtRegFDate"];
		$varRegEDate = $_POST["txtRegEDate"];
		$varLoginFDate = $_POST["txtLoginFDate"];
		$varLoginEDate = $_POST["txtLoginEDate"];

		if ($varRegFDate!="" && $varRegEDate=="") {
			$strMessage = "Please enter the Registered End date and click Apply.";
		} else {
		if ($varRegFDate=="" && $varRegEDate!="") {
			$strMessage = "Please enter the Registered From date and click Apply.";
		} else {
		if (date($varRegFDate)>date("Y-m-d") && date($varRegEDate)>date("Y-m-d")) {
			$strMessage = "The Registered From Date and End Date should not be greater than current Date";
		} else {
		if (date($varRegFDate)>date("Y-m-d")) {
			$strMessage = "The Registered From Date should not be greater than current Date";
		} else {
		if (date($varRegEDate)>date("Y-m-d")) {
			$strMessage = "The Registered End Date should not be greater than current Date";
		} else {
		if (date($varRegFDate)>date($varRegEDate)) {
			$strMessage = "The Registered From Date should not be greater than Registered End Date";
		} else {


		if ($varLoginFDate!="" && $varLoginEDate=="") {
			$strMessage = "Please enter the Logedin End date and click Apply.";
		} else {
		if ($varLoginFDate=="" && $varLoginEDate!="") {
			$strMessage = "Please enter the Logedin From date and click Apply.";
		} else {
		if (date($varLoginFDate)>date("Y-m-d") && date($varLoginEDate)>date("Y-m-d")) {
			$strMessage = "The Logedin From Date and End Date should not be greater than current Date";
		} else {
		if (date($varLoginFDate)>date("Y-m-d")) {
			$strMessage = "The Logedin From Date should not be greater than current Date";
		} else {
		if (date($varLoginEDate)>date("Y-m-d")) {
			$strMessage = "The Logedin End Date should not be greater than current Date";
		} else {
		if (date($varLoginFDate)>date($varLoginEDate)) {
			$strMessage = "The Logedin From Date should not be greater than Logedin End Date";
		} else {
			$tempQuery = "UPDATE elms_admin_user_report_filter SET user_group='" . $varGroup . "',user_head='" . $varHead . "',user_course='" . $varCoursesEnrolled . "',user_reg_fdate='" . $varRegFDate . "',user_reg_edate='" . $varRegEDate . "',user_login_fdate='" . $varLoginFDate . "',user_login_edate='" . $varLoginEDate . "'";
			$tempResult = mysql_query($tempQuery);

			if ($tempResult) {
				$strMessage = "ELMS_SUCCESS";
			} else {
				$strMessage = "<b>Error: </b>Error occured while getting the Report Details from the Database.";
			}
		} } } } } } } } } } } }

		echo $strMessage;
	}
?>