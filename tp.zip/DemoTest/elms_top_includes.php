<?php
	require("elms_config.php");
	require("elms_db.php");
	require("elms_lib.php");
	require("class.phpmailer.php");
	require("elms_session_check.php");
?>