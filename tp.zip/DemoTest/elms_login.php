<?php
	require("elms_config.php");
	require("elms_db.php");
	
	$_SESSION["Elms_LoggedInId"] = "";
	$_SESSION["Elms_LoggedInEmail"] = "";
	$_SESSION["Elms_LoggedInUserName"] = "";
	$_SESSION["Elms_LoggedInUserType"] = "";
	$_SESSION["Elms_LoggedInIEUserType"] = "";
	$_SESSION["Elms_LoggedInTrackId"] = "";
	$_SESSION["Elms_LoggedInMUPer"] = "";
	$_SESSION["Elms_LoggedInMGPer"] = "";
	$_SESSION["Elms_LoggedInProfilePic"] = "";
	$_SESSION["Elms_ReplyEmail"] = "";
	$_SESSION["Elms_SiteURL"] = "";
	$_SESSION["Elms_ResMsg"] = "";
	$_SESSION["Elms_SuccessMsg"] = "";
	$_SESSION["Elms_ErrorMsg"] = "";
	$_SESSION["Elms_TrialMsg"] = "";
	$_SESSION["Elms_ThemeColor"] = "blue";
	$_SESSION["Elms_GeneralBgColor"] = "#49c0f0";
	$_SESSION["Elms_AlternateFColor"] = "#c0e7f9";
	$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";
	
	$_SESSION["Elms_SCORMCourseStatus"] = "";
	$_SESSION["Elms_SCORMRawScore"] = 0;
	
	$_SESSION["Elms_CourseName"] = "";
	$_SESSION["Elms_CourseCatName"] = "";
	
	$_SESSION["Elms_CourseEditId"] = "";	
?>

<?php
	/*
	$dbHost = 'localhost';
	$dbUser = 'root';
	$dbPass = '';
	$dbName = 'mvslms';
	*/
	
	$dbHost = 'localhost';
	$dbUser = 'mvslmsdbadmin';
	$dbPass = 'MvsLMSDBAdminGoodLuck123';
	$dbName = 'mvslms';
	
	$strMessage = "";
	$_SESSION["Elms_TrialMsg"] = "";
	$varTrailCount = 14;

	$dbConn = mysql_connect($dbHost, $dbUser, $dbPass);

	if (!$dbConn) {
		$strMessage = "<b>Server Message </b>MYSQL Server Connection Server Message Could not connect to MYSQL SERVER " . mysql_error();
	} else {
		$db = mysql_select_db($dbName);
		if (!$db) {
			$strMessage = "<b>Server Message </b>MYSQL Server Database Server Message Could not select the MYSQL SERVER Database " . mysql_error();
		} else {
			$strCurBaseDirName = dirname(__FILE__);
			$varSPL = explode(DIRECTORY_SEPARATOR, $strCurBaseDirName);
			$strCurDirName = $varSPL[count($varSPL)-1];
			$strCurDirName = "chironmeditour";
			$varCurDate = date('Y-m-d');
			$tempQuery = "SELECT * FROM elms_customer_details WHERE customer_lmsdb_name='" . $strCurDirName  . "'";
			$tempResult = mysql_query($tempQuery) or die (mysql_error());
			$tResult = mysql_query($tempQuery) or die (mysql_error());
			$intTempNum = mysql_num_rows($tResult);
			if ($intTempNum>0) {
				while ($tempRow = mysql_fetch_array($tempResult)) {
					if ($tempRow["customer_ispurchased"]=="Y") {
						$strMessage = "ELMS_SUCCESS";
					} else {
					if ($tempRow["customer_isverified"]=="Y" && $varCurDate<=date($tempRow["customer_trial_expdate"])) {
						$varTrailCount = doGetDateTimeDiff($varCurDate, date($tempRow["customer_trial_expdate"]), "D");
						if ($varTrailCount>=0) {
							$strMessage = "ELMS_SUCCESS";
							$_SESSION["Elms_TrialMsg"] = 'Your trial period will expire in <b>' . $varTrailCount . ' day(s)</b>. Please click <a href="http://www.mvslms.com/pricing-plans/">here</a> to purchase.';
						} else {
							$strMessage = 'Your trial period has expired. Please click <a href="http://www.mvslms.com/pricing-plans/">here</a> to purchase.';
						}
					} else {
						$strMessage = "Access denied. Please contact MVS LMS server Administrator.";
					} }
				}
			} else {
				$strMessage = "Access denied. Please contact MVS LMS server Administrator.";
			}
		}
	}
	if ($strMessage!="ELMS_SUCCESS") {
		header("Location:http://www.mvslms.com/elms_customer_show_account_expired_message.php");
	}
	$db = mysql_select_db($strCurDirName);	
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doInitialize() {
				document.frmMain.txtEmail.focus();
			}
			
			function doFormValidation() {
				if (document.frmMain.txtEmail.value=="") {
					doShowAlertPanel("User name cannot be blank. Please enter the User name.", document.frmMain.txtEmail);
				} else {
				if (!validEmail(document.frmMain.txtEmail.value)) {
					doShowAlertPanel("Invalid email address format ! \nEvery email address must include one @ sign followed by a domain name. \nEg: User@Server.com.", document.frmMain.txtEmail);
				} else {
				if (document.frmMain.txtPass.value=="") {
					doShowAlertPanel("Password cannot be blank. Please enter the Password.", document.frmMain.txtPass);
				} else {
					var strPOSTURL = "elms_login_check.php";
					var objFormData = $( "#frmMain" ).serialize();					
					doPOSTNormalFormData(strPOSTURL, objFormData);
				} } }
			}

			function doSendForgotPassData() {
				if (document.frmForgotPass.txtForgotPassEmail.value=="") {
					doShowAlertPanel("E-mail Id cannot be blank. Please enter the E-mail Id.", document.frmForgotPass.txtForgotPassEmail);
				} else {
				if (!validEmail(document.frmForgotPass.txtForgotPassEmail.value)) {
					doShowAlertPanel("Invalid e-mail address format! \nEvery e-mail address must include one @ sign followed by a domain ne. \nEg: User@Server.com.", document.frmForgotPass.txtForgotPassEmail);
				} else {
					var strPOSTURL = "elms_forgot_pass_update.php";
					var objFormData = $( "#frmForgotPass" ).serialize();
					doPOSTForgotPassFormData(strPOSTURL, objFormData);
				} }
			}			
			
			function doPOSTNormalFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_INVALID")>-1) {
							doShowAlertPanel("Invalid Login Id or Password. Please try again!", document.frmMain.txtEmail);
						} else {
						if (strAjaxReturnTrimed.indexOf("ELMS_DEACTIVE")>-1) {
							doShowAlertPanel("Your account has been deactivated. Please contact <b>Chiron Meditour Training</b>.", '');
						} else {
							document.location.href = strAjaxReturnTrimed;
						} }
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}

			function doPOSTForgotPassFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
							doHideForgotPassForm();
							doShowAlertPanel("Your login details has been sent to your registered E-mail Id. Please check your mailbox.", document.frmMain.txtEmail);
						} else {
							doShowAlertPanel(strAjaxReturnTrimed, '');
						}
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}			
			
			function doResetForgotPassForm() {
				document.frmForgotPass.txtForgotPassEmail.value = "";
			}

			function doShowForgotPassForm() {
				getScrollTop();
				doResetForgotPassForm();
				document.getElementById("divLoginDisableBG").style.display = "block";
				document.getElementById("divForgotPass").style.display = "block";
				document.frmForgotPass.txtForgotPassEmail.focus();
			}

			function doHideForgotPassForm() {
				doResetForgotPassForm();
				document.getElementById("divForgotPass").style.display = "none";
				document.getElementById("divLoginDisableBG").style.display = "none";
				document.frmMain.txtEmail.focus();
			}
			
			document.onkeypress = keyPress;
			function keyPress(e){
				var x = e || window.event;
				var key = (x.keyCode || x.which);
				if(key == 13 || key == 3){
					doFormValidation();
				}
			}
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<td width="100%" align="center" valign="middle">
											<div style="font-size:35px;">Sign In</div>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0" border="0">
												<tr>
													<td width="35%" align="right" valign="top">
														<br /><br /><br />
														<img src="images/custom_icon.png?x=<?php echo uniqid((double)microtime()*1000000, 0); ?>" alt="" title="" />
													</td>
													<td width="5%">
														&nbsp;
													</td>
													<td>
														<table width="100%" align="left" valign="top" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_login_check.php">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tr>
																				<td width="100%" align="left" valign="middle">
																					<table border="0">
																						<tr height="38">
																							<td valign="middle">
																								<img src="images/Mail_icon.png" alt="" title="" />
																							</td>
																							<td>
																							</td>
																							<td valign="top">
																								<font size="5">E-mail</font>
																							</td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="left" valign="middle">
																					<input type="text" id="txtEmail" name="txtEmail" class="clsTextField" style="width:350px; height:30px; font-size:15px;" />
																				</td>
																			</tr>
																			<tr height="25">
																				<td>
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="left" valign="middle">
																					<table border="0">
																						<tr height="37">
																							<td valign="middle">
																								<img src="images/lock_icon.png" alt="" title="" />
																							</td>
																							<td>
																							</td>
																							<td valign="top">
																								<font size="5">Password</font>
																							</td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="left" valign="middle">
																					<input type="password" id="txtPass" name="txtPass" class="clsTextField" style="width:350px; height:30px; font-size:15px;" />
																				</td>
																			</tr>
																			<tr height="15">
																				<td>
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="left" valign="middle">
																					<table width="48%" border="0">
																						<tr>
																							<td align="right">
																								<a href="javascript:doShowForgotPassForm();" class="clsHyperLinkText"><font color="#000000" size="5">Forgot Password</font></a>
																							</td>
																						</tr>
																					</table>

																				</td>
																			</tr>
																			<tr height="25">
																				<td>
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="left" valign="middle">
																					<input type="button" value="Sign In" onclick="javascript:doFormValidation();" class="clsActionButton" style="width:355px; height:45px; font-size:25px;" />
																				</td>
																			</tr>
																		</table>
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<div id="divLoginDisableBG" name="divLoginDisableBG" class="clsDivLoginDisableBG"></div>
				<div id="divForgotPass" name="divForgotPass" style="position:fixed; left:0px; top:25%; right:0px; margin:auto; display:none;">
					<form name="frmForgotPass" id="frmForgotPass" method="post" action="elms_user_signup_update.php">
						<table width="45%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>" class="clsSingleBorder">
							<tr class="clsTableSingleRowHeadingText">
								<td width="100%">Forgot Password</td>
							</tr>
							<tr>
								<td width="100%" align="left" valign="top">
									<table width="100%" align="center" cellspacing="2" cellpadding="2">
										<tr height="5">
											<td width="100%" colspan="3"></td>
										</tr>								
										<tr>
											<td width="32%" align="right">
												<font color="red">*</font> Registered E-mail Id:
											</td>
											<td width="1%">
											</td>																										
											<td width="67%" align="left">
												<input type="text" id="txtForgotPassEmail" name="txtForgotPassEmail" class="clsTextField" style="width:90%" />
											</td>																										
										</tr>
										<tr height="10">
											<td width="100%" colspan="3"></td>
										</tr>
										<tr>
											<td width="100%" align="center" colspan="3">
												<input type="button" value="&nbsp;Send Password&nbsp;" class="clsActionButton" onclick="javascript:doSendForgotPassData();" />
												<input type="button" value="Cancel" class="clsActionButton" onclick="javascript:doHideForgotPassForm();" />
											</td>
										</tr>
										<tr height="5">
											<td width="100%" colspan="3"></td>
										</tr>																									
									</table>
								</td>
							</tr>																						
						</table>
					</form>
				</div>				
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>	
	</body>
</html>

<?php
	function doGetDateTimeDiff($strTemp1, $strTemp2, $strRequired="") {
		$strReturnVal = "";
		$strDate1 = $strTemp1;
		$strDate2 = $strTemp2;
		$strDiff = abs(strtotime($strDate2) - strtotime($strDate1));
		$years = floor($strDiff / (365*60*60*24));
		$months = floor(($strDiff - $years * 365*60*60*24) / (30*60*60*24));
		$days = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
		$hours = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60));
		$minuts = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60);
		$seconds = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minuts*60));
		if (strlen($hours)==1) $hours = "0" . $hours;
		if (strlen($minuts)==1) $minuts = "0" . $minuts;
		if (strlen($seconds)==1) $seconds = "0" . $seconds;
		if ($strRequired=="D") {
			$strReturnVal = $days;
		} else {
			$strReturnVal = $hours . ":" . $minuts . ":" . $seconds;
		}
		return $strReturnVal;
	}
?>