<?php
	require("elms_top_includes.php");
?>

<?php
	$varUserType = "Internal";
	$varMemType = "";
	$varUserTitle = "Mr.";
	$varFname = "";
	$varLname = "";
	$varDOB = "";
	$varEmail = "";
	$varPhone = "";
	$varRole = "User";
	$varManager = $_SESSION['Elms_LoggedInId'];
	$varStatus = "A";

	if (isset($_POST["ddUserMemType"])) {
		$varMemType = $_POST["ddUserMemType"];
	}
	if (isset($_POST["ddUserIEType"])) {
		$varUserType = $_POST["ddUserIEType"];
		$varMemType = "";
	}
	if (isset($_POST["ddUserTitle"])) {
		$varUserTitle = $_POST["ddUserTitle"];
	}	
	if (isset($_POST["txtFName"])) {
		$varFname = $_POST["txtFName"];
	}
	if (isset($_POST["txtLName"])) {
		$varLname = $_POST["txtLName"];
	}
	if (isset($_POST["txtDOB"])) {
		$varDOB = $_POST["txtDOB"];
	}
	if (isset($_POST["txtEmail"])) {
		$varEmail = $_POST["txtEmail"];
	}
	if (isset($_POST["txtPhone"])) {
		$varPhone = $_POST["txtPhone"];
	}
	if (isset($_POST["ddUserType"])) {
		$varRole = $_POST["ddUserType"];
	}
	if (isset($_POST["ddManager"])) {
		$varManager = $_POST["ddManager"];
	}
	if (isset($_POST["txtStatus"])) {
		$varStatus = $_POST["txtStatus"];
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doInitialize() {
				$("#txtDOB").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true,changeYear: true, yearRange: "-75:+0"});
			}

			function doFormValidation() {
				if (document.frmMain.ddUserMemType.value=="") {
					doShowAlertPanel("Membership Name cannot be blank. Please select the Membership.", document.frmMain.ddUserMemType);
				} else {				
				if (document.frmMain.txtFName.value=="") {
					doShowAlertPanel("First Name cannot be blank. Please enter the First Name.", document.frmMain.txtFName);
				} else {
				if (document.frmMain.txtEmail.value=="") {
					doShowAlertPanel("E-mail Id cannot be blank. Please enter the E-mail Id.", document.frmMain.txtEmail);
				} else {
				if (!validEmail(document.frmMain.txtEmail.value)) {
					doShowAlertPanel("Invalid e-mail address format! \nEvery e-mail address must include one @ sign followed by a domain ne. \nEg: User@Server.com.", document.frmMain.txtEmail);
				} else {
				if (document.frmMain.txtPhone.value=="") {
					doShowAlertPanel("Mobile number cannot be blank. Please enter the Mobile number.", document.frmMain.txtPhone);
				} else {
/*				
				if (document.getElementsByName('lstGroupsAssigned[]').length<=0) {
					if (document.frmMain.ddUserType.value=="User") {
						doShowAlertPanel("Please assign the Group to the User.", '');
					} else {
						doShowAlertPanel("Please assign the Group to the Manager.", '');
					}
				} else {
*/				
					for (var i=0; i<document.getElementsByName('lstGroupsAssigned[]').length; i++) {
						document.getElementsByName('lstGroupsAssigned[]')[i].checked = true;
					}				
					var strPOSTURL = "elms_user_new_update.php";
					var objFormData = $( "#frmMain" ).serialize();					
					doPOSTNormalFormData(strPOSTURL, objFormData);
				} } } } } //}
			}

			function doPOSTNormalFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
							document.location.href = "elms_user_list.php";
						} else {
							doShowAlertPanel(strAjaxReturnTrimed, '');
						}
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}
			
			function doGetUserFormData() {
				doShowProccessIcon();
				document.frmMain.action = "elms_user_new.php";
				document.frmMain.submit();
			}			
			
			/* Group Handling */
			function doAddSelectedGroup() {
				if (document.getElementsByName('lstGroupsAssigned[]').length<=0) {
					document.getElementById('divGroupsAssignedPanel').innerHTML = "";
				}			
				var tempCount = document.getElementsByName('lstGroupsAvail[]').length;
				var tempSelectedCount = 0;
				var tempInnerHTML = "";
				var tempInc = 0;				
				for (var i=0; i<tempCount; i++) {
					if (document.getElementsByName('lstGroupsAvail[]')[i].checked==true) {
						tempSelectedCount++;
						break;
					}
				}
				if (tempSelectedCount<=0) {
					doShowAlertPanel("You have not selected any of the Group. Please select atleast one Group to assign.", '');
				} else {
					for (var i=0; i<tempCount; i++) {
						if (document.getElementsByName('lstGroupsAvail[]')[i].checked==true) {
							if (tempInnerHTML=="") {
								tempInnerHTML = '<div id="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');">';
								tempInnerHTML = tempInnerHTML + '<table width="100%" cellspacing="0" cellpadding="0" border="0">';
								tempInnerHTML = tempInnerHTML + '<tr>';
								tempInnerHTML = tempInnerHTML + '<td width="2%" align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + '<input type="checkbox" id="lstGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="lstGroupsAssigned[]" value="' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');" style="cursor:pointer;" />';
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '<td align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + document.getElementsByName('lstGroupsAvail[]')[i].getAttribute('groupname');
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '</tr>';
								tempInnerHTML = tempInnerHTML + '</table>';
								tempInnerHTML = tempInnerHTML + '</div>';
								tempInnerHTML = tempInnerHTML + '<div id="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="height:3px;"></div>';
							} else {
								tempInnerHTML = tempInnerHTML + '<div id="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');">';
								tempInnerHTML = tempInnerHTML + '<table width="100%" cellspacing="0" cellpadding="0" border="0">';
								tempInnerHTML = tempInnerHTML + '<tr>';
								tempInnerHTML = tempInnerHTML + '<td width="2%" align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + '<input type="checkbox" id="lstGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="lstGroupsAssigned[]" value="' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');" style="cursor:pointer;" />';
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '<td align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + document.getElementsByName('lstGroupsAvail[]')[i].getAttribute('groupname');
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '</tr>';
								tempInnerHTML = tempInnerHTML + '</table>';
								tempInnerHTML = tempInnerHTML + '</div>';
								tempInnerHTML = tempInnerHTML + '<div id="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="height:3px;"></div>';
							}
							tempInc++;
						}
					}
					if (document.frmMain.ddUserType.value=="User") {
						if (tempInc>1 || document.getElementsByName('lstGroupsAssigned[]').length>=1) {
							doShowAlertPanel("You can not assign more then one Group to the User.", '');
						} else {
							document.getElementById('divGroupsAssignedPanel').innerHTML = tempInnerHTML;
						}
					} else {
						var flgGroupFound = false;
						for (var i=0; i<document.getElementsByName('lstGroupsAvail[]').length; i++) {
							for (var j=0; j<document.getElementsByName('lstGroupsAssigned[]').length; j++) {
								if (document.getElementsByName('lstGroupsAvail[]')[i].checked==true && document.getElementsByName('lstGroupsAvail[]')[i].value==document.getElementsByName('lstGroupsAssigned[]')[j].value) {
									flgGroupFound = true;
									break;
								}
							}
						}
						if (flgGroupFound) {
							doShowAlertPanel("Any one of the selected Group already assigned to the User. Please try again with the correct selection.", '');
						} else {
							document.getElementById('divGroupsAssignedPanel').innerHTML = document.getElementById('divGroupsAssignedPanel').innerHTML + tempInnerHTML;
						}
					}
				}
			}
			
			function doRemoveSelectedGroup() {
				var tempCount = document.getElementsByName('lstGroupsAssigned[]').length;
				var tempSelectedCount = 0;
				for (var i=0; i<tempCount; i++) {
					if (document.getElementsByName('lstGroupsAssigned[]')[i].checked==true) {
						tempSelectedCount++;
						break;
					}
				}
				if (tempSelectedCount<=0) {
					doShowAlertPanel("You have not selected any of the Group. Please select atleast one Group to remove.", '');
				} else {
					for (var j=tempCount-1; j>=0; j--) {
						if (document.getElementsByName('lstGroupsAssigned[]')[j].checked==true) {
							document.getElementById('divGroupsAssignedPanel').removeChild(document.getElementById('divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAssigned[]')[j].value));
							document.getElementById('divGroupsAssignedPanel').removeChild(document.getElementById('divGroupsAssigned_' + document.getElementsByName('lstGroupsAssigned[]')[j].value));
						}
					}
					doCheckAllAssignedGroupsSelected();
				}
			}			

			function doCheckORUncheckGroupsAvail(varTemp) {
				var objTemp = document.getElementById("divGroupsAvail_" + varTemp);
				var objThis = document.getElementById("lstGroupsAvail_" + varTemp);
				if (objThis.checked==true) {
					objThis.checked=false;
					objTemp.style.backgroundColor = "#ffffff";
				} else {
					objThis.checked=true;
					objTemp.style.backgroundColor = "#d4d4d4";
				}
				doCheckAllAvailGroupsSelected();
			}
			
			function doCheckORUncheckGroupsAssigned(varTemp) {
				var objTemp = document.getElementById("divGroupsAssigned_" + varTemp);
				var objThis = document.getElementById("lstGroupsAssigned_" + varTemp);
				if (objThis.checked==true) {
					objThis.checked=false;
					objTemp.style.backgroundColor = "#ffffff";
				} else {
					objThis.checked=true;
					objTemp.style.backgroundColor = "#d4d4d4";
				}
				doCheckAllAssignedGroupsSelected();
			}
			
			function doCheckORUncheckAllAvailGroups(objThis) {
				var objTemp = null;
				var tempCount = document.getElementsByName('lstGroupsAvail[]').length;
				if (objThis.checked==true) {
					objThis.checked=false;
				} else {
					objThis.checked=true;
				}
				for (var i=0; i<tempCount; i++) {
					objTemp = document.getElementById(document.getElementsByName('lstGroupsAvail[]')[i].id.split("lst").join("div"));
					if (objThis.checked==true) {
						document.getElementsByName('lstGroupsAvail[]')[i].checked = true;
						objTemp.style.backgroundColor = "#d4d4d4";
					} else {
						document.getElementsByName('lstGroupsAvail[]')[i].checked = false;
						objTemp.style.backgroundColor = "#ffffff";
					}
				}
				doCheckAllAvailGroupsSelected();
			}
			
			function doCheckAllAvailGroupsSelected() {
				var boolAllSelected = true;
				if (document.getElementsByName("lstGroupsAvail[]").length<=0) {
					boolAllSelected = false;
				} else {
					for (var i=0; i<document.getElementsByName("lstGroupsAvail[]").length; i++) {
						if (document.getElementsByName("lstGroupsAvail[]")[i].checked==false) {
							boolAllSelected = false;
							break;
						}
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkCheckOrUncheckAllAvailGroups").checked = true;
				} else {
					document.getElementById("chkCheckOrUncheckAllAvailGroups").checked = false;
				}
			}			
			
			function doCheckORUncheckAllAssignedGroups(objThis) {
				var objTemp = null;
				var tempCount = document.getElementsByName('lstGroupsAssigned[]').length;
				if (objThis.checked==true) {
					objThis.checked=false;
				} else {
					objThis.checked=true;
				}
				for (var i=0; i<tempCount; i++) {
					objTemp = document.getElementById(document.getElementsByName('lstGroupsAssigned[]')[i].id.split("lst").join("div"));
					if (objThis.checked==true) {
						document.getElementsByName('lstGroupsAssigned[]')[i].checked = true;
						objTemp.style.backgroundColor = "#d4d4d4";
					} else {
						document.getElementsByName('lstGroupsAssigned[]')[i].checked = false;
						objTemp.style.backgroundColor = "#ffffff";
					}
				}
				doCheckAllAssignedGroupsSelected();
			}

			function doCheckAllAssignedGroupsSelected() {
				var boolAllSelected = true;
				if (document.getElementsByName("lstGroupsAssigned[]").length<=0) {
					boolAllSelected = false;
				} else {
					for (var i=0; i<document.getElementsByName("lstGroupsAssigned[]").length; i++) {
						if (document.getElementsByName("lstGroupsAssigned[]")[i].checked==false) {
							boolAllSelected = false;
							break;
						}
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkCheckOrUncheckAllAssignedGroups").checked = true;
				} else {
					document.getElementById("chkCheckOrUncheckAllAssignedGroups").checked = false;
				}
			}
			/* Group Handling */
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_user_new_update.php">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="2">New User</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="2">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="top">
																								<table width="100%" align="center" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> User Type:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<select id="ddUserIEType" name="ddUserIEType" size="1" class="clsTextField" style="width:15%;" onchange="javascript:doGetUserFormData();">
																												<?php if ($varUserType=="Internal") { ?>
																													<option selected value="Internal">Internal</option>
																												<?php } else { ?>
																													<option value="Internal">Internal</option>
																												<?php } ?>
																												
																												<?php if ($varUserType=="External") { ?>
																													<option selected value="External">External</option>
																												<?php } else { ?>
																													<option value="External">External</option>
																												<?php } ?>
																											</select>
																											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																											<font color="red">*</font> Membership:&nbsp;
																											<select id="ddUserMemType" name="ddUserMemType" size="1" class="clsTextField" style="width:25%;">
																												<option selected value="">---Select Membership---</option>
																											<?php
																												$tQuery = "SELECT * FROM elms_membership_details WHERE mem_id<>20 AND mem_type='" . $varUserType . "'";
																												$tResult = mysql_query($tQuery) or die (mysql_error());
																												while ($tRow = mysql_fetch_array($tResult)) {
																											?>
																													<?php if ($varMemType==$tRow["mem_id"]) { ?>
																														<option selected value="<?php echo $tRow["mem_id"]; ?>"><?php echo $tRow["mem_name"]; ?></option>
																													<?php } else { ?>
																														<option value="<?php echo $tRow["mem_id"]; ?>"><?php echo $tRow["mem_name"]; ?></option>
																													<?php } ?>
																											<?php
																												}
																											?>																											
																											</select>																											
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> Title:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<select id="ddUserTitle" name="ddUserTitle" size="1" class="clsTextField" style="width:8%;">
																												<?php if ($varUserTitle=="Mr.") { ?>
																													<option selected value="Mr.">Mr.</option>
																												<?php } else { ?>
																													<option value="Mr.">Mr.</option>
																												<?php } ?>
																												
																												<?php if ($varUserTitle=="Miss") { ?>
																													<option selected value="Miss">Miss</option>
																												<?php } else { ?>
																													<option value="Miss">Miss</option>
																												<?php } ?>
																												
																												<?php if ($varUserTitle=="Mrs.") { ?>
																													<option selected value="Mrs.">Mrs.</option>
																												<?php } else { ?>
																													<option value="Mrs.">Mrs.</option>
																												<?php } ?>

																												<?php if ($varUserTitle=="Dr.") { ?>
																													<option selected value="Dr.">Dr.</option>
																												<?php } else { ?>
																													<option value="Dr.">Dr.</option>
																												<?php } ?>																												
																											</select>
																										</td>																										
																									</tr>																									
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> First Name:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtFName" name="txtFName" class="clsTextField" style="width:40%" value="<?php echo $varFname; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>																									
																									<tr>
																										<td width="24%" align="right">
																											Last Name:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtLName" name="txtLName" class="clsTextField" style="width:40%" value="<?php echo $varLname; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											Date of Birth:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtDOB" name="txtDOB" class="clsTextField" style="width:15%" value="<?php echo $varDOB; ?>" />
																											<div style="display:inline-block;vertical-align:middle;" onclick="javascript:$('#txtDOB').datepicker('show');"><img width="25" height="25" src="images/calendar_icon.png" style="cursor:pointer" /></div>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> E-mail:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtEmail" name="txtEmail" class="clsTextField" style="width:40%" value="<?php echo $varEmail; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> Mobile:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtPhone" name="txtPhone" class="clsTextField" style="width:25%" value="<?php echo $varPhone; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> User Role:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<select id="ddUserType" name="ddUserType" size="1" class="clsTextField" style="width:15%;" onchange="javascript:doGetUserFormData();">
																												<?php if ($varRole=="Manager") { ?>
																													<option selected value="Manager">Manager</option>
																												<?php } else { ?>
																													<option value="Manager">Manager</option>
																												<?php } ?>
																												
																												<?php if ($varRole=="User") { ?>
																													<option selected value="User">User</option>
																												<?php } else { ?>
																													<option value="User">User</option>
																												<?php } ?>
																											</select>
																											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																											<font color="red">*</font> Reports To:&nbsp;
																											<select id="ddManager" name="ddManager" size="1" class="clsTextField" style="width:28%;" onchange="javascript:doGetUserFormData();">
																												<option selected value="<?php echo $_SESSION['Elms_LoggedInId']; ?>">Administrator</option>
																												<?php
																													if ($varRole=="User") {
																														$tempTQuery = "SELECT user_id, user_fname FROM elms_user_details WHERE user_role='Manager' AND user_status='A' AND user_head=" . $_SESSION['Elms_LoggedInId'] . " ORDER BY user_fname";
																														$managerResult = mysql_query($tempTQuery) or die (mysql_error());
																														while ($tempRow = mysql_fetch_array($managerResult)) {
																												?>
																															<?php if ($varManager==$tempRow["user_id"]) { ?>
																																<option value="<?php echo $tempRow["user_id"]; ?>"><?php echo $tempRow["user_fname"]; ?></option>
																															<?php } else { ?>
																																<option selected value="<?php echo $tempRow["user_id"]; ?>"><?php echo $tempRow["user_fname"]; ?></option>
																															<?php } ?>
																												<?php
																													}	}
																												?>
																											</select>
																										</td>																										
																									</tr>
																									<?php if ($varRole=="Manager") { ?>
																										<tr height="5">
																											<td width="100%" colspan="3"></td>
																										</tr>
																										<tr>
																											<td width="24%" align="right">
																												Select Manager Permission:
																											</td>
																											<td width="1%">
																											</td>																										
																											<td width="75%" align="left">
																												<span id="spanUserPermissionList" name="spanUserPermissionList" style="width:80%; display:inline-block;">
																													<input type="checkbox" id="chkMGPer" name="chkMGPer" value="Y" />&nbsp;Manage Groups (Add/Edit/Delete)
																													&nbsp;&nbsp;
																													<input type="checkbox" id="chkMUPer" name="chkMUPer" value="Y" />&nbsp;Manage Users (Add/Edit/Delete)
																												</span>
																											</td>																										
																										</tr>
																									<?php } ?>																									
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right" valign="top">
																											Assign Group:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<div id="divAssignGroup" name="divAssignGroup">
																												<?php
																													$strTMessage = "";
																													if ($varRole=="Manager") {
																														$tempTQuery = "SELECT ELMSGD.group_assigned, ELMSAG.group_id, ELMSAG.group_name, ELMSAG.user_id FROM elms_group_details ELMSGD INNER JOIN elms_assigned_groups ELMSAG ON ELMSGD.group_id=ELMSAG.group_id WHERE group_type='" . $varUserType . "' AND (ELMSGD.group_assigned='N' AND ELMSAG.group_id<>11 AND ELMSAG.user_id=" . $varManager . ") ORDER BY ELMSAG.group_name";
																													} else {
																														$tempTQuery = "SELECT ELMSGD.group_assigned, ELMSAG.group_id, ELMSAG.group_name, ELMSAG.user_id FROM elms_group_details ELMSGD INNER JOIN elms_assigned_groups ELMSAG ON ELMSGD.group_id=ELMSAG.group_id WHERE group_type='" . $varUserType . "' AND (ELMSAG.group_id<>11 AND ELMSAG.user_id=" . $varManager . ") ORDER BY ELMSAG.group_name";
																													}
																													$tResult = mysql_query($tempTQuery) or die (mysql_error());
																													if (dbNumRows($tResult)<=0) {
																														$strTMessage =  "No groups available.";
																													}
																												?>
																												<table width="100%" align="center" cellspacing="2" cellpadding="2">
																													<tr>
																														<td width="40%" align="left" valign="middle">
																															<b>Available Group(s):</b>
																															<div style="height:5px;"></div>
																															<div style="width:90px; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckAllAvailGroups(document.getElementById('chkCheckOrUncheckAllAvailGroups'));">
																																<input type="checkbox" id="chkCheckOrUncheckAllAvailGroups" name="chkCheckOrUncheckAllAvailGroups" onclick="javascript:doCheckORUncheckAllAvailGroups(this);" />&nbsp;Select All
																															</div>
																															<div style="height:5px;"></div>
																															<div id="divGroupsAvailPanel" name="divGroupsAvailPanel" style="background-color:#f4f4f4; overflow-x:hidden; overflow-y:auto; border:5px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; width:98%; height:175px;">
																																<?php if ($strTMessage=="") { ?>
																																	<?php while ($row = mysql_fetch_array($tResult)) { ?>
																																		<div id="divGroupsAvail_<?php echo $row["group_id"]; ?>" name="divGroupsAvail_<?php echo $row["group_id"]; ?>" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckGroupsAvail(<?php echo $row["group_id"]; ?>);">
																																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																																				<tr>
																																					<td width="5%" align="left" valign="top">
																																						<input type="checkbox" id="lstGroupsAvail_<?php echo $row["group_id"]; ?>" name="lstGroupsAvail[]" value="<?php echo $row["group_id"]; ?>" groupname="<?php echo $row["group_name"]; ?>" onclick="javascript:doCheckORUncheckGroupsAvail(<?php echo $row["group_id"]; ?>);" style="cursor:pointer;" />
																																					</td>
																																					<td align="left" valign="top">
																																						<?php echo $row["group_name"]; ?>
																																					</td>
																																				</tr>
																																			</table>
																																		</div>
																																		<div style="height:3px;"></div>
																																	<?php } ?>
																																<?php } else { ?>
																																	<?php echo $strTMessage; ?>
																																<?php } ?>
																															</div>
																														</td>
																														<td width="10%" align="center" valign="middle">
																															<br /><br /><br />
																															<input type="button" id="btnGAssign" name="btnGAssign" value="&nbsp;Assign&nbsp;" class="clsActionButton" onclick="javascript:doAddSelectedGroup();" /><br /><br />
																															<input type="button" id="btnGRemove" name="btnGRemove" value="Remove" class="clsActionButtonRed" onclick="javascript:doRemoveSelectedGroup();" /><br />
																														</td>
																														<td width="40%" align="left" valign="middle">
																															<b>Assigned Group(s):</b>
																															<div style="height:5px;"></div>
																															<div style="width:90px; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckAllAssignedGroups(document.getElementById('chkCheckOrUncheckAllAssignedGroups'));">
																																<input type="checkbox" id="chkCheckOrUncheckAllAssignedGroups" name="chkCheckOrUncheckAllAssignedGroups" onclick="javascript:doCheckORUncheckAllAssignedGroups(this);" style="cursor:pointer;" />&nbsp;Select All
																															</div>																															
																															<div style="height:5px;"></div>																															
																															<div id="divGroupsAssignedPanel" name="divGroupsAssignedPanel" style="background-color:#f4f4f4; overflow-x:hidden; overflow-y:auto; border:5px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; width:98%; height:175px;">
																															</div>																															
																														</td>
																													</tr>
																												</table>
																											</div>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											Status:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<?php if ($varStatus=="A") { ?>
																												<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusA'), document.getElementById('rdStatusA').value);"><input id="rdStatusA" name="rdStatusA" type="radio" value="A" checked onclick="javascript:doPutStatusVal(this, this.value);" />Active</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusI'), document.getElementById('rdStatusI').value);"><input id="rdStatusI" name="rdStatusI" type="radio" value="I" onclick="javascript:doPutStatusVal(this, this.value);" />Inactive</div>
																											<?php } else { ?>
																												<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusA'), document.getElementById('rdStatusA').value);"><input id="rdStatusA" name="rdStatusA" type="radio" value="A" onclick="javascript:doPutStatusVal(this, this.value);" />Active</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusI'), document.getElementById('rdStatusI').value);"><input id="rdStatusI" name="rdStatusI" type="radio" value="I" checked onclick="javascript:doPutStatusVal(this, this.value);" />Inactive</div>
																											<?php } ?>
																										</td>																										
																									</tr>																									
																									<tr height="10">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="100%" align="center" colspan="3">
																											<input type="button" value="Save" class="clsActionButton" onclick="javascript:doFormValidation();" />
																											<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_user_list.php');" />																										
																										</td>
																									</tr>
																									<tr height="10">
																										<td width="100%" colspan="3"></td>
																									</tr>																									
																								</table>
																							</td>																						
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtStatus" name="txtStatus" type="hidden" value="<?php echo $varStatus; ?>" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>