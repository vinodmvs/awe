<?php
	require("elms_top_includes.php");
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doInitialize() {
				document.frmMain.ddGroup.focus();
				var options = {
					beforeSubmit:showRequest,
					success:showResponse
				};
				$('#frmMain').ajaxForm(options);
			}

			function showRequest(formData, jqForm, options) {
				doShowProccessIcon();
			}

			function showResponse(responseText, statusText, xhr, $form) {
				strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
				if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
					document.location.href = "elms_course_list.php";
				} else {
					doShowAlertPanel(strAjaxReturnTrimed, '');
				}
				doHideProccessIcon();
			}

			function doFormValidation() {
				if (document.frmMain.ddGroup.value=="") {
					doShowAlertPanel("Please select the User to assign the Group.", document.frmMain.ddUser);
					return false;
				} else {
					return true;
				}
			}
		</script>
	</head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0" onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_course_assign_group_wise_update.php" onsubmit="javascript:return doFormValidation();">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="2">Assign Course</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="2">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<tr>
																							<td width="50%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="center">
																											<table width="87%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="100%" align="left" valign="middle">
																														<font color="red">*</font> Group:
																														<select id="ddGroup" name="ddGroup" size="1" class="clsTextField" style="width:25%;" onchange="javascrit:doDisplayUserAvailAssignedCoursesGroupWise(<?php echo $_SESSION["Elms_LoggedInId"]; ?>);">
																															<option selected value="">---Select the Group---</option>
																															<?php
																																$tempTQuery = "SELECT * FROM elms_assigned_groups WHERE user_id=" . $_SESSION["Elms_LoggedInId"];
																																$groupResult = mysql_query($tempTQuery) or die (mysql_error());
																																while ($tempRow = mysql_fetch_array($groupResult)) {
																																	$tempDispQuery = "SELECT group_type FROM elms_group_details WHERE group_id=" . $tempRow["group_id"];
																																	$tempDispResult = mysql_query($tempDispQuery) or die (mysql_error());
																																	$tempDispRow = mysql_fetch_array($tempDispResult);																																	
																															?>
																																	<?php if ($tempDispRow["group_type"]=="Internal") { ?>
																																		<option value="<?php echo $tempRow["group_id"]; ?>" style="color:green;"><?php echo $tempRow["group_name"]; ?> [<?php echo $tempDispRow["group_type"]; ?>]</option>
																																	<?php } else { ?>
																																		<option value="<?php echo $tempRow["group_id"]; ?>" style="color:blue;"><?php echo $tempRow["group_name"]; ?> [<?php echo $tempDispRow["group_type"]; ?>]</option>
																																	<?php } ?>
																															<?php
																																}
																															?>
																														</select>
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr>
																							<td width="12%" align="right" valign="top">Assign Course:</td>
																							<td width="88%" align="left" valign="middle">
																								<div id="divAssignCourse" name="divAssignCourse" style="display:block;">
																									<table width="100%" align="center" cellspacing="2" cellpadding="2">
																										<tr>
																											<td width="40%" align="left" valign="middle">
																												<b>Available Course(s):</b><br />
																												<select id="lstCoursesAvail" name="lstCoursesAvail" size="6" class="clsTextField" style="width:100%;" onclick="javascript:doDeSelectSelectedCourse();">
																												</select>
																											</td>
																											<td width="10%" align="center" valign="middle">
																												<br />
																												<input type="button" id="btnGAssign" name="btnGAssign" value="&nbsp;Assign&nbsp;" class="clsActionButton" onclick="javascript:doAddSelectedCourse();" /><br /><br />
																												<input type="button" id="btnGRemove" name="btnGRemove" value="Remove" class="clsActionButtonRed" onclick="javascript:doRemoveSelectedCourse();" /><br />
																											</td>
																											<td width="40%" align="left" valign="middle">
																												<b>Assigned Course(s):</b><br />
																												<select id="lstCoursesAssigned" name="lstCoursesAssigned" size="6" class="clsTextField" style="width:100%;" onclick="javascript:doDeSelectAvailedCourse();">
																												</select>
																											</td>
																										</tr>
																									</table>
																								</div>
																							</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="100%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="center">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="100%" align="right" valign="middle">
																														<input type="submit" id="btnFinish" name="btnFinish" value="&nbsp;Finish&nbsp;" class="clsActionButton" />
																														<input type="button" id="btnCancel" name="btnCancel" value="Cancel" class="clsActionButton" onclick="javascript:doCancel('elms_course_list.php');" />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="2">
																							<td colspan="2"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtTempRMCourses" name="txtTempRMCourses" type="hidden" value="" />
																		<input id="txtCourses" name="txtCourses" type="hidden" value="" />
																		<input id="txtTempCourses" name="txtTempCourses" type="hidden" value="" />
																		<input id="txtUser" name="txtUser" type="hidden" value="<?php echo $_SESSION["Elms_LoggedInId"]; ?>" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="100">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>