<?php
	require("elms_top_includes.php");
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
		</script>
	</head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_branding_details_update.php" onsubmit="javascript:return doFormValidation();">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" cellspacing="0" cellpadding="0" align="center">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="2">Account Details</td>
																						</tr>
																						<?php
																							$strMessage = "";
																							$varST = 0;
																							$varRegDate = "";
																							$varPurDate = "";
																							$varRenDate = "";
																							$varImgPath = "";
																							$varFeatureText = "";
																							
																							/*
																							$dbHost = 'localhost';
																							$dbUser = 'root';
																							$dbPass = '';
																							$dbName = 'mvslms';
																							*/
																							
																							$dbHost = 'localhost';
																							$dbUser = 'mvslmsdbadmin';
																							$dbPass = 'MvsLMSDBAdminGoodLuck123';
																							$dbName = 'mvslms';

																							$dbConn = mysql_connect($dbHost, $dbUser, $dbPass);

																							if (!$dbConn) {
																								$strMessage = "<b>Error: </b>MYSQL Server Connection Error: Could not connect to MYSQL SERVER " . mysql_error();
																							} else {
																								$db = mysql_select_db($dbName);
																								if (!$db) {
																									$strMessage = "<b>Error: </b>MYSQL Server Database Error: Could not select the MYSQL SERVER Database " . mysql_error();
																								} else {
																									$tempQuery = "SELECT * FROM elms_customer_details WHERE customer_email='" . $_SESSION["Elms_LoggedInEmail"] . "'";
																									$tResult = mysql_query($tempQuery) or die (mysql_error());
																									if ($tRow = mysql_fetch_array($tResult)) {
																										if ($tRow["customer_ispurchased"]=="N") {
																											$strMessage = "<b>Note: </b>You are in trail mode, the account information only available for purchased customer.";
																										} else {
																											$varST = $tRow["customer_subscription_type"];
																											$varRegDate = $tRow["customer_created_date"];
																											$varPurDate = $tRow["customer_purchased_date"];
																											$varOneYearAdd = strtotime(date("Y-m-d", strtotime($varPurDate)) . " +1 year");
																											$varRenDate = date("l dS \ \f F Y", $varOneYearAdd);
																										}
																									} else {
																										$strMessage = "<b>Error: </b>MYSQL Server Database Error: Could not select the MYSQL SERVER Database " . mysql_error();
																									}
																								}
																							}
																						?>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="center">
																											<table width="33%" cellspacing="0" cellpadding="0">
																												<?php
																													if ($strMessage != "") {
																												?>
																														<tr height="2">
																															<td></td>
																														</tr>																												
																														<tr>
																															<td width="100%" align="center" valign="top">
																																<?php echo $strMessage; ?>
																															</td>
																														</tr>
																												<?php
																													} else {
																												?>
																														<tr height="2">
																															<td colspan="3"></td>
																														</tr>																												
																														<tr>
																															<td width="40%" align="left" valign="top">
																																Subscription Type:
																															</td>
																															<td width="1%"></td>
																															<td width="59%" align="left" valign="middle">
																																<?php
																																	switch ($varST) {
																																		case 1:
																																			$varImgPath = "images/basic.png";
																																			$varFeatureText = "upto 100 User Accounts<br />Custom Branding<br />Free Hosting<br />Free 24/7 E-mail Support";
																																			break;
																																		case 2:
																																			$varImgPath = "images/advanced.png";
																																			$varFeatureText = "upto 250 User Accounts<br />Custom Branding<br />Free Hosting<br />Free 24/7 E-mail Support";
																																			break;
																																		case 3:
																																			$varImgPath = "images/premium.png";
																																			$varFeatureText = "upto 500 User Accounts<br />Custom Branding<br />Free Hosting<br />Free 24/7 E-mail Support";
																																			break;
																																		case 4:
																																			$varImgPath = "images/ultimate.png";
																																			$varFeatureText = "Unlimited User Accounts<br />Custom Branding<br />Free Hosting<br />Free 24/7 E-mail Support";
																																			break;																																			
																																	}
																																?>																															
																																<img src="<?php echo $varImgPath; ?>" alt="" title="" />
																															</td>
																														</tr>
																														<tr height="20">
																															<td colspan="3"></td>
																														</tr>																															
																														<tr>
																															<td width="40%" align="left" valign="top">
																																Features:
																															</td>
																															<td width="1%"></td>
																															<td width="59%" align="left" valign="middle">
																																<?php echo $varFeatureText; ?>
																															</td>
																														</tr>																														
																														<tr height="20">
																															<td colspan="3"></td>
																														</tr>																														
																														<tr>
																															<td width="40%" align="left" valign="top">
																																Registered Date:
																															</td>
																															<td width="1%"></td>
																															<td width="59%" align="left" valign="middle">
																																<?php echo $varRegDate; ?>
																															</td>
																														</tr>
																														<tr height="20">
																															<td colspan="3"></td>
																														</tr>																														
																														<tr>
																															<td width="40%" align="left" valign="top">
																																Purchased Date:
																															</td>
																															<td width="1%"></td>
																															<td width="59%" align="left" valign="middle">
																																<?php echo $varPurDate; ?>
																															</td>
																														</tr>
																														<tr height="20">
																															<td colspan="3"></td>
																														</tr>																														
																														<tr>
																															<td width="40%" align="left" valign="top">
																																Renewal Date:
																															</td>
																															<td width="1%"></td>
																															<td width="59%" align="left" valign="middle">
																																<?php echo $varRenDate; ?>
																															</td>
																														</tr>																														
																												<?php
																													}
																												?>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="10">
																							<td colspan="2"</td>
																						</tr>

																						<tr height="2">
																							<td colspan="2"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="100">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>