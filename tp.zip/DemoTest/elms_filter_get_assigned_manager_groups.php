<?php
	require("elms_top_includes.php");
?>

<?php
	$strUserId = "";
	$strMessage = "";
	$strDispAssignedGroups = "";

	if (!isset($_POST["UserId"])) {
		header("Location:index.php");
	} else {
		$strUserId = $_POST["UserId"];
		if ($strUserId=="") {
			$tQuery = "SELECT * FROM elms_assigned_groups WHERE user_id=" . $_SESSION["Elms_LoggedInId"];
		} else {
			$tQuery = "SELECT * FROM elms_assigned_groups WHERE user_id=" . $strUserId;
		}
		$tResult = mysql_query($tQuery) or die (mysql_error());
		$tempResult = mysql_query($tQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
		} else {
			while ($tRow = mysql_fetch_array($tResult)) {
				if ($strDispAssignedGroups=="") {
					$strDispAssignedGroups = $tRow["group_id"] . "~" . $tRow["group_name"];
				} else {
					$strDispAssignedGroups = $strDispAssignedGroups. "ELMS_SPL" . $tRow["group_id"] . "~" . $tRow["group_name"];
				}
			}
		}

		if ($strDispAssignedGroups=="") $strDispAssignedGroups = "NoGroups";
		$strMessage = $strDispAssignedGroups;

		echo $strMessage;
	}
?>