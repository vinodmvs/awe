<?php
	require("elms_top_includes.php");
?>

<?php
	$varID = "";
	$strMessage = "";
	$varName = "";
	$varCat = "";
	$varDesc = "";
	$varPrice = "";
	$varDiscount = "";
	$varThumbImgName = "course_thumb_default.png";
	$varImgUploadError = "";
	if (!isset($_POST["txtCourseId"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["txtCourseId"];
		$_SESSION["Elms_CourseEditId"] = $varID;
		$varName = $_POST["txtName"];
		$varDDCat = $_POST["ddCat"];
		$varTxtCat = $_POST["txtCat"];
		$varTxtCat = str_replace("'", "\\'", $varTxtCat);
		$varCat = "";
		$varThumbImgName = $_POST["txtThumbImgName"];
		if (isset($_FILES["txtThumbImg"]) && $_FILES["txtThumbImg"]["name"]) {
			$strTargetPath = dirname(__FILE__) . "/images/course_catalog/";
			$strUploadMaxFileSize = ini_get('upload_max_filesize');
			$intUploadMaxFileSize = (int)substr($strUploadMaxFileSize, 0, -1);
			$intSourceFileSize = (int)(($_FILES['txtThumbImg']['size']/1024)/1024);		
			if ($intSourceFileSize < $intUploadMaxFileSize) {
				$strFilename = $_FILES["txtThumbImg"]["name"];
				$strSource = $_FILES["txtThumbImg"]["tmp_name"];
				$strType = $_FILES["txtThumbImg"]["type"];
				$strName = explode(".", $strFilename);
				if ($varThumbImgName=="course_thumb_default.png") {
					$varRndId = doGenerateRNDNum(5, false, 'd');
					$tempFile = "course_thumb_" . $varRndId . "_" . $strName[0] . "." . $strName[1];
				} else {
					$tempFile = $varThumbImgName;
				}				
				$strUploadPath = $strTargetPath . $tempFile;
				if (move_uploaded_file($strSource, $strUploadPath)) {
					$varThumbImgName = $tempFile;
				} else {
					$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not upload the Image file. Please try again!";
					header("Location:elms_course_edit.php");
				}
			} else {
				$_SESSION["Elms_ResMsg"] = "The upload Image file size is too large. Please try with the size of less than or equal to 2 MB.";
				header("Location:elms_course_edit.php");
			}
		}		
		if ($varImgUploadError=="") {
			if ($varDDCat=="") {
				$tQuery = "SELECT category_id FROM elms_category_details WHERE category_name='" . trim($varTxtCat) . "'";
				$tUpdate = mysql_query($tQuery) or die (mysql_error());
				if (dbNumRows($tUpdate)>0) {
					$tRow = mysql_fetch_array($tUpdate);
					$varCat = $tRow["category_id"];
				} else {
					$strTQuery = "INSERT INTO elms_category_details(category_name,category_created) VALUES('" . $varTxtCat . "','" . date('Y-m-d') . "')";
					$rstTResult = mysql_query($strTQuery) or die (mysql_error());
					$varCat = dbInsertId();
				}
			} else {
				$varCat = $varDDCat;
			}
			$varDesc = $_POST["txtDesc"];
			$varIsCert = $_POST["txtCertYN"];
			
			if (isset($_POST["txtPrice"])) {
				$varPrice = $_POST["txtPrice"];
				$varDiscount = $_POST["txtDiscount"];
			}
			
			$tempQuery = "UPDATE elms_course_details SET course_image='" . $varThumbImgName . "', course_dis_price='" . $varDiscount . "',course_cat=" . $varCat . ",course_name='" . str_replace("'", "\\'", $_POST["txtName"]) . "',course_desc='" . str_replace("'", "\\'", $_POST["txtDesc"]) . "',course_iscert='" . $varIsCert . "',course_price='" . $varPrice . "' WHERE course_id=" . $varID;
			$qUpdate = mysql_query($tempQuery) or die (mysql_error());

			$tempQuery = "UPDATE elms_assigned_courses SET course_name='" . $varName . "' WHERE course_id=" . $varID;
			$tempResult = mysql_query($tempQuery);
			
			$tempQuery = "UPDATE elms_assigned_courses_group_wise SET course_name='" . $varName . "' WHERE course_id=" . $varID;
			$tempResult = mysql_query($tempQuery);		

			if ($tempResult) {
				header("Location:elms_course_list.php");
			} else {
				$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not update the Course details. Please try again!";
				header("Location:elms_course_edit.php");
			}
		} else {
		}
	}
?>