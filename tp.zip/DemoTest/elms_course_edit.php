<?php
	require("elms_top_includes.php");
?>

<?php
	$varID = "";
	if (isset($_SESSION["Elms_CourseEditId"]) && $_SESSION["Elms_CourseEditId"]!="") {
		$varID = $_SESSION["Elms_CourseEditId"];
		$tempQuery = "SELECT * FROM elms_course_details WHERE course_id=" . $varID;
		$courseResult = mysql_query($tempQuery) or die (mysql_error());
		$courseRow = mysql_fetch_array($courseResult);

		$tempQuery = "SELECT * FROM elms_category_details ORDER BY category_name";
		$categoryResult = mysql_query($tempQuery) or die (mysql_error());
	} else {
		if (!isset($_POST["txtCourseId"])) {
			header("Location:index.php");
		} else {
			$varID = $_POST["txtCourseId"];
			$tempQuery = "SELECT * FROM elms_course_details WHERE course_id=" . $varID;
			$courseResult = mysql_query($tempQuery) or die (mysql_error());
			$courseRow = mysql_fetch_array($courseResult);

			$tempQuery = "SELECT * FROM elms_category_details ORDER BY category_name";
			$categoryResult = mysql_query($tempQuery) or die (mysql_error());
		}	
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			var strValidImageFileExtensions = [".jpg", ".jpeg", ".png", ".gif"];
			
		    function doInitialize() {
		    	document.frmMain.txtName.focus();
			}

			function doFormValidation() {
				if (document.frmMain.txtName.value=="") {
					doShowAlertPanel("Please enter the Course Name.", document.frmMain.txtName);
				} else {
				if (document.frmMain.ddCat.value=="" && document.frmMain.txtCat.value=="") {
					doShowAlertPanel("Please select the Course Category or enter new one.", document.frmMain.txtCat);
				} else {
				if (document.frmMain.txtUserType.value=="Both" && document.frmMain.txtOfferType.value=="N" && document.frmMain.txtPrice.value=="") {
					doShowAlertPanel("Please enter the Course Price.", document.frmMain.txtPrice);
				} else {
				if (document.frmMain.txtUserType.value=="Both" && document.frmMain.txtOfferType.value=="N" && parseFloat(document.frmMain.txtPrice.value).toString()=='NaN') {
					doShowAlertPanel("Please enter the valid Course Price.", document.frmMain.txtPrice);
				} else {
				if (document.frmMain.txtThumbImg.value!="" && !doValidFileExtension(document.frmMain.txtThumbImg.value, strValidImageFileExtensions)) {
					doShowAlertPanel("Invalid Image file. Please choose the valid file.", document.frmMain.txtThumbImg);
				} else {				
					doShowProccessIcon();
					document.frmMain.submit();
				} } } } }
			}
			
			function doValidFileExtension(strTemp, arrTemp){
				var varRetVal = false;
				var sCurExtension = "";
				for (var i=0; i<arrTemp.length; i++) {
					sCurExtension = arrTemp[i];
					if (strTemp.substr(strTemp.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
						varRetVal = true;
						break;
					}
				}
				return varRetVal;
			}			
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" enctype="multipart/form-data" action="elms_course_edit_update.php">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="3">Edit Course</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="3">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<?php
																							$varDispError = "";
																							if (isset($_SESSION["Elms_ResMsg"])) {
																								if ($_SESSION["Elms_ResMsg"]!="") { $varDispError = $_SESSION["Elms_ResMsg"]; }
																								$_SESSION["Elms_ResMsg"] = "";
																							}
																						?>
																						<?php if ($varDispError!="") { ?>
																							<tr height="15">
																								<td width="100%" align="center" valign="middle" colspan="3">
																								</td>
																							</tr>																			
																							<tr>
																								<td width="100%" align="center" valign="middle" colspan="3" class="clsResErrorMsgText">
																									<font color="green"><?php echo $varDispError; ?></font>
																								</td>
																							</tr>
																							<tr height="15">
																								<td width="100%" align="center" valign="middle" colspan="3">
																								</td>
																							</tr>
																						<?php } ?>																						
																						<tr>
																							<td width="25%" align="right" valign="middle"><font color="red">*</font> Course Name:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle"><input type="text" id="txtName" name="txtName" class="clsTextField" value="<?php echo $courseRow["course_name"]; ?>" style="width:65%" /></td>
																						</tr>
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top"><font color="red">*</font> Category:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="top">
																								<font color="red"><b>Note:</b></font> Select the category or enter new
																								<br />
																								<select id="ddCat" name="ddCat" class="clsTextField" style="width:200px;" onchange="javascript:doEnableNewCategory();">
																									<option selected value="">New Category</option>
																									<?php
																										$strTempCat = "";
																										while ($row = mysql_fetch_array($categoryResult)) {
																											if ($row["category_id"]==$courseRow["course_cat"]) {
																												$strTempCat = $row["category_name"];
																									?>
																												<option selected value="<?php echo $row["category_id"]; ?>"><?php echo $row["category_name"]; ?></option>
																									<?php
																											} else {
																									?>
																												<option value="<?php echo $row["category_id"]; ?>"><?php echo $row["category_name"]; ?></option>
																									<?php
																											}
																										}
																									?>
																								</select>
																								<input type="text" id="txtCat" name="txtCat" value="<?php echo $strTempCat; ?>" readonly class="clsTextField" style="width:42%" />
																							</td>
																						</tr>
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Course Type:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<?php
																									$varTempDisplay = "SCORM";
																									if ($courseRow["course_type"]=="SCORM") {
																										$varTempDisplay = "SCORM Package";
																									} else {
																										$varTempDisplay = "Normal Web Package";
																									}
																									echo $varTempDisplay;
																								?>
																							</td>
																						</tr>
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Description:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<textarea id="txtDesc" name="txtDesc" class="clsTextField" style="width:65%; height:100px; resize:none;"><?php echo $courseRow["course_desc"]; ?></textarea>
																							</td>
																						</tr>
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="25%" align="right" valign="top">Thumbnail Picture:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<font color="red"><b>Note:</b></font> If you wish to replace the existing thumbnail image browse the file. The image file should be (jpg, jpeg, png or gif) with DIM of 320x240 or less and file size should be less then or eaqual to 2 MB.
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="25%" align="right" valign="top"></td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<input id="txtThumbImg" name="txtThumbImg" class="clsTextField" type="file"  />
																							</td>
																						</tr>
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">This Course For:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<?php if ($courseRow["course_for"]=="InternalOnly") { ?>
																									Internal Users Only
																								<?php } else  { ?>
																								<?php if ($courseRow["course_for"]=="ExternalOnly") { ?>
																									External Users Only
																								<?php } else  { ?>
																									Internal and External Users
																								<?php } } ?>
																							</td>
																						</tr>																						
																						<tr>
																							<td width="100%" colspan="3">
																								<?php if ($courseRow["course_for"]=="InternalOnly") { ?>
																									<div id="divOffer" name="divOffer" style="display:none;">
																								<?php } else  { ?>
																									<div id="divOffer" name="divOffer" style="display:block;">
																								<?php } ?>
																									<table width="100%" cellspacing="0" cellpadding="0">
																										<tr height="25">
																											<td width="100%" colspan="3"></td>
																										</tr>																									
																										<tr height="1">
																											<td width="25%" align="right" valign="top">Offer Type for External Users:</td>
																											<td width="1%"></td>
																											<td width="84%" align="left" valign="middle">
																												<?php if ($courseRow["course_isfree"]=="Y") { ?>
																													Free
																												<?php } else  { ?>
																													Paid
																												<?php } ?>
																												<?php if ($courseRow["course_isfree"]=="Y") { ?>
																													<div id="divCourseSubInfo" name="divCourseSubInfo" style="display:none;">
																												<?php } else  { ?>
																													<div id="divCourseSubInfo" name="divCourseSubInfo" style="display:block;">
																												<?php } ?>
																													<div style="height:5px;"></div>
																													<table cellspacing="0" cellpadding="0" border="0">
																														<tr>
																															<td align="left" valign="middle">
																																Price:
																															</td>
																															<td align="left" valign="middle">
																																&nbsp;
																																<input type="text" id="txtPrice" name="txtPrice" class="clsTextField" style="width:50px; height:15px;" value="<?php echo $courseRow["course_price"]; ?>" />
																																&nbsp;&nbsp;&nbsp;&nbsp;
																															</td>
																															<td align="left" valign="middle">
																																Discount:
																															</td>
																															<td align="left" valign="middle">
																																&nbsp;
																																<input type="text" id="txtDiscount" name="txtDiscount" class="clsTextField" style="width:50px; height:15px;" value="<?php echo $courseRow["course_dis_price"]; ?>" />
																															</td>																															
																														</tr>
																													</table>
																												</div>
																											</td>
																										</tr>
																									</table>
																								</div>
																							</td>
																						</tr>
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Membership:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<div id="divMemList" name="divMemList">
																									<?php
																										if ($courseRow["course_mem_type"]!="" && $courseRow["course_mem_type"]!="N/A") {
																											$varTempMemListValArray = explode("~", $courseRow["course_mem_type"]);
																									?>
																									<?php
																											for ($k=0; $k<count($varTempMemListValArray); $k++) {
																									?>
																											<?php
																												$tQuery = "SELECT * FROM elms_membership_details WHERE mem_id=" . $varTempMemListValArray[$k];
																												$tResult = mysql_query($tQuery) or die (mysql_error());
																												$tRow = mysql_fetch_array($tResult);
																											?>
																											<div style="display:inline-block; cursor:pointer;"><?php echo $tRow["mem_name"]; ?> <b>[<?php echo $tRow["mem_type"]; ?>]</b></div>
																											<?php
																												if ($k<count($varTempMemListValArray)-1) {
																													echo ",&nbsp;";
																												}
																											?>
																									<?php
																											}
																										}
																									?>																									
																								</div>
																							</td>
																						</tr>																						
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Certificate:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<?php if ($courseRow["course_iscert"]=="Y") { ?>
																									<input id="rdCertY" name="rdCertY" type="radio" value="Y" checked onclick="javascript:doPutCertificateYN(this, this.value);" />Yes&nbsp;&nbsp;<input id="rdCertN" name="rdCertN" type="radio" value="N" onclick="javascript:doPutCertificateYN(this, this.value);" />No
																								<?php } else  { ?>
																									<input id="rdCertY" name="rdCertY" type="radio" value="Y" onclick="javascript:doPutCertificateYN(this, this.value);" />Yes&nbsp;&nbsp;<input id="rdCertN" name="rdCertN" type="radio" value="N" checked onclick="javascript:doPutCertificateYN(this, this.value);" />No
																								<?php } ?>
																							</td>
																						</tr>																						
																						<tr>
																							<td width="98%" align="left" valign="middle" colspan="3">
																								<table width="99%" cellspacing="0" cellpadding="0">
																									<tr>
																										<td width="99%" align="right" valign="middle">
																											<input type="button" value="&nbsp;Update&nbsp;" class="clsActionButton" onclick="javascript:doFormValidation();" />
																											<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_course_list.php');" />
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="15">
																							<td colspan="3"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtCourseId" name="txtCourseId" type="hidden" value="<?php echo $courseRow["course_id"]; ?>" />
																		<input id="txtUserType" name="txtUserType" type="hidden" value="<?php echo $courseRow["course_for"]; ?>" />
																		<input id="txtOfferType" name="txtOfferType" type="hidden" value="<?php echo $courseRow["course_isfree"]; ?>" />
																		<input id="txtCertYN" name="txtCertYN" type="hidden" value="<?php echo $courseRow["course_iscert"]; ?>" />
																		<input id="txtThumbImgName" name="txtThumbImgName" type="hidden" value="<?php echo $courseRow["course_image"]; ?>" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
					<div id="divPicture" name="divPicture" style="position:absolute; right:50px; top:350px; border:5px solid #cccccc;">
						<img width="250" height="250" src="images/course_catalog/<?php echo $courseRow["course_image"]; ?>" />
					</div>					
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>

<?php
	$_SESSION["Elms_CourseEditId"] = "";
?>