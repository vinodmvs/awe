<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varType = "";
	$varName = "";
	$varDesc = "";
	$varStatus = "";
	$varAssigned = "";
	$varCreatedDate = "";

	if (!isset($_POST["txtName"])) {
		header("Location:index.php");
	} else {
		$varName = $_POST["txtName"];
		$varName = trim($varName);
		$varName = str_replace("'", "\\'", $varName);
		$varType = $_POST["ddType"];
		$varDesc = $_POST["txtDesc"];
		$varDesc = str_replace("'", "\\'", $varDesc);
		$varStatus = $_POST["txtStatus"];
		$varAssigned = "N";
		$varCreatedDate = date('Y-m-d');

		$tempQuery = "SELECT * FROM elms_group_details WHERE group_type='" . $varType . "' AND group_name='" . trim($varName) . "'";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
			$tempQuery = "INSERT INTO elms_group_details(group_type,group_name,group_desc,group_status,group_created_by,group_assigned,group_created) VALUES('" . $varType . "','" . trim($varName) . "','" . $varDesc . "','" . $varStatus . "'," . $_SESSION["Elms_LoggedInId"] . ",'" . $varAssigned . "','" . $varCreatedDate .  "')";
			$tempResult = mysql_query($tempQuery);

			$intTempId = dbInsertId();

			$tempQuery = "INSERT INTO elms_assigned_groups(user_id,group_id,group_name,assigned_date) VALUES(" . $_SESSION["Elms_LoggedInId"] . "," . $intTempId . ",'" . trim($varName) . "','" . $varCreatedDate . "')";
			$tempResult = mysql_query($tempQuery);
			
			if ($varType=="Internal") {
				$tempQuery = "SELECT * FROM elms_course_details";
			} else {
				$tempQuery = "SELECT * FROM elms_course_details WHERE course_isfree='Y' AND course_for='Both'";
			}			
			$tResult = mysql_query($tempQuery) or die (mysql_error());
			while ($tRow = mysql_fetch_array($tResult)) {
				$tDelQuery = "DELETE FROM elms_assigned_courses_group_wise WHERE group_id=" . $intTempId . " AND course_id=" . $tRow["course_id"];
				$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
				$tempQuery = "INSERT INTO elms_assigned_courses_group_wise(group_id,course_id,course_name,assigned_date) VALUES(" . $intTempId . "," . $tRow["course_id"] . ",'" . str_replace("'", "\\'", $tRow["course_name"]) . "','" . $varCreatedDate . "')";
				$qUpdate = mysql_query($tempQuery) or die (mysql_error());								
			}

			if ($tempResult) {
				$strMessage = "ELMS_SUCCESS";
			} else {
				$strMessage = "Unfortunately the system could not update the Group details. Please try again!";
			}
		} else {
			$strMessage = "The entered Group name already exists. Please enter another Group.";
		}
		echo $strMessage;
	}
?>