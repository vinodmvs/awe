<?php
	require("elms_top_includes.php");
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doInitialize() {
				document.frmMain.ddUser.focus();
				var options = {
					beforeSubmit:showRequest,
					success:showResponse
				};
				$('#frmMain').ajaxForm(options);
			}

			function showRequest(formData, jqForm, options) {
				doShowProccessIcon();
			}

			function showResponse(responseText, statusText, xhr, $form) {
				strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
				if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
					document.location.href = "elms_admin_group_list.php";
				} else {
					doShowAlertPanel(strAjaxReturnTrimed, '');
				}
				doHideProccessIcon();
			}

			function doFormValidation() {
				if (document.frmMain.ddUser.value=="") {
					doShowAlertPanel("Please select the User to assign the Group.", document.frmMain.ddUser);
					return false;
				} else {
					return true;
				}
			}
		</script>
	</head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0" onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_group_assign_update.php" onsubmit="javascript:return doFormValidation();">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="2">Assign Group</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="2">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<tr>
																							<td width="50%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="center">
																											<table width="87%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="100%" align="left" valign="middle">
																														&nbsp;<font color="red">*</font> User:
																														<select id="ddUser" name="ddUser" size="1" class="clsTextField" style="width:25%;" onchange="javascript:doDisplayUserAvailAssignedGroups(document.frmMain.ddUser.value);">
																															<option selected value="">Select the user</option>
																															<?php
																																$tempTQuery = "SELECT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_status='A' ORDER BY ELMSUserDetailsList.user_id";
																																$userResult = mysql_query($tempTQuery) or die (mysql_error());
																																while ($tempRow = mysql_fetch_array($userResult)) {
																																	$tempName = "";
																																	if ($tempRow['user_role']=='User') {
																																		$tempName = "Learner";
																																	} else {
																																		$tempName = $tempRow['user_role'];
																																	}

																																	if ($tempRow['user_role']=='Manager') {
																															?>

																																		<option style="color: #0000ff" value="<?php echo $tempRow["user_id"]; ?>"><?php echo $tempRow["user_fname"] . " [" . $tempName . "]"; ?></option>
																															<?php
																																	} else {
																															?>
																																		<option style="color: #000000" value="<?php echo $tempRow["user_id"]; ?>"><?php echo $tempRow["user_fname"] . " [" . $tempName . "]"; ?></option>
																															<?php
																																	}
																															?>
																															<?php
																																}
																															?>
																														</select>
																														<span id="spanUserRole" name="spanUserRole" style="visibility:hidden;">
																															&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																															User Role: <span id="spanUserRoleText" name="spanUserRoleText">N/A</span>
																														</span>
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr>
																							<td width="12%" align="right" valign="top">Assign Group:</td>
																							<td width="88%" align="left" valign="middle">
																								<div id="divAssignGroup" name="divAssignGroup" style="display:block;">
																									<table width="100%" align="center" cellspacing="2" cellpadding="2">
																										<tr>
																											<td width="40%" align="left" valign="middle">
																												<b>Available Group(s):</b><br />
																												<select id="lstGroupsAvail" name="lstAMGroupsAvail" size="6" class="clsTextField" style="width:100%;" onclick="javascript:doDeSelectSelectedGroup();">
																												</select>
																											</td>
																											<td width="10%" align="center" valign="middle">
																												<br />
																												<input type="button" id="btnGAssign" name="btnGAssign" value="&nbsp;Assign&nbsp;" class="clsActionButton" onclick="javascript:doAddSelectedGroup();" /><br />
																												<input type="button" id="btnGRemove" name="btnGRemove" value="Remove" class="clsActionButtonRed" onclick="javascript:doRemoveSelectedGroup();" /><br />
																											</td>
																											<td width="40%" align="left" valign="middle">
																												<b>Assigned Group(s):</b><br />
																												<select id="lstGroupsAssigned" name="lstGroupsAssigned" size="6" class="clsTextField" style="width:100%;" onclick="javascript:doDeSelectAvailedGroup();">
																												</select>
																											</td>
																										</tr>
																									</table>
																								</div>
																							</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="100%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="center">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="100%" align="right" valign="middle">
																														<input type="submit" id="btnFinish" name="btnFinish" value="&nbsp;Finish&nbsp;" class="clsActionButton" />
																														<input type="button" id="btnCancel" name="btnCancel" value="Cancel" class="clsActionButton" onclick="javascript:doCancel('elms_admin_group_list.php');" />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="2">
																							<td colspan="2"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtRMGroups" name="txtRMGroups" type="hidden" value="" />
																		<input id="txtGroups" name="txtGroups" type="hidden" value="" />
																		<input id="txtTempGroups" name="txtTempGroups" type="hidden" value="" />
																		<input id="txtUserRole" name="txtUserRole" type="hidden" value="" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="100">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>