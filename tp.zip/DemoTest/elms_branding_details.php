<?php
	require("elms_top_includes.php");
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			strValidFileExtensions = [".jpg", ".png"];
			function doInitialize() {
				var options = {
					beforeSubmit:showRequest,
					success:showResponse
				};
				$('#frmMain').ajaxForm(options);
			}

			function showRequest(formData, jqForm, options) {
				doShowProccessIcon();
			}

			function showResponse(responseText, statusText, xhr, $form) {
				strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
				if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
					document.location.href = "elms_branding_details.php";
				} else {
					doShowAlertPanel(strAjaxReturnTrimed, '');
				}
				doHideProccessIcon();
			}

			function doPutSocialMediaLinks(objThis, objFiled, strTemp) {
				if (objThis.checked==true) {
					objFiled.value = strTemp;
				} else {
					objFiled.value = "";
				}
			}

			function doCheckFileExtension(theForm){
				var arrInputs = theForm.getElementsByTagName("input");
				for (var i = 0; i < arrInputs.length; i++) {
				var oInput = arrInputs[i];
				if (oInput.type == "file") {
					var sFileName = oInput.value;
					if (sFileName!="") {
						var blnValid = false;
							for (var j = 0; j < strValidFileExtensions.length; j++) {
								var sCurExtension = strValidFileExtensions[j];
								if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
									blnValid = true;
									break;
								}
							}
							if (!blnValid) {
								return false;
							}
						}
					}
				}
				return true;
			}

			function doFormValidation() {
				if (document.frmMain.txtCName.value=="") {
					doShowAlertPanel("Company Name can not be blank. Please enter the Company Name.", document.frmMain.txtCName);
					return false;
				} else {			
				if (document.frmMain.txtREmail.value=="") {
					doShowAlertPanel("Reply E-mail Id can not be blank. Please enter the Reply E-mail Id.", document.frmMain.txtREmail);
					return false;
				} else {
				if (!validEmail(document.frmMain.txtREmail.value)) {
					doShowAlertPanel("Invalid email address format ! \nEvery email address must include one @ sign followed by a domain ne. \nEg: User@Server.com.", document.frmMain.txtREmail);
					return false;
				} else {
				if (!doCheckFileExtension(document.frmMain)) {
					doShowAlertPanel("Invalid logo or custom image file. Please choose the valid file.", '');
					return false;
				} else {
				if (document.frmMain.chkMLY.checked==true && document.frmMain.txtYURL.value=="") {
					doShowAlertPanel("Please enter the Youtube media links URL.", document.frmMain.txtYURL);
					return false;
				} else {
				if (document.frmMain.chkMLT.checked==true && document.frmMain.txtTURL.value=="") {
					doShowAlertPanel("Please enter the Twitter media links URL.", document.frmMain.txtTURL);
					return false;
				} else {
				if (document.frmMain.chkMLF.checked==true && document.frmMain.txtFURL.value=="") {
					doShowAlertPanel("Please enter the Facebook media links URL.", document.frmMain.txtFURL);
					return false;
				} else {
				if (document.frmMain.chkMLL.checked==true && document.frmMain.txtLURL.value=="") {
					doShowAlertPanel("Please enter the Linkedin media links URL.", document.frmMain.txtLURL);
					return false;
				} else {
					strMediaLinks = "";
					document.frmMain.txtMediaLinks.value = "";
					strMediaLinks = strMediaLinks + document.frmMain.txtY.value + "ELMS_SPL" + document.frmMain.txtYURL.value;
					strMediaLinks = strMediaLinks +  "ELMS_SPLMAIN"  + document.frmMain.txtT.value + "ELMS_SPL" + document.frmMain.txtTURL.value;
					strMediaLinks = strMediaLinks +  "ELMS_SPLMAIN"  + document.frmMain.txtF.value + "ELMS_SPL" + document.frmMain.txtFURL.value;
					strMediaLinks = strMediaLinks +  "ELMS_SPLMAIN"  + document.frmMain.txtL.value + "ELMS_SPL" + document.frmMain.txtLURL.value;
					document.frmMain.txtMediaLinks.value = strMediaLinks;
					return true;
				} } } } } } } }
			}
		</script>
	</head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0" onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_branding_details_update.php" onsubmit="javascript:return doFormValidation();">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" cellspacing="0" cellpadding="0" align="center">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="2">Branding Details</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="2">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="25%" align="right" valign="middle">
																														<font color="red">*</font> Company Name:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="middle">
																														<?php
																															$varCompanyName = "";
																															$tempQuery = "SELECT company_name FROM elms_branding_details";
																															$tResult = mysql_query($tempQuery) or die (mysql_error());
																															$tRow = mysql_fetch_row($tResult);
																															$varCompanyName = $tRow[0];
																														?>																															
																														<input type="text" id="txtCName" name="txtCName" value="<?php echo $varCompanyName; ?>" class="clsTextField" style="width:50%" />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="10">
																							<td colspan="2"</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="25%" align="right" valign="top">
																														Your Logo:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="middle">
																														<input id="txtLogo" name="txtLogo" type="file"  />
																														<br />
																														<font size=2">( Choose your .jpg or .png file )</font>
																														<br />

																														<br />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="10">
																							<td colspan="2"</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="25%" align="right" valign="top">
																														Custom Image:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="middle">
																														<input id="txtCI" name="txtCI" type="file"  />
																														<br />
																														<font size=2">( Choose your .jpg or .png file )</font>
																														<br />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>																						
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="25%" align="right" valign="middle">
																														<font color="red">*</font> Reply E-mail:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="middle">
																														<?php
																															$varReplyEmail = "";
																															$tempQuery = "SELECT company_reply_email FROM elms_branding_details";
																															$tResult = mysql_query($tempQuery) or die (mysql_error());
																															$tRow = mysql_fetch_row($tResult);
																															$varReplyEmail = $tRow[0];
																														?>
																														<input type="text" id="txtREmail" name="txtREmail" value="<?php echo $varReplyEmail; ?>" class="clsTextField" style="width:50%" />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left" valign="top">
																											<table width="100%" cellspacing="0" cellpadding="0" border="0">
																												<tr>
																													<td width="25%" align="right" valign="top">
																														Send Reminder to Learners:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="top">
																														<table width="98%" cellspacing="0" cellpadding="0">
																															<tr>
																																<td align="left" valign="middle">
																																	<?php
																																		$varReminder = "";
																																		$tempQuery = "SELECT company_send_reminder FROM elms_branding_details";
																																		$tResult = mysql_query($tempQuery) or die (mysql_error());
																																		$tRow = mysql_fetch_row($tResult);
																																		$varReminder = $tRow[0];
																																	?>
																																	<?php
																																		if ($varReminder=="Y") {
																																	?>
																																			<input checked type="checkbox" id="chkSRS" name="chkSRS" value="Y" class="clsTextField" />
																																	<?php
																																		} else {
																																	?>
																																			<input type="checkbox" id="chkSRS" name="chkSRS" value="Y" class="clsTextField" />
																																	<?php
																																		}
																																	?>
																																</td>
																															</tr>
																														</table>
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left" valign="top">
																											<table width="100%" cellspacing="0" cellpadding="0" border="0">
																												<tr>
																													<td width="25%" align="right" valign="top">
																														Send Auto Reports Via Email:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="top">
																														<table width="98%" cellspacing="0" cellpadding="0">
																															<tr>
																																<td align="left" valign="middle">
																																	<?php
																																		$varEmailReport = "";
																																		$tempQuery = "SELECT company_send_reports FROM elms_branding_details";
																																		$tResult = mysql_query($tempQuery) or die (mysql_error());
																																		$tRow = mysql_fetch_row($tResult);
																																		$varEmailReport = $tRow[0];
																																	?>
																																	<?php
																																		if ($varEmailReport=="Y") {
																																	?>
																																			<input checked type="checkbox" id="chkAR" name="chkAR" value="Y" class="clsTextField" />
																																	<?php
																																		} else {
																																	?>
																																			<input type="checkbox" id="chkAR" name="chkAR" value="Y" class="clsTextField" />
																																	<?php
																																		}
																																	?>																																		
																																</td>
																															</tr>
																														</table>
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>																						
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="25%" align="right" valign="top">
																														Account Creation E-mail Message:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="middle">
																														<?php
																															$varAdditionalEmailMsg = "";
																															$tempQuery = "SELECT company_additional_email_message FROM elms_branding_details";
																															$tResult = mysql_query($tempQuery) or die (mysql_error());
																															$tRow = mysql_fetch_row($tResult);
																															$varAdditionalEmailMsg = $tRow[0];
																														?>
																														<div style="padding: 5px 5px 5px 5px; border: 1px #d4d4d4 solid;">
																															<b>Please enter the additional message along with system generated message if you need.</b><br /><br />
																															<textarea id="txtAddMsg" name="txtAddMsg" class="clsTextField" style="width: 430px; height: 100px; resize: none;"><?php echo $varAdditionalEmailMsg; ?></textarea>
																														</div>
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>																						
																						<tr height="10">
																							<td colspan="2"</td>
																						</tr>
																						<?php
																							$varY = "";
																							$varT = "";
																							$varF = "";
																							$varL = "";

																							$varYVal = "";
																							$varTVal = "";
																							$varFVal = "";
																							$varLVal = "";

																							$varYURL = "";
																							$varTURL = "";
																							$varFURL = "";
																							$varLURL = "";

																							$varMediaLinks = "";
																							$tempQuery = "SELECT company_social_medialinks FROM elms_branding_details";
																							$tResult = mysql_query($tempQuery) or die (mysql_error());
																							$tRow = mysql_fetch_row($tResult);
																							$varMediaLinks = $tRow[0];
																							if ($varMediaLinks!="") {
																								$arrTempSplMain = explode("ELMS_SPLMAIN", $varMediaLinks);
																								for ($i=0; $i<count($arrTempSplMain); $i++) {
																									$arrTempSplSub = explode("ELMS_SPL", $arrTempSplMain[$i]);
																									if ($arrTempSplSub[0]=="Y") {
																										$varY = "checked";
																										$varYVal = "Y";
																									}

																									if ($arrTempSplSub[0]=="T") {
																										$varT = "checked";
																										$varTVal = "T";
																									}

																									if ($arrTempSplSub[0]=="F") {
																										$varF = "checked";
																										$varFVal = "F";
																									}

																									if ($arrTempSplSub[0]=="L") {
																										$varL = "checked";
																										$varLVal = "L";
																									}
																									switch ($i) {
																										case 0:
																											$varYURL = $arrTempSplSub[1];
																											break;
																										case 1:
																											$varTURL = $arrTempSplSub[1];
																											break;
																										case 2:
																											$varFURL = $arrTempSplSub[1];
																											break;
																										case 3:
																											$varLURL = $arrTempSplSub[1];
																											break;
																									}
																								}
																							}
																						?>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left" valign="top">
																											<table width="100%" cellspacing="0" cellpadding="0" border="0">
																												<tr>
																													<td width="25%" align="right" valign="top">
																														Social Media Links:
																													</td>
																													<td width="1%"></td>
																													<td width="74%" align="left" valign="top">
																														<table width="98%" cellspacing="0" cellpadding="0">
																															<tr>
																																<td align="left" valign="middle">
																																	<input type="checkbox" id="chkMLY" name="chkMLY" value="Y" <?php echo $varY; ?> onclick="javascript:doPutSocialMediaLinks(this, document.frmMain.txtY, 'Y')" /> Youtube
																																</td>
																																<td align="left" valign="middle">
																																	Link URL:
																																</td>
																																<td align="left" valign="middle">
																																	<input type="text" id="txtYURL" name="txtYURL" class="clsTextField" style="height:15px; width:100%;" value="<?php echo $varYURL; ?>" />
																																</td>
																																<td width="50%">
																																</td>
																															</tr>
																															<tr>
																																<td align="left" valign="middle">
																																	<input type="checkbox" id="chkMLT" name="chkMLT" value="T" <?php echo $varT; ?> onclick="javascript:doPutSocialMediaLinks(this, document.frmMain.txtT, 'T')" /> Twitter
																																</td>
																																<td align="left" valign="middle">
																																	Link URL:
																																</td>
																																<td align="left" valign="middle">
																																	<input type="text" id="txtTURL" name="txtTURL" class="clsTextField" style="height:15px; width:100%;" value="<?php echo $varTURL; ?>" />
																																</td>
																																<td width="50%">
																																</td>
																															</tr>
																															<tr>
																																<td align="left" valign="middle">
																																	<input type="checkbox" id="chkMLF" name="chkMLF" value="F" <?php echo $varF; ?> onclick="javascript:doPutSocialMediaLinks(this, document.frmMain.txtF, 'F')" /> Facebook
																																</td>
																																<td align="left" valign="middle">
																																	Link URL:
																																</td>
																																<td align="left" valign="middle">
																																	<input type="text" id="txtFURL" name="txtFURL" class="clsTextField" style="height:15px; width:100%;" value="<?php echo $varFURL; ?>" />
																																</td>
																																<td width="50%">
																																</td>
																															</tr>
																															<tr>
																																<td align="left" valign="middle">
																																	<input type="checkbox" id="chkMLL" name="chkMLL" value="L" <?php echo $varL; ?> onclick="javascript:doPutSocialMediaLinks(this, document.frmMain.txtL, 'L')" /> Linkedin
																																</td>
																																<td align="left" valign="middle">
																																	Link URL:
																																</td>
																																<td align="left" valign="middle">
																																	<input type="text" id="txtLURL" name="txtLURL" class="clsTextField" style="height:15px; width:100%;" value="<?php echo $varLURL; ?>" />
																																</td>
																																<td width="50%">
																																</td>
																															</tr>
																														</table>
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="10">
																							<td colspan="2"</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top" colspan="2">
																								<table width="100%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="center">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="100%" align="right" valign="middle">
																														<input type="submit" id="btnFinish" name="btnFinish" value="&nbsp;Update&nbsp;" class="clsActionButton" />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>

																						<tr height="2">
																							<td colspan="2"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<?php
																			if ($_SESSION["Elms_LoggedInUserType"]=="Admin") {
																		?>
																				<input id="txtY" name="txtY" type="hidden" value="<?php echo $varYVal; ?>" />
																				<input id="txtT" name="txtT" type="hidden" value="<?php echo $varTVal; ?>" />
																				<input id="txtF" name="txtF" type="hidden" value="<?php echo $varFVal; ?>" />
																				<input id="txtL" name="txtL" type="hidden" value="<?php echo $varLVal; ?>" />
																				<input id="txtMediaLinks" name="txtMediaLinks" type="hidden" value="" />
																		<?php
																			}
																		?>
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="100">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>