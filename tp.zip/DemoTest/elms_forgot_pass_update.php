<?php
	require("elms_config.php");
	require("elms_db.php");
	require("class.phpmailer.php");
?>

<?php
	$strMessage = "";
	if (!isset($_POST["txtForgotPassEmail"])) {
		header("Location:index.php");
	} else {
		$flgFound = "No";
		$tempEmail = $_POST["txtForgotPassEmail"];
		$tempLoginPass = "";
		$varTempStatus = "A";

		$tempQuery = "SELECT * FROM elms_user_details";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		while ($tempRow = mysql_fetch_array($tempResult)) {
			if (strtolower($tempRow["user_email"])==strtolower($tempEmail)) {
				$flgFound = "Yes";
				$varTitle = $tempRow["user_title"];
				$varFName = $tempRow["user_fname"];
				$varLName = $tempRow["user_lname"];
				$tempLoginId = $tempRow["user_login"];
				$tempLoginPass = $tempRow["user_pass"];
				$varTempStatus = $tempRow["user_status"];
				break;
			}
		}
		
		if ($flgFound=="No") {
			$strMessage = "Invalid E-mail Id. Please try again!";
		} else {
			if ($varTempStatus=="I") {
				$strMessage = "Your account has been deactivated. Please contact <b>Chiron Meditour Training</b>.";
			} else {
				$varImageBasePath = "http://www.chironmeditourtraining.com/";
				$varLogoHTML = '<img src="' . $varImageBasePath . 'images/logo.png" />';
				$varTodayDate = date('d-m-Y');				
			
				$varLoginDetailsHTML = "";
				$varLoginDetailsHTML .= '<table width="350" cellspacing="0" cellpadding="0" border="0">';
					$varLoginDetailsHTML .= '<tr>';
						$varLoginDetailsHTML .= '<td width="100%" align="left">';
							$varLoginDetailsHTML .= '<div id="divPrintArea" name="divPrintArea" style="border:1px solid #cccccc;">';
								$varLoginDetailsHTML .= '<table width="100%" cellspacing="1" cellpadding="2" bgcolor="#e4e4e4">';
									$varLoginDetailsHTML .= '<tr style="background:#04548f; height:35px; font-family:arial; color:#ffffff; font-size:12px; font-weight:normal; text-align:center; vertical-align:middle;">';
										$varLoginDetailsHTML .= '<td width="60%" align="left">';
											$varLoginDetailsHTML .= 'Login Id';
										$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '<td width="40%" align="left">';
											$varLoginDetailsHTML .= 'Password';
										$varLoginDetailsHTML .= '</td>';
									$varLoginDetailsHTML .= '</tr>';
									$varLoginDetailsHTML .= '<tr style="background:#eaffea; height:25px; font-family:arial; color:#000000; font-size:11px; font-weight:normal; text-align:left; vertical-align:middle;">';
										$varLoginDetailsHTML .= '<td width="60%" align="left" valign="middle">';
											$varLoginDetailsHTML .= $tempLoginId;
										$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '<td width="40%" align="left" valign="middle">';
											$varLoginDetailsHTML .= $tempLoginPass;
										$varLoginDetailsHTML .= '</td>';
									$varLoginDetailsHTML .= '</tr>';
								$varLoginDetailsHTML .= '</table>';
							$varLoginDetailsHTML .= '</div>';
						$varLoginDetailsHTML .= '</td>';
					$varLoginDetailsHTML .= '</tr>';
				$varLoginDetailsHTML .= '</table>';

				$varSubject = "Chiron Meditour Training: Forgot Password Login Details";
				$varMessage = <<<EOF
<html>
	<head></head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<table width="100%" cellspacing="0" cellpadding="0" bordercolor="#004080" border="5">
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%" align="left" valign="center">
									$varLogoHTML
								</td>
							</tr>
							<tr height="5" bgcolor="#ffcc00">
								<td></td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
							<tr>
								<td width="100%" align="center" valign="top">
									<table width="98%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="100%" align="right" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Date: $varTodayDate</b>
												</font>
											</td>
										</tr>
										<tr height="5">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Dear $varTitle $varFName,</b>
												</font>
												<br /><br />
												<font face="arial" size="2" color="#000000">
													Below is your <b>Chiron Meditour Training</b> Login details.
													<br /><br />
													$varLoginDetailsHTML
													<br /><br />
													Should you encounter any problems, have questions or comments, please email us at: admin@chironmeditourtraining.com													
													<br /><br />
													Happy Learning!!
													<br /><br />
													Regards,
													<br /><br />
													Chiron Meditour Training
													<br />
													<a href="http://www.chironmeditourtraining.com" target="_blank">www.chironmeditourtraining.com</a>
												</font>												
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>
EOF;
				$varEmailTo = $tempEmail;
				$varEmailFrom = "";
				$varEmailFromName = "";
				$tQuery = "SELECT company_name, company_reply_email FROM elms_branding_details";
				$tResult = mysql_query($tQuery) or die (mysql_error());
				if ($tRow = mysql_fetch_array($tResult)) {
					$varEmailFrom = $tRow["company_reply_email"];
					$varEmailFromName = $tRow["company_name"];
				}
				$varEmailFromName = "Chiron Meditour Training";
				$mail = new PHPMailer();
				$mail->From = $varEmailFrom;
				$mail->FromName = $varEmailFromName;
				$mail->AddAddress($varEmailTo, $varUserFname);
				$mail->AddReplyTo($varEmailFrom, $varEmailFromName);
				$mail->IsHTML(true);
				$mail->Subject = $varSubject;
				$mail->Body = $varMessage;
				$mail->AltBody = "Here is your Login details.";

				if($varEmailFrom!="" && $mail->Send()) {
					$strMessage = "ELMS_SUCCESS";
				} else {
					$strMessage = "Unfortunately the system could not send an email to recipient.";
				}				
			}
		}
		echo $strMessage;
	}
?>