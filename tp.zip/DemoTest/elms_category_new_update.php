<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varName = "";
	$varCreated = "";
	if (!isset($_POST["txtName"])) {
		header("Location:index.php");
	} else {
		$varName = $_POST["txtName"];
		$varName = trim($varName);
		$varName = str_replace("'", "\\'", $varName);
		$varCreated = date('Y-m-d');

		$tempQuery = "SELECT * FROM elms_category_details WHERE category_name='" . trim($varName) . "'";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
			$tempQuery = "INSERT INTO elms_category_details(category_name,category_created) VALUES('" . trim($varName) . "','" . $varCreated .  "')";
			$tempResult = mysql_query($tempQuery);

			if ($tempResult) {
				$strMessage = "ELMS_SUCCESS";
			} else {
				$strMessage = "Unfortunately the system could not update the Course Category details. Please try again!";
			}
		} else {
			$strMessage = "The entered Course Category name already exists. Please enter another Course Category.";
		}
		echo $strMessage;
	}
?>