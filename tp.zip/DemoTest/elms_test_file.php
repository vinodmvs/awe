<?php
	require("elms_config.php");
	require("elms_db.php");
?>

<?php
/*
	//for ($i=1; $i<=217; $i++) {
		$tQuery = "SELECT DISTINCT user_id FROM elms_assigned_courses";
		$tResult = mysql_query($tQuery) or die (mysql_error());
		while ($tRow = mysql_fetch_array($tResult)) {
			$tempQuery = "SELECT * FROM elms_user_details WHERE user_id=" . $tRow["user_id"];
			$tempResult = mysql_query($tempQuery) or die (mysql_error());
			if (dbNumRows($tempResult)<=0) {
				print $tRow["user_id"] . "<br />";	
			}
		}
	//}
*/
	$varTempMsg = "";
	$varTempUserId = 1;
	$varUserCreated = "2015-01-05";
	$tempQuery = "SELECT * FROM elms_course_details";
	$tempResult = mysql_query($tempQuery) or die (mysql_error());
	while ($tempRow = mysql_fetch_array($tempResult)) {
		$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varTempUserId . " AND course_id=" . $tempRow["course_id"];
		$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
			
		$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varTempUserId . "," . $tempRow["course_id"] . ",'" . str_replace("'", "\\'", $tempRow["course_name"]) . "','" . $varUserCreated . "')";
		$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
		
		if ($varTempMsg=="") {
			$varTempMsg = "Course <b>" . str_replace("'", "\\'", $tempRow["course_name"]) . "</b> Inserted.";
		} else {
			$varTempMsg = $varTempMsg . "<br />Course <b>" . str_replace("'", "\\'", $tempRow["course_name"]) . "</b> Inserted.";
		}
	}
	echo $varTempMsg;
	
	
	/*$tempQuery = "SELECT * FROM elms_user_details WHERE user_role<>'Admin'";
	$tempResult = mysql_query($tempQuery) or die (mysql_error());
	$varTempInc = 0;
	$varMemId = 1;
	$varTempMsg = "";
	while ($tempRow = mysql_fetch_array($tempResult)) {
		$varTempInc++;
		if ($varTempInc>20 && $varTempInc<=40) {
			$varMemId = 2;
		}
		if ($varTempInc>40 && $varTempInc<=60) {
			$varMemId = 3;
		}
		if ($varTempInc>60 && $varTempInc<=80) {
			$varMemId = 4;
		}	
		if ($varTempInc>80 && $varTempInc<=100) {
			$varMemId = 5;
		}	
		if ($varTempInc>100 && $varTempInc<=120) {
			$varMemId = 6;
		}	
		if ($varTempInc>120 && $varTempInc<=140) {
			$varMemId = 7;
		}	
		if ($varTempInc>140 && $varTempInc<=160) {
			$varMemId = 8;
		}		
		if ($varTempInc>180 && $varTempInc<=200) {
			$varMemId = 9;
		}
		if ($varTempInc>200 && $varTempInc<=220) {
			$varMemId = 10;
		}		
		
		$tUpdateQuery = "UPDATE elms_user_details SET user_mem_type=" . $varMemId . " WHERE user_id=" . $tempRow["user_id"];
		$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
		
		if ($varTempMsg=="") {
			$varTempMsg = "User <b>" . str_replace("'", "\\'", $tempRow["user_fname"]) . "</b> Updated.";
		} else {
			$varTempMsg = $varTempMsg . "<br />User <b>" . str_replace("'", "\\'", $tempRow["user_fname"]) . "</b> Updated.";
		}
		
		
	}
	
	echo $varTempMsg;*/


	/*$tempQuery = "DELETE FROM elms_assigned_courses WHERE user_id=45 OR user_id=46 OR user_id=47 OR user_id=48";
	$tempResult = mysql_query($tempQuery) or die (mysql_error());
	echo "elms_assigned_courses table has been corrected<br /><br />";
	
	$tempQuery = "DELETE FROM elms_assigned_courses_group_wise WHERE group_id=6 OR group_id=7";
	$tempResult = mysql_query($tempQuery) or die (mysql_error());
	echo "elms_assigned_courses_group_wise table has been corrected<br /><br />";

	$tempQuery = "UPDATE elms_assigned_courses_group_wise SET assigned_date='2014-12-12' WHERE assigned_date=''";
	$tempResult = mysql_query($tempQuery) or die (mysql_error());
	echo "elms_assigned_courses_group_wise table has been updated";*/	
?>