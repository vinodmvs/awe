<?php
	require("elms_top_includes.php");
?>

<?php
	$varTotalCount = 0;
	$varRowSize = 10;
	$varStartLimit = 0;
	$varShowPreNav = "No";
	$varDisablePreNav = "Yes";
	$varShowNextNav = "No";
	$varDisableNextNav = "Yes";
	$varDisplayRowSizeText = "";
	$varCurPage = 1;
	$varPaginationStyle = "PRENEXTDDL"; //"PAGELINK" OR "PRENEXT" OR "PRENEXTDDL"
	
	
	$varAdditionalFilter = "All";
	$varTempCourseIds = null;
	$varTempUserIds = null;	
	if (isset($_POST["ddAdditionalFilter"])) {
		$varAdditionalFilter = $_POST["ddAdditionalFilter"];
	}
	if (isset($_POST["lstCoursesAvail"])) {
		$varTempCourseIds = $_POST["lstCoursesAvail"];
	}
	if (isset($_POST["chkUserIds"])) {
		$varTempUserIds = $_POST["chkUserIds"];
	}

	/*Course Assign or Remove Proccess*/
		$varCourseIds = null;
		$varUserIds = null;
		$varCourseAction = "";
		if (isset($_POST["txtCourseAction"]) && $_POST["txtCourseAction"]!="") {
			$varCourseAction = $_POST["txtCourseAction"];
			$varCourseIds = $_POST["lstCoursesAvail"];
			$varUserIds = $_POST["chkUserIds"];
			switch ($varCourseAction) {
				case "ASSIGN":
					for ($i=0; $i<count($varUserIds); $i++) {
						for ($j=0; $j<count($varCourseIds); $j++) {
							$varTempCourseData = explode("SPLMAIN", $varCourseIds[$j]);
							$tChkQuery = "SELECT user_id FROM elms_assigned_courses WHERE user_id=" . $varUserIds[$i] . " AND course_id=" . $varTempCourseData[0];
							$tChkResult = mysql_query($tChkQuery) or die (mysql_error());
							if (dbNumRows($tChkResult)<=0) {
								$tACQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varUserIds[$i] . "," . $varTempCourseData[0] . ",'" . str_replace("'", "\\'", $varTempCourseData[1]) . "','" . date('Y-m-d') . "','A')";
								$tACResult = mysql_query($tACQuery) or die (mysql_error());								
							} else {
								$tACQuery = "UPDATE elms_assigned_courses SET active_status='A' WHERE user_id=" . $varUserIds[$i] . " AND course_id=" . $varTempCourseData[0];
								$tACResult = mysql_query($tACQuery) or die (mysql_error());
							}
						}
					}
					break;
				case "REMOVE":
					for ($i=0; $i<count($varUserIds); $i++) {
						for ($j=0; $j<count($varCourseIds); $j++) {
							$varTempCourseData = explode("SPLMAIN", $varCourseIds[$j]);
							$tACQuery = "UPDATE elms_assigned_courses SET active_status='I' WHERE user_id=" . $varUserIds[$i] . " AND course_id=" . $varTempCourseData[0];
							$tACResult = mysql_query($tACQuery) or die (mysql_error());
						}
					}
					break;					
			}
		}
	/*Course Assign or Remove Proccess*/
	
	$varUserType = "All";
	$varMemberType = "All";
	$varGroupId = "All";
	$varFilterSQL = "";
	$varJOINSQL = "";
	$varSearchKeyWord = "";
	
	$varRegFDate = "";
	$varRegEDate = "";	
	$varRegFDateT = "";
	$varRegEDateT = "";
	
	if (isset($_POST["txtRegFDate"]) && $_POST["txtRegFDate"]!="") {
		$varRegFDateT = $_POST["txtRegFDate"];
		$varRegFDate = date_format(date_create($varRegFDateT), 'Y-m-d');
	}
	if (isset($_POST["txtRegEDate"]) && $_POST["txtRegEDate"]!="") {
		$varRegEDateT = $_POST["txtRegEDate"];
		$varRegEDate = date_format(date_create($varRegEDateT), 'Y-m-d');
	}
	
	$strMessage = "";
	$intTempNum = 0;	
	
	if (isset($_POST["ddRowSize"])) {
		$varRowSize = $_POST["ddRowSize"];
	}
	if (isset($_POST["ddUserIEType"])) {
		$varUserType = $_POST["ddUserIEType"];
	}
	if (isset($_POST["ddUserMemType"])) {
		$varMemberType = $_POST["ddUserMemType"];
	}	
	if (isset($_POST["ddGroup"])) {
		$varGroupId = $_POST["ddGroup"];
	}
	if (isset($_POST["txtCurPage"])) {
		$varCurPage = $_POST["txtCurPage"];
	}	

	if (isset($_POST["txtSearchWord"])) {
		$varSearchKeyWord = trim($_POST["txtSearchWord"]);
		$varSearchKeyWord = str_replace("'", "\\'", $varSearchKeyWord);
	}
	
	if ($varUserType!="All") {
		if ($varFilterSQL=="") {
			$varFilterSQL = " WHERE ELMSUserDetailsList.user_type='" . $varUserType . "'";
		} else {
			$varFilterSQL = $varFilterSQL . " AND ELMSUserDetailsList.user_type='" . $varUserType . "'";
		}
	}
	
	if ($varMemberType!="All") {
		$varMemberTypeTempSpl = explode("~", $varMemberType);
		if (count($varMemberTypeTempSpl)==1) {
			if ($varFilterSQL=="") {
				$varFilterSQL = " WHERE ELMSUserDetailsList.user_mem_type=" . $varMemberTypeTempSpl[0];
			} else {
				$varFilterSQL = $varFilterSQL . " AND ELMSUserDetailsList.user_mem_type=" . $varMemberTypeTempSpl[0];
			}
		} else {
			if ($varFilterSQL=="") {
				$varFilterSQL = " WHERE ELMSUserDetailsList.user_mem_type=" . $varMemberTypeTempSpl[0] . " OR ELMSUserDetailsList.user_mem_type=" . $varMemberTypeTempSpl[1];
			} else {
				$varFilterSQL = $varFilterSQL . " AND ELMSUserDetailsList.user_mem_type=" . $varMemberTypeTempSpl[0] . " OR ELMSUserDetailsList.user_mem_type=" . $varMemberTypeTempSpl[1];
			}		
		}
	}
	
	if ($varGroupId=="All") {
		$varJOINSQL = " FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id";
	} else {
		$varJOINSQL = ", ELMSAG.group_id as group_id FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_assigned_groups ELMSAG ON ELMSUserDetailsList.user_id=ELMSAG.user_id INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id";
		if ($varFilterSQL=="") {
			$varFilterSQL = " WHERE ELMSAG.group_id=" . $varGroupId;
		} else {
			$varFilterSQL = $varFilterSQL . " AND ELMSAG.group_id=" . $varGroupId;
		}
	}
	
	if ($varSearchKeyWord=="") {
		$tempQuery = "SELECT DISTINCT ELMSUserDetailsList.user_title, ELMSUserDetailsList.user_mem_type, ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_head AS user_head, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_type AS user_type, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_profile_pic AS user_profile_pic, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_toREPLACEFILTERSQL(ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") ORDER BY ELMSUserDetailsList.user_id";
	} else {
		$tempQuery = "SELECT DISTINCT ELMSUserDetailsList.user_title, ELMSUserDetailsList.user_mem_type, ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_head AS user_head, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_type AS user_type, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_profile_pic AS user_profile_pic, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_toREPLACEFILTERSQL(ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND () ORDER BY ELMSUserDetailsList.user_id";
		$varTempSQL = "";
		$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
		for ($i=0; $i<count($varTempKwyWordArray); $i++) {
			if ($i==0) {
				$varTempSQL = "ELMSUserDetailsList.user_fname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_lname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_email LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			} else {
				$varTempSQL = $varTempSQL . " OR ELMSUserDetailsList.user_fname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_lname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_email LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			}
		}
		$varTempSQL = "AND (" . $varTempSQL . ")";
		$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
	}
	if ($varFilterSQL=="") {
		if ($varRegFDate!="" && $varRegEDate!="") {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " WHERE (DATE(ELMSUserDetailsList.user_created) BETWEEN DATE('" . $varRegFDate . "') AND DATE('" . $varRegEDate . "')) AND ", $tempQuery);
		} else {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " WHERE ", $tempQuery);
		}
	} else {
		if ($varRegFDate!="" && $varRegEDate!="") {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " " . $varFilterSQL . " AND (DATE(ELMSUserDetailsList.user_created) BETWEEN DATE('" . $varRegFDate . "') AND DATE('" . $varRegEDate . "')) AND ", $tempQuery);
		} else {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " " . $varFilterSQL . " AND ", $tempQuery);
		}
	}
	$tCountResult = mysql_query($tempQuery) or die (mysql_error());	
	$varTotalCount = dbNumRows($tCountResult);
	
	if ($varRowSize=="0") {
		$varRowSize = $varTotalCount;
	}	

	if (isset($_POST["txtAction"])) {
		if (isset($_POST["txtStartLimit"])) {
			$varStartLimit = $_POST["txtStartLimit"];
		}
		switch ($_POST["txtAction"]) {
			case "NEXT":
				$varStartLimit = $varStartLimit + $varRowSize;
				break;
			case "LAST":
				$varTempVal = $varTotalCount/$varRowSize;
				$varTempArr = explode(".", $varTempVal);
				$varTempFinalVal = ($varTempArr[0]*$varRowSize);
				if (count($varTempArr)==2) {
					$varStartLimit = $varTempFinalVal;
				} else {
					$varStartLimit = $varTempFinalVal - $varRowSize;
				}
				break;				
			case "PREVIOUS":
				$varStartLimit = $varStartLimit - $varRowSize;
				break;
			case "FIRST":
				$varStartLimit = 0;
				break;			
				
		}
	}

	if ($varSearchKeyWord=="") {
		$tempQuery = "SELECT DISTINCT ELMSUserDetailsList.user_title, ELMSUserDetailsList.user_mem_type, ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_head AS user_head, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_type AS user_type, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_profile_pic AS user_profile_pic, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_toREPLACEFILTERSQL(ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") ORDER BY ELMSUserDetailsList.user_id LIMIT " . $varStartLimit . ", " . $varRowSize;
	} else {
		$tempQuery = "SELECT DISTINCT ELMSUserDetailsList.user_title, ELMSUserDetailsList.user_mem_type, ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_head AS user_head, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_type AS user_type, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_profile_pic AS user_profile_pic, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_toREPLACEFILTERSQL(ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND () ORDER BY ELMSUserDetailsList.user_id LIMIT " . $varStartLimit . ", " . $varRowSize;
		$varTempSQL = "";
		$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
		for ($i=0; $i<count($varTempKwyWordArray); $i++) {
			if ($i==0) {
				$varTempSQL = "ELMSUserDetailsList.user_fname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_lname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_email LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			} else {
				$varTempSQL = $varTempSQL . " OR ELMSUserDetailsList.user_fname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_lname LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSUserDetailsList.user_email LIKE '%" . $varTempKwyWordArray[$i] . "%'";
			}
		}
		$varTempSQL = "AND (" . $varTempSQL . ")";
		$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
	}
	if ($varFilterSQL=="") {
		if ($varRegFDate!="" && $varRegEDate!="") {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " WHERE (DATE(ELMSUserDetailsList.user_created) BETWEEN DATE('" . $varRegFDate . "') AND DATE('" . $varRegEDate . "')) AND ", $tempQuery);
		} else {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " WHERE ", $tempQuery);
		}
	} else {
		if ($varRegFDate!="" && $varRegEDate!="") {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " " . $varFilterSQL . " AND (DATE(ELMSUserDetailsList.user_created) BETWEEN DATE('" . $varRegFDate . "') AND DATE('" . $varRegEDate . "')) AND ", $tempQuery);
		} else {
			$tempQuery = str_replace("REPLACEFILTERSQL", $varJOINSQL . " " . $varFilterSQL . " AND ", $tempQuery);
		}
	}
	$userResult = mysql_query($tempQuery) or die (mysql_error());
	if (dbNumRows($userResult)<=0) {
		$strMessage =  "No user(s) available.";
	} else {
		$intTempNum = dbNumRows($userResult);
		
		if ($varStartLimit<=0) {
			$varShowPreNav = "No";
			$varDisablePreNav = "Yes";	
		} else {
			$varShowPreNav = "Yes";
			$varDisablePreNav = "No";	
		}		
		
		if ($intTempNum<$varRowSize || ($varStartLimit + $varRowSize)>=$varTotalCount) {
			$varShowNextNav = "No";
			$varDisableNextNav = "Yes";		
		} else {
			$varShowNextNav = "Yes";
			$varDisableNextNav = "No";		
		}
		$strMessage = "<b> " . $intTempNum . "</b> user(s) available.";
		
		$varDisplayRowSizeText = "Displaying " . ($varStartLimit + 1) . " - " . ($varStartLimit + $intTempNum) . " of " . $varTotalCount . " (Users)";
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			var tempCourseSelectedCount = 0;
			function doInitialize() {
				$("#txtRegFDate").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true,changeYear: true, yearRange: "-5:+0"});
				$("#txtRegEDate").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true,changeYear: true, yearRange: "-5:+0"});
				var arrTemp = document.getElementById("txtCourseIds").value.split(",");
				for (var i=0; i<document.getElementsByName("lstCoursesAvail[]").length; i++) {
					for (var j=0; j<arrTemp.length; j++) {
						if (Number(document.getElementsByName("lstCoursesAvail[]")[i].value.split("SPLMAIN")[0])==Number(arrTemp[j].split("SPLMAIN")[0])) {
							document.getElementsByName("lstCoursesAvail[]")[i].checked = true;
							var tempDivId = document.getElementsByName("lstCoursesAvail[]")[i].id.split("_")[1];
							var objTemp = document.getElementById("divCoursesAvail_" + tempDivId);
							objTemp.style.backgroundColor = "#d4d4d4";
						}
					}
				}
				doCheckAllAvailCoursesSelected();
				
				var arrTemp = document.getElementById("txtUserIds").value.split(",");
				for (var i=0; i<document.getElementsByName("chkUserIds[]").length; i++) {
					for (var j=0; j<arrTemp.length; j++) {
						if (Number(document.getElementsByName("chkUserIds[]")[i].value)==Number(arrTemp[j])) {
							document.getElementsByName("chkUserIds[]")[i].checked = true;
						}
					}
				}
				doCheckAllSelected();
			}
			
			function doAssignORRemoveCourses(strTemp) {
				var boolCourseSelected = false;
				var boolUserSelected = false;			
				for (var i=0; i<document.getElementsByName("lstCoursesAvail[]").length; i++) {
					if (document.getElementsByName("lstCoursesAvail[]")[i].checked==true) {
						boolCourseSelected = true;
						break;
					}
				}
				
				for (var i=0; i<document.getElementsByName("chkUserIds[]").length; i++) {
					if (document.getElementsByName("chkUserIds[]")[i].checked==true) {
						boolUserSelected = true;
						break;
					}
				}
				
				if (!boolCourseSelected && !boolUserSelected) {
					doShowAlertPanel('Please select the Course and User to Assign.', '');
				} else {
				if (!boolCourseSelected) {
					doShowAlertPanel('Please select the Course to Assign.', '');
				} else {
				if (!boolUserSelected) {
					doShowAlertPanel('Please select the User to Assign.', '');
				} else {
					document.frmMain.txtCourseAction.value = strTemp;
					doShowProccessIcon();
					document.frmMain.txtStartLimit.value='0';
					document.frmMain.txtAction.value='';
					document.frmMain.submit();
				} } }
			}
			
			function doCheckORUncheckAll() {
				if (document.getElementById("chkAll").checked==true) {
					for (var i=0; i<document.getElementsByName("chkUserIds[]").length; i++) {
						document.getElementsByName("chkUserIds[]")[i].checked = true;
					}
				} else {
					for (var i=0; i<document.getElementsByName("chkUserIds[]").length; i++) {
						document.getElementsByName("chkUserIds[]")[i].checked = false;
					}
				}
			}
			
			function doCheckAllSelected() {
				var boolAllSelected = true;
				for (var i=0; i<document.getElementsByName("chkUserIds[]").length; i++) {
					if (document.getElementsByName("chkUserIds[]")[i].checked==false) {
						boolAllSelected = false;
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkAll").checked = true;
				} else {
					document.getElementById("chkAll").checked = false;
				}
			}

			function doCheckORUncheckAllAvailCourses(objThis) {
				var objTemp = null;
				var tempCount = document.getElementsByName('lstCoursesAvail[]').length;
				if (objThis.checked==true) {
					objThis.checked=false;
				} else {
					objThis.checked=true;
				}
				for (var i=0; i<tempCount; i++) {
					objTemp = document.getElementById(document.getElementsByName('lstCoursesAvail[]')[i].id.split("lst").join("div"));
					if (objThis.checked==true) {
						document.getElementsByName('lstCoursesAvail[]')[i].checked = true;
						objTemp.style.backgroundColor = "#d4d4d4";
					} else {
						document.getElementsByName('lstCoursesAvail[]')[i].checked = false;
						objTemp.style.backgroundColor = "#ffffff";
					}
				}
				doCheckAllAvailCoursesSelected();
			}
			
			function doCheckORUncheckCoursesAvail(varTemp) {
				var objTemp = document.getElementById("divCoursesAvail_" + varTemp);
				var objThis = document.getElementById("lstCoursesAvail_" + varTemp);
				if (objThis.checked==true) {
					objThis.checked=false;
					objTemp.style.backgroundColor = "#ffffff";
				} else {
					objThis.checked=true;
					objTemp.style.backgroundColor = "#d4d4d4";
				}
				doCheckAllAvailCoursesSelected();
			}
			
			function doCheckAllAvailCoursesSelected() {
				var boolAllSelected = true;
				if (document.getElementsByName("lstCoursesAvail[]").length<=0) {
					boolAllSelected = false;
				} else {
					for (var i=0; i<document.getElementsByName("lstCoursesAvail[]").length; i++) {
						if (document.getElementsByName("lstCoursesAvail[]")[i].checked==false) {
							boolAllSelected = false;
							break;
						}
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkCheckOrUncheckAllAvailCourses").checked = true;
				} else {
					document.getElementById("chkCheckOrUncheckAllAvailCourses").checked = false;
				}
				
				tempCourseSelectedCount = 0;
				for (var i=0; i<document.getElementsByName("lstCoursesAvail[]").length; i++) {
					if (document.getElementsByName("lstCoursesAvail[]")[i].checked) {
						tempCourseSelectedCount = tempCourseSelectedCount+1;
					}
				}
				$("#spnCourseAvailCount").html(document.getElementsByName("lstCoursesAvail[]").length);
				$("#spnCourseSelectedCount").html(tempCourseSelectedCount);
			}			
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<form id="frmMain" name="frmMain" method="post" action="elms_user_assign_course.php">
									<table width="100%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="1%">
												&nbsp;
											</td>
											<td>
												<table width="100%" cellspacing="0" cellpadding="0">
													<tr>
														<td width="1%">
															&nbsp;
														</td>
														<td align="left" valign="top">
															<table width="100%" cellspacing="0" cellpadding="0">
																<tr>
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tr>
																				<td width="75%">
																					<div style="width:100%; display:inline-block;">
																						<div class="clsRoleSubLink" onclick="javascript:doCancel('elms_user_list.php');"><< Back</div>
																					</div>
																				</td>
																				<td width="25%" align="right">
																					<div style="width:100%; display:inline-block;">
																						Show Users:&nbsp;
																						<select id="ddRowSize" name="ddRowSize" class="clsTextField" style="width:65px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<?php if ($varRowSize==10) { ?>
																								<option selected value="10">10</option>
																							<?php } else { ?>
																								<option value="10">10</option>
																							<?php } ?>

																							<?php if ($varRowSize==25) { ?>
																								<option selected value="25">25</option>
																							<?php } else { ?>
																								<option value="25">25</option>
																							<?php } ?>

																							<?php if ($varRowSize==50) { ?>
																								<option selected value="50">50</option>
																							<?php } else { ?>
																								<option value="50">50</option>
																							<?php } ?>

																							<?php if ($varRowSize==100) { ?>
																								<option selected value="100">100</option>
																							<?php } else { ?>
																								<option value="100">100</option>
																							<?php } ?>

																							<?php if ($varRowSize==$varTotalCount) { ?>
																								<option selected value="0">All</option>
																							<?php } else { ?>
																								<option value="0">All</option>
																							<?php } ?>																							
																						</select>
																					</div>
																				</td>
																			</tr>
																			<tr height="25">
																				<td width="100%" align="center" colspan="2">
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="left" colspan="2">
																					<fieldset style="padding:5px 5px 5px 5px; border:1px solid #cccccc">
																						<legend style="position: relative; padding:5px 5px 5px 5px; font-size:12px; top: 0px; left: 0px; color:#000000; border:1px solid #000000;"><b>Filter By</b></legend>																				
																						User Type:&nbsp;
																						<select id="ddUserIEType" name="ddUserIEType" size="1" class="clsTextField" style="width:200px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<option selected value="All">All Users</option>
																							<?php if ($varUserType=="Internal") { ?>
																								<option selected value="Internal">Internal</option>
																							<?php } else { ?>
																								<option value="Internal">Internal</option>
																							<?php } ?>
																							
																							<?php if ($varUserType=="External") { ?>
																								<option selected value="External">External</option>
																							<?php } else { ?>
																								<option value="External">External</option>
																							<?php } ?>																							
																						</select>
																						&nbsp;&nbsp;
																						Membership:&nbsp;
																						<select id="ddUserMemType" name="ddUserMemType" size="1" class="clsTextField" style="width:250px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<option selected value="All">All Members</option>
																							<?php
																								if ($varUserType!="All") {
																									$tQuery = "SELECT * FROM elms_membership_details WHERE mem_type='" . $varUserType . "' ORDER BY mem_name";
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																									while ($tRow = mysql_fetch_array($tResult)) {
																							?>
																										<?php if ($varMemberType==$tRow["mem_id"]) { ?>
																											<option selected value="<?php echo $tRow["mem_id"]; ?>"><?php echo $tRow["mem_name"]; ?></option>
																										<?php } else { ?>
																											<option value="<?php echo $tRow["mem_id"]; ?>"><?php echo $tRow["mem_name"]; ?></option>
																										<?php } ?>
																							<?php
																									}	
																								} else {
																									$tQuery = "SELECT * FROM elms_membership_details ORDER BY mem_name";
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																									$varTempChkText = "";
																									$varTempMemListVal = "";
																									$varTempPrevId = 0;
																									while ($tRow = mysql_fetch_array($tResult)) {
																										if ($varTempChkText!=$tRow["mem_name"]) {
																											if ($varTempMemListVal=="") {
																												$varTempMemListVal = $tRow["mem_name"] . "~" . $tRow["mem_id"];
																											} else {
																												$varTempMemListVal = $varTempMemListVal . "SPLMAIN" . $tRow["mem_name"] . "~" . $tRow["mem_id"];
																											}
																										} else {
																											$varTempMemListVal = str_replace($tRow["mem_name"] . "~" . $varTempPrevId, $tRow["mem_name"] . "~" . $varTempPrevId . "~" . $tRow["mem_id"], $varTempMemListVal);
																										}
																										$varTempChkText = $tRow["mem_name"];
																										$varTempPrevId = $tRow["mem_id"];
																									}
																									if ($varTempMemListVal!="") {
																										$varTempMemListValArray = explode("SPLMAIN", $varTempMemListVal);
																							?>
																									<?php
																										for ($k=0; $k<count($varTempMemListValArray); $k++) {
																									?>
																											<?php
																												$varTempSubSpl = explode("~", $varTempMemListValArray[$k]);
																												$varMemName = "";
																												$varMemId = "";
																												if (count($varTempSubSpl)==2) {
																													$varMemName = $varTempSubSpl[0];
																													$varMemId = $varTempSubSpl[1];
																												} else {
																													$varMemName = $varTempSubSpl[0];
																													$varMemId = $varTempSubSpl[1] . "~" . $varTempSubSpl[2];
																												}
																											?>
																											<?php if ($varMemberType==$varMemId) { ?>
																												<option selected value="<?php echo $varMemId; ?>"><?php echo $varMemName; ?></option>
																											<?php } else { ?>
																												<option value="<?php echo $varMemId; ?>"><?php echo $varMemName; ?></option>
																											<?php } ?>
																									<?php
																										}
																									?>																							
																							<?php
																									}
																								}
																							?>																											
																						</select>
																						&nbsp;&nbsp;																					
																						Group:&nbsp;
																						<select id="ddGroup" name="ddGroup" size="1" class="clsTextField" style="width:450px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<option selected value="All">All Groups</option>
																							<?php
																								$tempTQuery = "SELECT * FROM elms_assigned_groups WHERE user_id=" . $_SESSION["Elms_LoggedInId"];
																								$groupResult = mysql_query($tempTQuery) or die (mysql_error());
																								while ($tempRow = mysql_fetch_array($groupResult)) {
																									if ($varUserType=="All") {
																										$tempDispQuery = "SELECT * FROM elms_group_details WHERE group_id=" . $tempRow["group_id"];
																									} else {
																										$tempDispQuery = "SELECT * FROM elms_group_details WHERE group_id=" . $tempRow["group_id"] . " AND group_type='" . $varUserType . "'";
																									}
																									$tempDispResult = mysql_query($tempDispQuery) or die (mysql_error());
																							?>
																									<?php 
																										if (dbNumRows($tempDispResult)>0) { 
																											$tempDispRow = mysql_fetch_array($tempDispResult);
																									?>
																									
																											<?php if ($varMemberType=="All") { ?>
																												<?php if ($tempDispRow["group_id"]==$varGroupId) { ?>
																													<option selected value="<?php echo $tempDispRow["group_id"]; ?>"><?php echo $tempDispRow["group_name"]; ?></option>
																												<?php } else { ?>
																													<option value="<?php echo $tempDispRow["group_id"]; ?>"><?php echo $tempDispRow["group_name"]; ?></option>
																												<?php } ?>
																											<?php } else { ?>
																												<?php
																													$varMemberTypeTempSpl = explode("~", $varMemberType);
																													if (count($varMemberTypeTempSpl)==1) {
																														$tQuery = "SELECT user_id FROM elms_user_details WHERE user_mem_type=" . $varMemberTypeTempSpl[0];
																													} else {
																														$tQuery = "SELECT user_id FROM elms_user_details WHERE user_mem_type=" . $varMemberTypeTempSpl[0] . " OR user_mem_type=" . $varMemberTypeTempSpl[1];
																													}
																													$tResult = mysql_query($tQuery) or die (mysql_error());
																													if (dbNumRows($tResult)>0) {
																														$varGroupText = "";
																														while ($tRow = mysql_fetch_array($tResult)) {
																															$tQuery = "SELECT user_id FROM elms_assigned_groups WHERE user_id=" . $tRow["user_id"] . " AND group_id=" . $tempDispRow["group_id"];
																															$tGCountResult = mysql_query($tQuery) or die (mysql_error());
																															if (dbNumRows($tGCountResult)>0) {
																																if ($varGroupText!=$tempDispRow["group_name"]) {
																																	$varGroupText = $tempDispRow["group_name"];
																												?>
																																	<?php if ($tempDispRow["group_id"]==$varGroupId) { ?>
																																		<option selected value="<?php echo $tempDispRow["group_id"]; ?>"><?php echo $tempDispRow["group_name"]; ?></option>
																																	<?php } else { ?>
																																		<option value="<?php echo $tempDispRow["group_id"]; ?>"><?php echo $tempDispRow["group_name"]; ?></option>
																																	<?php } ?>
																												<?php 
																													}	}	}	}
																												?>
																											<?php } ?>
																									<?php } ?>
																							<?php
																								}
																							?>
																						</select>
																					</fieldset>
																				</td>
																			</tr>
																			<tr height="25">
																				<td width="100%" colspan="2">
																				</td>
																			</tr>																			
																			<tr>
																				<td width="100%" align="center" colspan="2">
																					<table width="100%" align="center" cellspacing="2" cellpadding="2">
																						<tr>
																							<td width="50%" align="left">
																								<fieldset style="padding:5px 5px 5px 5px; border:1px solid #cccccc">
																									<legend style="position: relative; padding:5px 5px 5px 5px; font-size:12px; top: 0px; left: 0px; color:#000000; border:1px solid #000000;"><b>Search by Enroll Date</b></legend>
																									Start Date:&nbsp;<input type="text" id="txtRegFDate" name="txtRegFDate" class="clsTextField" readonly style="width:100px" value="<?php echo $varRegFDateT; ?>" />
																									<div style="display:inline-block;vertical-align:middle;" onclick="javascript:$('#txtRegFDate').datepicker('show');"><img width="25" height="25" src="images/calendar_icon.png" style="cursor:pointer" /></div>
																									&nbsp;&nbsp;
																									End Date:&nbsp;<input type="text" id="txtRegEDate" name="txtRegEDate" class="clsTextField" readonly style="width:100px" value="<?php echo $varRegEDateT; ?>" />
																									<div style="display:inline-block;vertical-align:middle;" onclick="javascript:$('#txtRegEDate').datepicker('show');"><img width="25" height="25" src="images/calendar_icon.png" style="cursor:pointer" /></div>
																									<div class="clsActionButton" onclick="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.submit();">&nbsp;Go&nbsp;</div>
																									<div class="clsActionButton" onclick="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtRegFDate.value=''; document.frmMain.txtRegEDate.value=''; document.frmMain.submit();">&nbsp;Reset&nbsp;</div>
																								</fieldset>
																							</td>																						
																							<td width="50%" align="right">
																								<fieldset style="padding:5px 5px 5px 5px; border:1px solid #cccccc; text-align:left;">
																									<legend style="position: relative; padding:5px 5px 5px 5px; font-size:12px; top: 0px; left: 0px; color:#000000; border:1px solid #000000;"><b>Search by Name or E-mail</b></legend>
																									<div style="text-align:right;">
																										<input type="text" id="txtSearchWord" name="txtSearchWord" class="clsTextField" style="width:400px;" value="<?php echo $varSearchKeyWord; ?>" />
																										<div class="clsActionButton" onclick="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.submit();">&nbsp;Go&nbsp;</div>
																									</div>
																								</fieldset>
																							</td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																			<?php if ($intTempNum>0) { ?>
																				<tr height="25">
																					<td width="100%" colspan="2">
																					</td>
																				</tr>
																				<tr>
																					<td width="100%" colspan="2" align="center">
																						<div style="width:100%; display:inline-block;">
																							<div class="clsRoleSubLink" onclick="javascript:doAssignORRemoveCourses('ASSIGN');">Assign Course(s)</div>
																							<div class="clsRoleSubLink" onclick="javascript:doAssignORRemoveCourses('REMOVE');">Remove Course(s)</div>
																						</div>																				
																					</td>
																				</tr>
																				<tr height="10">
																					<td width="100%" colspan="2">
																					</td>
																				</tr>
																				<tr>
																					<td width="100%" colspan="2">
																						<p align="center" style="font-size:20px; font-weight:bold; color:<?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;">Course List</p>
																						<b>Available Course(s):</b>
																						<div style="height:5px;"></div>
																						<div style="display:inline-block; width:95px; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckAllAvailCourses(document.getElementById('chkCheckOrUncheckAllAvailCourses'));">
																							<input type="checkbox" id="chkCheckOrUncheckAllAvailCourses" name="chkCheckOrUncheckAllAvailCourses" onclick="javascript:doCheckORUncheckAllAvailCourses(this);" style="cursor:pointer;" />&nbsp;<b>Select All</b>
																						</div>
																						&nbsp;&nbsp;
																						<div style="display:inline-block; text-align:left; vertical-align:middle;">
																							<b>Filter By:</b>&nbsp;
																							<select id="ddAdditionalFilter" name="ddAdditionalFilter" size="1" class="clsTextField" style="width:250px;"  onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.submit();">
																								<option selected value="All">All Courses</option>
																								<!--
																								<?php if ($varAdditionalFilter==1) { ?>
																									<option selected value="1">Internal Users</option>
																								<?php } else { ?>
																									<option value="1">Internal Users</option>
																								<?php } ?>
																								
																								<?php if ($varAdditionalFilter==2) { ?>
																									<option selected value="2">External Users</option>
																								<?php } else { ?>
																									<option value="2">External Users</option>
																								<?php } ?>

																								<?php if ($varAdditionalFilter==3) { ?>
																									<option selected value="3">Skill Institute[External]</option>
																								<?php } else { ?>
																									<option value="3">Skill Institute[External]</option>
																								<?php } ?>
																								
																								<?php if ($varAdditionalFilter==4) { ?>
																									<option selected value="4">Online Users[External]</option>
																								<?php } else { ?>
																									<option value="4">Online Users[External]</option>
																								<?php } ?>
																								-->
																							</select>
																							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Total Available Courses:</b> <span id="spnCourseAvailCount" name="spnCourseAvailCount">0</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Total Selected Courses:</b> <span id="spnCourseSelectedCount" name="spnCourseSelectedCount">0</span>
																						</div>
																						<div style="height:5px;"></div>
																						<div id="divCoursesAvailPanel" name="divCoursesAvailPanel" style="background-color:#f4f4f4; overflow-x:hidden; overflow-y:auto; border:5px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; width:100%; height:250px;">
																							<?php
																								$strTMessage = "";
																								if ($varAdditionalFilter=="All") {
																									$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSAC.course_id";
																								} else {
																									$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND (ELMSCD.course_additional_filter RLIKE '[[:<:]]" . $varAdditionalFilter . "[[:>:]]') AND ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSAC.course_id";
																								}
																								$tResult = mysql_query($tempTQuery) or die (mysql_error());
																								$varTempAvailCount = dbNumRows($tResult);
																								if (dbNumRows($tResult)<=0) {
																									$strTMessage =  "No courses available.";
																								}
																								/*
																								$strTMessage = "";
																								if ($varUserType=="All") {
																									$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSAC.course_id";
																								} else {
																								if ($varUserType=="Internal") {
																									$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='Both') AND ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSAC.course_id";
																								} else {
																									$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND ELMSCD.course_isfree='Y' AND ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSAC.course_id";
																								} }
																								$tResult = mysql_query($tempTQuery) or die (mysql_error());
																								$varTempAvailCount = dbNumRows($tResult);
																								if (dbNumRows($tResult)<=0) {
																									$strTMessage =  "No courses available.";
																								}
																								*/
																							?>
																							<?php if ($strTMessage=="") { ?>
																								<?php while ($row = mysql_fetch_array($tResult)) { ?>
																									<div id="divCoursesAvail_<?php echo $row["course_id"]; ?>" name="divCoursesAvail_<?php echo $row["course_id"]; ?>" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckCoursesAvail(<?php echo $row["course_id"]; ?>);">
																										<table width="100%" cellspacing="0" cellpadding="0" border="0">
																											<tr>
																												<td width="2%" align="right" valign="top"><input type="checkbox" id="lstCoursesAvail_<?php echo $row["course_id"]; ?>" name="lstCoursesAvail[]" value="<?php echo $row["course_id"]; ?>SPLMAIN<?php echo $row["course_name"]; ?>" coursename="<?php echo $row["course_name"]; ?>" onclick="javascript:doCheckORUncheckCoursesAvail(<?php echo $row["course_id"]; ?>);" style="cursor:pointer;" /></td>
																												<td align="left" valign="top">
																													&nbsp;<b><font size="3" color="green"><?php echo $row["course_id"]; ?></font></b>&nbsp;<?php echo $row["course_name"]; ?>
																												</td>
																											</tr>
																										</table>
																									</div>
																									<div style="height:3px;"></div>
																								<?php } ?>
																							<?php } else { ?>
																								<?php echo $strTMessage; ?>
																							<?php } ?>
																						</div>
																					</td>
																				</tr>
																			<?php } ?>
																			<tr height="10">
																				<td colspan="2">
																				</td>
																			</tr>
																			<tr>
																				<td colspan="2">
																					<p align="center" style="font-size:20px; font-weight:bold; color:<?php echo $_SESSION["Elms_GeneralBgColor"]; ?>;">User List</p>
																				</td>
																			</tr>																			
																			<?php
																				if ($intTempNum>0) { 
																					if ($varPaginationStyle=="PAGELINK") {
																						doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "TOP");
																					} else {
																					if ($varPaginationStyle=="PRENEXT") {
																						doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} else {
																						doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} }
																				}
																			?>
																		</table>
																	</td>
																	<input type="hidden" id="txtStartLimit" name="txtStartLimit" value="<?php echo $varStartLimit; ?>" />
																	<input type="hidden" id="txtAction" name="txtAction" value="" />
																	<input type="hidden" id="txtCurPage" name="txtCurPage" value="1" />
																	<input type="hidden" id="txtCourseAction" name="txtCourseAction" value="" />
																	<?php if ($varTempCourseIds==null) { ?>
																		<input type="hidden" id="txtCourseIds" name="txtCourseIds" value="" />
																	<?php } else { ?>
																		<input type="hidden" id="txtCourseIds" name="txtCourseIds" value="<?php echo implode(",", $varTempCourseIds); ?>" />
																	<?php } ?>
																	<?php if ($varTempUserIds==null) { ?>
																		<input type="hidden" id="txtUserIds" name="txtUserIds" value="" />
																	<?php } else { ?>
																		<input type="hidden" id="txtUserIds" name="txtUserIds" value="<?php echo implode(",", $varTempUserIds); ?>" />
																	<?php } ?>
																</tr>
																<tr height="10">
																	<td>
																	</td>
																</tr>
																<?php if ($intTempNum<=0) { ?>
																	<tr height="25">
																		<td width="100%" align="center" class="clsResErrorMsgText">
																			<?php echo $strMessage; ?>
																		</td>
																	</tr>
																<?php } else { ?>
																	<tr>
																		<td width="100%" align="left" valign="top">
																			<div class="clsSingleBorder">
																				<table width="100%" cellspacing="1" cellpadding="2">
																					<tr class="clsTableRowHeadingText">
																						<td width="2%" align="center">
																							<input type="checkbox" id="chkAll" name="chkAll" style="width:20px; height:20px; cursor:pointer;" onclick="javascript:doCheckORUncheckAll();" />
																						</td>
																						<td width="20%">
																							First Name
																						</td>
																						<td width="18%">
																							Membership
																						</td>																					
																						<td width="22%">
																							E-mail
																						</td>
																						<td width="29%">
																							Group
																						</td>
																						<td width="4%">
																							Course
																						</td>
																						<td width="5%">
																							Status
																						</td>
																					</tr>
																					<?php
																						$intTempInc = 0;
																						$intTempInc = $varStartLimit;
																						$strColorFilled = "No";
																						while ($row = mysql_fetch_array($userResult)) {
																							$intTempInc++;
																					?>
																					<?php
																						if ($strColorFilled=="No") {
																							$strColorFilled = "Yes";

																					?>
																						<tr class="clsAlternateFColor">
																					<?php
																						} else {
																							$strColorFilled = "No";

																					?>
																						<tr class="clsAlternateSColor" style="height:30px; font-size:14px; font-weight:normal; text-align:left; vertical-align:top;">
																					<?php
																						}
																					?>
																							<td width="2%" align="center">
																								<!--<img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/users_icon_small.png" alt="" title="" />-->
																								<input type="checkbox" id="chkUserIds_<?php echo $row["user_id"]; ?>" name="chkUserIds[]" value="<?php echo $row["user_id"]; ?>" style="width:15px; height:15px; cursor:pointer;" onclick="javascript:doCheckAllSelected();" />
																							</td>
																							<td width="20%">
																								<?php echo $row["user_title"] . " " . $row["user_fname"]; ?>
																							</td>
																							<td width="18%">
																								<?php
																									$varTempDisplay = "";
																									$tQuery = "SELECT * FROM elms_membership_details WHERE mem_id=" . $row["user_mem_type"];
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																									$tRow = mysql_fetch_array($tResult);
																									$varTempDisplay = $tRow["mem_name"];
																									if ($row['user_type']=="Internal") {
																										echo $varTempDisplay . " <b><font color='#000000'>[" . $row['user_type'] . "]</font></b>";
																									} else {
																										echo $varTempDisplay . " <b><font color='#000000'>[" . $row['user_type'] . "]</font></b>";
																									}
																								?>
																							</td>																						
																							<td width="22%">
																								<?php echo $row["user_email"]; ?>
																							</td>
																							<td width="29%">
																								<?php
																									$tQuery = "SELECT * FROM elms_assigned_groups WHERE user_id=" . $row['user_id'];
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																									$tempResult = mysql_query($tQuery) or die (mysql_error());
																									if (dbNumRows($tempResult)<=0) {
																										echo "-";
																									} else {
																										$strDisp = "";
																										while ($tRow = mysql_fetch_array($tResult)) {
																											if ($strDisp=="") {
																												$strDisp = $tRow["group_name"];
																											} else {
																												$strDisp = $strDisp. "<b>,</b> " . $tRow["group_name"];
																											}
																										}
																										echo $strDisp;
																									}
																								?>
																							</td>
																							<td width="3%">
																								<?php
																									$tQuery = "SELECT * FROM elms_assigned_courses WHERE active_status='A' AND user_id=" . $row['user_id'];
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																									$tempResult = mysql_query($tQuery) or die (mysql_error());
																									if (dbNumRows($tempResult)<=0) {
																										echo dbNumRows($tempResult);
																									} else {
																										echo dbNumRows($tempResult);
																									}
																								?>
																							</td>
																							<td width="6%">
																								<?php
																									if ($row["user_status"]=="A") {
																										echo "Active";
																									} else {
																										echo "Inactive";
																									}
																								?>
																							</td>
																						</tr>
																					<?php } ?>
																				</table>
																			</div>
																		</td>
																	</tr>
																	<?php
																		if ($varPaginationStyle=="PAGELINK") {
																			doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "BOTTOM");
																		} else {
																		if ($varPaginationStyle=="PRENEXT") {
																			doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																		} else {
																			doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																		} }
																	?>
																	<tr height="10">
																		<td width="100%">
																		</td>
																	</tr>
																	<tr>
																		<td width="100%" align="center">
																			<div style="width:100%; display:inline-block;">
																				<div class="clsRoleSubLink" onclick="javascript:doAssignORRemoveCourses('ASSIGN');">Assign Course(s)</div>
																				<div class="clsRoleSubLink" onclick="javascript:doAssignORRemoveCourses('REMOVE');">Remove Course(s)</div>
																			</div>																				
																		</td>
																	</tr>
																<?php } ?>
																<tr height="25">
																	<td width="100%">
																	</td>
																</tr>
																<tr>
																	<td width="100%" align="left">
																		<div style="width:100%; display:inline-block;">
																			<div class="clsRoleSubLink" onclick="javascript:doCancel('elms_user_list.php');"><< Back</div>
																		</div>																				
																	</td>
																</tr>																
															</table>
														</td>
														<td width="1%">
															&nbsp;
														</td>
													</tr>
												</table>
											</td>
											<td width="1%">
												&nbsp;
											</td>
										</tr>
									</table>
								</form>
							</td>
						</tr>
						<tr height="25">
							<td>
							</td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>