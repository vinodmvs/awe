<?php
	require("elms_top_includes.php");
?>

<?php
	$varID = "";
	$strMessage = "";
	$varName = "";
	$varDesc = "";
	$varStatus = "";

	if (!isset($_POST["txtGroupId"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["txtGroupId"];
		$varName = $_POST["txtName"];
		$varName = trim($varName);
		$varName = str_replace("'", "\\'", $varName);
		$varDesc = $_POST["txtDesc"];
		$varDesc = str_replace("'", "\\'", $varDesc);
		$varType = $_POST["txtGroupType"];
		$varStatus = $_POST["txtStatus"];

		$tempQuery = "SELECT * FROM elms_group_details WHERE group_id<>" . $varID . " AND group_name='" . $varName . "' AND group_type='" . $varType . "'";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
			$tempQuery = "UPDATE elms_group_details SET group_name='" . $varName . "',group_desc='" . $varDesc . "',group_status='" . $varStatus . "' WHERE group_id=" . $varID;
			$tempResult = mysql_query($tempQuery);

			$tempQuery = "UPDATE elms_assigned_groups SET group_name='" . $varName . "' WHERE group_id=" . $varID;
			$tempResult = mysql_query($tempQuery);

			if ($tempResult) {
				$strMessage = "ELMS_SUCCESS";
			} else {
				$strMessage = "Unfortunately the system could not update the Group details. Please try again!";
			}
		} else {
			$strMessage = "The entered Group name already exists. Please enter another Group.";
		}
		echo $strMessage;
	}
?>