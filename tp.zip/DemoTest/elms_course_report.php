<?php
	require("elms_top_includes.php");
?>

<?php
	$varTotalCount = 0;
	$varRowSize = 10;
	$varStartLimit = 0;
	$varShowPreNav = "No";
	$varDisablePreNav = "Yes";
	$varShowNextNav = "No";
	$varDisableNextNav = "Yes";
	$varDisplayRowSizeText = "";
	$varCurPage = 1;
	$varPaginationStyle = "PRENEXTDDL"; //"PAGELINK" OR "PRENEXT" OR "PRENEXTDDL"

	$strMessage = "";
	$varCatID = "All";
	$varMemberType = "All";
	$varSearchKeyWord = "";
	$intTempNum = 0;
	
	$_SESSION["Elms_SCORMCourseStatus"] = "";
	$_SESSION["Elms_SCORMRawScore"] = 0;
	
	if (isset($_POST["ddRowSize"])) {
		$varRowSize = $_POST["ddRowSize"];
	}	
	
	if (isset($_POST["ddCat"])) {
		$varCatID = $_POST["ddCat"];
	}

	if (isset($_POST["ddUserMemType"])) {
		$varMemberType = $_POST["ddUserMemType"];
	}	
	
	if (isset($_POST["txtCurPage"])) {
		$varCurPage = $_POST["txtCurPage"];
	}	
	
	if (isset($_POST["txtSearchWord"])) {
		$varSearchKeyWord = trim($_POST["txtSearchWord"]);
		$varSearchKeyWord = str_replace("'", "\\'", $varSearchKeyWord);
	}	
	
	$tempQuery = "SELECT * FROM elms_category_details ORDER BY category_name";
	$categoryResult = mysql_query($tempQuery) or die (mysql_error());

	if ($varCatID=="All") {
		if ($varSearchKeyWord=="") {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSCD.course_name";
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') ORDER BY ELMSCD.course_name";
			}
		} else {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND () ORDER BY ELMSCD.course_name";
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') AND () ORDER BY ELMSCD.course_name";
			}
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSCATD.category_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSCATD.category_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);
		}
	} else {
		if ($varSearchKeyWord=="") {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " ORDER BY ELMSCD.course_name";
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') ORDER BY ELMSCD.course_name";
			}
		} else {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " AND () ORDER BY ELMSCD.course_name";
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') AND () ORDER BY ELMSCD.course_name";
			}
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
		}
	}
	$tCountResult = mysql_query($tempQuery) or die (mysql_error());	
	$varTotalCount = dbNumRows($tCountResult);	
	
	if ($varRowSize=="0") {
		$varRowSize = $varTotalCount;
	}

	if (isset($_POST["txtAction"])) {
		if (isset($_POST["txtStartLimit"])) {
			$varStartLimit = $_POST["txtStartLimit"];
		}
		switch ($_POST["txtAction"]) {
			case "NEXT":
				$varStartLimit = $varStartLimit + $varRowSize;
				break;
			case "LAST":
				$varTempVal = $varTotalCount/$varRowSize;
				$varTempArr = explode(".", $varTempVal);
				$varTempFinalVal = ($varTempArr[0]*$varRowSize);
				if (count($varTempArr)==2) {
					$varStartLimit = $varTempFinalVal;
				} else {
					$varStartLimit = $varTempFinalVal - $varRowSize;
				}
				break;				
			case "PREVIOUS":
				$varStartLimit = $varStartLimit - $varRowSize;
				break;
			case "FIRST":
				$varStartLimit = 0;
				break;			
				
		}
	}	
	
	if ($varCatID=="All") {
		if ($varSearchKeyWord=="") {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			}
		} else {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND () ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') AND () ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			}
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSCATD.category_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSCATD.category_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);
		}
	} else {
		if ($varSearchKeyWord=="") {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			}
		} else {
			if ($varMemberType=="All") {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " AND () ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			} else {
				$tempQuery = "SELECT DISTINCT ELMSAC.course_id, ELMSCD.course_cat, ELMSCD.course_type, ELMSCD.course_name, ELMSCD.course_desc, ELMSCD.course_image, ELMSCD.course_created, ELMSCD.course_iscert, ELMSCATD.category_id, ELMSCATD.category_name FROM elms_assigned_courses ELMSAC INNER JOIN elms_course_details ELMSCD ON ELMSAC.course_id=ELMSCD.course_id INNER JOIN elms_category_details ELMSCATD ON ELMSCATD.category_id=ELMSCD.course_cat WHERE ELMSAC.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSCATD.category_id=" . $varCatID . " AND (course_mem_type RLIKE '[[:<:]]" . $varMemberType . "[[:>:]]' OR course_mem_type='') AND () ORDER BY ELMSCD.course_name LIMIT " . $varStartLimit . ", " . $varRowSize;
			}
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSCD.course_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSCD.course_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
		}
	}
	$courseResult = mysql_query($tempQuery) or die (mysql_error());
	if (dbNumRows($courseResult)<=0) {
		$strMessage =  "No course(s) available.";
	} else {
		$intTempNum = dbNumRows($courseResult);
		
		if ($varStartLimit<=0) {
			$varShowPreNav = "No";
			$varDisablePreNav = "Yes";	
		} else {
			$varShowPreNav = "Yes";
			$varDisablePreNav = "No";	
		}		
		
		if ($intTempNum<$varRowSize || ($varStartLimit + $varRowSize)>=$varTotalCount) {
			$varShowNextNav = "No";
			$varDisableNextNav = "Yes";		
		} else {
			$varShowNextNav = "Yes";
			$varDisableNextNav = "No";		
		}		
		$strMessage = "<b> " . $intTempNum . "</b> course(s) available.";
		$varDisplayRowSizeText = "Displaying " . ($varStartLimit + 1) . " - " . ($varStartLimit + $intTempNum) . " of " . $varTotalCount . " (Courses)";
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doConvertPDF() {
				document.frmPDF.txtData.value = document.getElementById('divPrintData').innerHTML;
				document.frmPDF.action = "elms_course_report_print.php";
				document.frmPDF.submit();
			}
		</script>		
	</head>
	<body>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<form id="frmMain" name="frmMain" method="post" action="elms_course_report.php">
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tr>
																				<td width="60%">
																					<div style="display:inline-block;">
																						<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_statistic_report.php';">Statistic Reports</div>
																						<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_user_report.php';">User Reports</div>
																						<div class="clsRoleSubLinkSelected" onclick="javascript:document.location.href='elms_course_report.php';">Course Reports</div>
																					</div>
																				</td>
																				<td width="40%" align="right">
																					<div style="width:100%; display:inline-block;">
																						Show Courses:&nbsp;
																						<select id="ddRowSize" name="ddRowSize" class="clsTextField" style="width:15%;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<?php if ($varRowSize==5) { ?>
																								<option selected value="5">5</option>
																							<?php } else { ?>
																								<option value="5">5</option>
																							<?php } ?>
																							
																							<?php if ($varRowSize==10) { ?>
																								<option selected value="10">10</option>
																							<?php } else { ?>
																								<option value="10">10</option>
																							<?php } ?>

																							<?php if ($varRowSize==25) { ?>
																								<option selected value="25">25</option>
																							<?php } else { ?>
																								<option value="25">25</option>
																							<?php } ?>

																							<?php if ($varRowSize==50) { ?>
																								<option selected value="50">50</option>
																							<?php } else { ?>
																								<option value="50">50</option>
																							<?php } ?>

																							<?php if ($varRowSize==100) { ?>
																								<option selected value="100">100</option>
																							<?php } else { ?>
																								<option value="100">100</option>
																							<?php } ?>

																							<?php if ($varRowSize==$varTotalCount) { ?>
																								<option selected value="0">All</option>
																							<?php } else { ?>
																								<option value="0">All</option>
																							<?php } ?>																							
																						</select>
																					</div>
																				</td>
																			</tr>
																			<tr height="25">
																				<td width="100%" align="center" colspan="2">
																				</td>
																			</tr>
																			<tr>
																				<td width="100%" align="left" colspan="2">
																					<fieldset style="padding:5px 5px 5px 5px; border:1px solid #cccccc">
																						<legend style="position: relative; padding:5px 5px 5px 5px; font-size:12px; top: 0px; left: 0px; color:#000000; border:1px solid #000000;"><b>Filter By</b></legend>																				
																						<?php if($_SESSION["Elms_LoggedInUserType"]=="Admin") { ?>
																							Membership:&nbsp;
																							<select id="ddUserMemType" name="ddUserMemType" size="1" class="clsTextField" style="width:200px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																								<option selected value="All">All Members</option>
																								<?php
																									$tQuery = "SELECT * FROM elms_membership_details ORDER BY mem_name";
																									$tResult = mysql_query($tQuery) or die (mysql_error());
																									$varTempChkText = "";
																									$varTempMemListVal = "";
																									$varTempPrevId = 0;
																									while ($tRow = mysql_fetch_array($tResult)) {
																										if ($varTempChkText!=$tRow["mem_name"]) {
																											if ($varTempMemListVal=="") {
																												$varTempMemListVal = $tRow["mem_name"] . "~" . $tRow["mem_id"];
																											} else {
																												$varTempMemListVal = $varTempMemListVal . "SPLMAIN" . $tRow["mem_name"] . "~" . $tRow["mem_id"];
																											}
																										} else {
																											$varTempMemListVal = str_replace($tRow["mem_name"] . "~" . $varTempPrevId, $tRow["mem_name"] . "~" . $varTempPrevId . "~" . $tRow["mem_id"], $varTempMemListVal);
																										}
																										$varTempChkText = $tRow["mem_name"];
																										$varTempPrevId = $tRow["mem_id"];
																									}
																									if ($varTempMemListVal!="") {
																										$varTempMemListValArray = explode("SPLMAIN", $varTempMemListVal);
																								?>
																								<?php
																									for ($k=0; $k<count($varTempMemListValArray); $k++) {
																								?>
																										<?php
																											$varTempSubSpl = explode("~", $varTempMemListValArray[$k]);
																											$varMemName = "";
																											$varMemId = "";
																											if (count($varTempSubSpl)==2) {
																												$varMemName = $varTempSubSpl[0];
																												$varMemId = $varTempSubSpl[1];
																											} else {
																												$varMemName = $varTempSubSpl[0];
																												$varMemId = $varTempSubSpl[1] . "~" . $varTempSubSpl[2];
																											}
																										?>
																										<?php if ($varMemberType==$varMemId) { ?>
																											<option selected value="<?php echo $varMemId; ?>"><?php echo $varMemName; ?></option>
																										<?php } else { ?>
																											<option value="<?php echo $varMemId; ?>"><?php echo $varMemName; ?></option>
																										<?php } ?>
																								<?php
																										}
																									}
																								?>																							
																							</select>
																							&nbsp;&nbsp;
																						<?php } ?>
																						Category:&nbsp;
																						<select id="ddCat" name="ddCat" size="1" class="clsTextField" style="width:300px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<option selected value="All">All Category</option>
																							<?php
																								while ($row = mysql_fetch_array($categoryResult)) {
																							?>
																								<?php if ($row["category_id"]==$varCatID) { ?>
																									<option selected value="<?php echo $row["category_id"]; ?>"><?php echo $row["category_name"]; ?></option>
																								<?php } else { ?>
																									<option value="<?php echo $row["category_id"]; ?>"><?php echo $row["category_name"]; ?></option>
																								<?php } ?>
																							<?php
																								}
																							?>
																						</select>
																					</fieldset>
																				</td>
																			</tr>
																			<tr height="25">
																				<td width="100%" colspan="2">
																				</td>
																			</tr>																			
																			<tr>
																				<td width="100%" align="right" colspan="2">
																					Search by Course Name or Description:&nbsp;<input type="text" id="txtSearchWord" name="txtSearchWord" class="clsTextField" style="width:400px;" value="<?php echo $varSearchKeyWord; ?>" />
																					<div class="clsActionButton" onclick="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.submit();">&nbsp;Go&nbsp;</div>																				
																				</td>
																			</tr>																			
																			<?php
																				if ($intTempNum>0) { 
																					if ($varPaginationStyle=="PAGELINK") {
																						doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "TOP");
																					} else {
																					if ($varPaginationStyle=="PRENEXT") {
																						doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} else {
																						doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} }
																			?>
																					<tr height="10">
																						<td width="100%" colspan="2">
																						</td>
																					</tr>
																					<tr>
																						<td width="100%" align="right" colspan="2">
																							<input type="button" value="Print / Download" class="clsActionButton" onclick="javascript:doConvertPDF();" />
																						</td>
																					</tr>
																			<?php
																				}
																			?>
																		</table>
																	</td>
																	<input type="hidden" id="txtStartLimit" name="txtStartLimit" value="<?php echo $varStartLimit; ?>" />
																	<input type="hidden" id="txtAction" name="txtAction" value="" />
																	<input type="hidden" id="txtCurPage" name="txtCurPage" value="1" />
																</form>
															</tr>
															<tr height="10">
																<td>
																</td>
															</tr>
															<?php if ($intTempNum<=0) { ?>
																<tr height="25">
																	<td width="100%" align="center" class="clsResErrorMsgText">
																		<?php echo $strMessage; ?>
																	</td>
																</tr>
															<?php } else { ?>
																<tr>
																	<td width="100%" align="left" valign="top">
																		<div id="divPrintData" name="divPrintData" class="clsSingleBorder">
																			<table width="100%" cellspacing="1" cellpadding="2">
																				<tr class="clsTableRowHeadingText">
																				<td width="2%">
																				#
																				</td>
																				<td width="50%">
																					Course Name
																				</td>
																				<td width="30%">
																					Course Category
																				</td>
																				<td width="11%">
																					Course Type
																				</td>
																				<td width="7%">
																					Action
																				</td>
																			</tr>
																				<?php
																					$intTempInc = 0;
																					$strColorFilled = "No";
																					while ($row = mysql_fetch_array($courseResult)) {
																						$intTempInc++;
																				?>
																				<?php
																					if ($strColorFilled=="No") {
																						$strColorFilled = "Yes";

																				?>
																					<tr class="clsAlternateFColor">
																				<?php
																					} else {
																						$strColorFilled = "No";

																				?>
																					<tr class="clsAlternateSColor">
																				<?php
																					}
																				?>
																						<td width="2%">
																							<?php //echo $intTempInc; ?>
																							<img border="0" src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/courses_icon_small.png" alt="" title="" />
																						</td>
																						<td width="50%">
																							<?php echo $row["course_name"]; ?>
																						</td>
																						<td width="30%">
																							<?php
																								$tQuery = "SELECT category_name FROM elms_category_details WHERE category_id=" . $row["course_cat"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								$tRow = mysql_fetch_array($tResult);
																								echo $tRow["category_name"];
																							?>
																						</td>
																						<td width="11%">
																							<?php echo $row["course_type"]; ?>
																						</td>
																						<td width="7%" align="center" valign="middle">
																							<form id="frmDetail_<?php echo $row["course_id"]; ?>" name="frmDetail_<?php echo $row["course_id"]; ?>" method="post" action="elms_course_report_detail.php">
																								<a class="clsActionButton" href="javascript:document.frmDetail_<?php echo $row["course_id"]; ?>.submit();">Details</a>
																								<input type="hidden" id="txtCourseId" name="txtCourseId" value="<?php echo $row["course_id"]; ?>">
																							</form>
																						</td>
																					</tr>
																				<?php } ?>
																			</table>
																		</div>
																	</td>
																</tr>
																<tr height="10">
																	<td width="100%">
																	</td>
																</tr>
																<tr>
																	<td width="100%" align="right">
																		<input type="button" value="Print / Download" class="clsActionButton" onclick="javascript:doConvertPDF();" />
																		<form id="frmPDF" name="frmPDF" method="post" target="_blank">
																			<input type="hidden" id="txtData" name="txtData" value="" />
																		</form>																	
																	</td>
																</tr>																
																<?php
																	if ($varPaginationStyle=="PAGELINK") {
																		doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "BOTTOM");
																	} else {
																	if ($varPaginationStyle=="PRENEXT") {
																		doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																	} else {
																		doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																	} }
																?>
															<?php } ?>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>