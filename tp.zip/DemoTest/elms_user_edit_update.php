<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";

	$varUserTitle = "Mr.";
	$varUserId = "";
	$varUserRole = "";
	$varUserPass = "";
	$varUserFname = "";
	$varUserLname = "";
	$varUserDOB = "";
	$varUserPhone = "";
	$varUserStatus = "";
	$varTodayDate = date('Y-m-d');
	$varUserMUPer = "N";
	$varUserMGPer = "N";
	$varUserGroups = "";
	$varUserCourses = "";
	

	if (!isset($_POST["txtUserId"])) {
		header("Location:elms_login.php");
	} else {
		$varUserId = $_POST["txtUserId"];
		$varUserTitle = $_POST["ddUserTitle"];
		$varUserRole = $_POST["ddUserType"];
		$varUserPass = $_POST["txtPass"];
		$varUserFname = str_replace("'", "\\'", $_POST["txtFName"]);
		$varUserLname = str_replace("'", "\\'", $_POST["txtLName"]);
		$varUserDOB = $_POST["txtDOB"];
		$varUserPhone = $_POST["txtPhone"];
		$varUserStatus = $_POST["txtStatus"];
		if (isset($_POST["chkMGPer"]) && $_POST["chkMGPer"]!="") {
			$varUserMGPer = $_POST["chkMGPer"];
		}
		if (isset($_POST["chkMUPer"]) && $_POST["chkMUPer"]!="") {
			$varUserMUPer = $_POST["chkMUPer"];
		}
		
		if (isset($_POST["lstGroupsAssigned"])) {
			$varUserGroups = $_POST["lstGroupsAssigned"];
		}

		if (isset($_POST["lstCoursesAssigned"])) {
			$varUserCourses = $_POST["lstCoursesAssigned"];
		}		
		
		$tempQuery = "UPDATE elms_user_details SET user_title='" . $varUserTitle . "',user_fname='" . $varUserFname . "',user_lname='" . $varUserLname . "',user_dob='" . $varUserDOB . "',user_phone='" . $varUserPhone . "',user_mg_per='" . $varUserMGPer . "',user_mu_per='" . $varUserMUPer . "',user_status='" . $varUserStatus . "',user_pass='" . $varUserPass . "' WHERE user_id=" . $varUserId;
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		if (!$tempResult) {
			$strMessage = "Unfortunately the system could not update User the details. Please try again.";
		} else {
			/* Assigning Groups and Courses */
			/* Resetting Group Assigned Status to "N" */		
			if ($varUserRole=="Manager") {
				$tCheckQuery = "SELECT DISTINCT * FROM elms_group_details ELMSGD INNER JOIN elms_assigned_groups ELMSAG ON ELMSGD.group_id = ELMSAG.group_id WHERE ELMSAG.user_id=" . $varUserId;
				$tCheckResult = mysql_query($tCheckQuery) or die (mysql_error());
				while ($tCheckRow = mysql_fetch_array($tCheckResult)) {
					$tempQuery = "UPDATE elms_group_details SET group_assigned='N' WHERE group_id=" . $tCheckRow["group_id"];
					$tempResult = mysql_query($tempQuery);

					$strTQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $tCheckRow["group_id"] . " AND user_id<>" . $varUserId . " AND user_id<>" . $_SESSION["Elms_LoggedInId"];
					$strTResult = mysql_query($strTQuery) or die (mysql_error());
					while ($strTRow = mysql_fetch_array($strTResult)) {
						$strTQuery = "UPDATE elms_user_details SET user_head=" . $_SESSION["Elms_LoggedInId"] . " WHERE user_id=" . $strTRow["user_id"];
						$strTUpdateResult = mysql_query($strTQuery) or die (mysql_error());
					}
				}
			}
			
			/* Assigning Groups with Courses */
			$tempQuery = "DELETE FROM elms_assigned_groups WHERE user_id=" . $varUserId;
			$tempResult = mysql_query($tempQuery);
			if ($varUserGroups!=null && $varUserGroups!="") {
				$arrTemp = $varUserGroups;
				for ($i=0; $i<count($arrTemp); $i++) {
					$tQuery = "SELECT * FROM elms_group_details WHERE group_id=" . $arrTemp[$i];
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$tempQuery = "INSERT INTO elms_assigned_groups(user_id,group_id,group_name,assigned_date) VALUES(" . $varUserId . "," . $tRow["group_id"] . ",'" . $tRow["group_name"] . "','" . $varTodayDate . "')";
					$tempResult = mysql_query($tempQuery);
					if ($varUserRole=="Manager") {
						$tempQuery = "UPDATE elms_group_details SET group_assigned='Y' WHERE group_id=" . $tRow["group_id"];
						$tempResult = mysql_query($tempQuery);

						$strTQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $arrTemp[$i] . " AND user_id<>" . $varUserId . " AND user_id<>" . $_SESSION["Elms_LoggedInId"];
						$strTResult = mysql_query($strTQuery) or die (mysql_error());
						while ($strTRow = mysql_fetch_array($strTResult)) {
							$strTQuery = "UPDATE elms_user_details SET user_head=" . $varUserId . " WHERE user_id=" . $strTRow["user_id"];
							$strTUpdateResult = mysql_query($strTQuery) or die (mysql_error());
						}
					}
					
					/*
					$tAssignCourse = "SELECT course_id, course_name FROM elms_assigned_courses_group_wise WHERE group_id=" . $tRow["group_id"];
					$tAssignResult = mysql_query($tAssignCourse) or die (mysql_error());
					$tChkResult = mysql_query($tAssignCourse) or die (mysql_error());
					$tempCheck = mysql_fetch_row($tChkResult);
					if ($tempCheck!=null && $tempCheck!="") {
						while ($tAssignRow = mysql_fetch_array($tAssignResult)) {
							//$tCheckQuery = "SELECT ELMSUD.user_mem_type, ELMSCD.course_id, ELMSCD.course_mem_type FROM elms_user_details ELMSUD INNER JOIN elms_course_details ELMSCD ON ELMSCD.course_mem_type RLIKE CONCAT(  '[[:<:]]', ELMSUD.user_mem_type,  '[[:>:]]' ) WHERE ELMSCD.course_id=" . $tAssignRow["course_id"] . " AND ELMSUD.user_id=" . $varUserId;
							//$tCheckResult = mysql_query($tCheckQuery) or die (mysql_error());
							
							$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varUserId . " AND course_id=" . $tAssignRow["course_id"];
							$tDelResult = mysql_query($tDelQuery) or die (mysql_error());							
							//if (dbNumRows($tCheckResult)>0) {
								$tUpdateQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varUserId . "," . $tAssignRow["course_id"] . ",'" . $tAssignRow["course_name"] . "','" . $varTodayDate . "','A')";
								$tUpdateResult = mysql_query($tUpdateQuery) or die (mysql_error());
							//}
						}
					}*/
				}
			}
			
			/* Assigning Groups with Courses */
			/*$tempQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varUserId;
			$tempResult = mysql_query($tempQuery);
			if ($varUserCourses!=null && $varUserCourses!="") {
				$arrTemp = $varUserCourses;
				for ($i=0; $i<count($arrTemp); $i++) {
					$tQuery = "SELECT * FROM elms_course_details WHERE course_id=" . $arrTemp[$i];
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);

					$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $varUserId . " AND course_id=" . $tRow["course_id"];
					$tDelResult = mysql_query($tDelQuery) or die (mysql_error());

					$tempQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $varUserId . "," . $tRow["course_id"] . ",'" . $tRow["course_name"] . "','" . $varTodayDate . "')";
					$tempResult = mysql_query($tempQuery);
				}
			}*/
			
			$tempQuery = "UPDATE elms_assigned_courses SET active_status='I' WHERE user_id=" . $varUserId;
			$tempResult = mysql_query($tempQuery);
			if ($varUserCourses!=null && $varUserCourses!="") {
				$arrTemp = $varUserCourses;
				for ($i=0; $i<count($arrTemp); $i++) {
					$tChkQuery = "SELECT user_id FROM elms_assigned_courses WHERE user_id=" . $varUserId . " AND course_id=" . $arrTemp[$i];
					$tChkResult = mysql_query($tChkQuery) or die (mysql_error());
					if (dbNumRows($tChkResult)<=0) {
						$tQuery = "SELECT * FROM elms_course_details WHERE course_id=" . $arrTemp[$i];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
					
						$tACQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date,active_status) VALUES(" . $varUserId . "," . $tRow["course_id"] . ",'" . str_replace("'", "\\'", $tRow["course_name"]) . "','" . date('Y-m-d') . "','A')";
						$tACResult = mysql_query($tACQuery) or die (mysql_error());								
					} else {
						$tACQuery = "UPDATE elms_assigned_courses SET active_status='A' WHERE user_id=" . $varUserId . " AND course_id=" . $arrTemp[$i];
						$tACResult = mysql_query($tACQuery) or die (mysql_error());
					}
				}
			}
			/* Assigning Groups and Courses */
			$strMessage = "ELMS_SUCCESS";
		}
		echo $strMessage;
	}
?>