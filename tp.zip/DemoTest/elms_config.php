<?php
	ini_set('display_errors', 'On');
	error_reporting(E_ALL);
	ob_start();
	session_cache_limiter();
	if (!isset($_SESSION)) {
		session_start();
	}
	if (!isset($_SESSION["Elms_ThemeColor"]) || $_SESSION["Elms_ThemeColor"]=="") {
		$_SESSION["Elms_ThemeColor"] = "blue";
		$_SESSION["Elms_GeneralBgColor"] = "#49c0f0";
		$_SESSION["Elms_AlternateFColor"] = "#c0e7f9";
		$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";
	}	
	date_default_timezone_set('Asia/Kolkata');
?>