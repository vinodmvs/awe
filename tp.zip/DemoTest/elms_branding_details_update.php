<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varCompanyName = "";
	$varREmail = "";
	$varSRS = "N";
	$varAR = "N";
	$varAddMsg = "";
	$varMediaLinks = "";

	if (!isset($_POST["txtCName"])) {
		header("Location:index.php");
	} else {
		$varCompanyName = $_POST["txtCName"];
		$varREmail = $_POST["txtREmail"];
		if (isset($_POST["chkSRS"])) {
			$varSRS = "Y";
		}
		if (isset($_POST["chkAR"])) {
			$varAR = "Y";
		}
		$varAddMsg = $_POST["txtAddMsg"];
		$varMediaLinks = $_POST["txtMediaLinks"];

		if ($varMediaLinks=="") {
			$tempQuery = "UPDATE elms_branding_details SET company_name='" . $varCompanyName . "', company_reply_email='" . $varREmail . "', company_send_reminder='" . $varSRS . "', company_send_reports='" . $varAR . "', company_additional_email_message='" . $varAddMsg . "'";
		} else {
			$tempQuery = "UPDATE elms_branding_details SET company_name='" . $varCompanyName . "', company_reply_email='" . $varREmail . "', company_send_reminder='" . $varSRS . "', company_send_reports='" . $varAR . "', company_additional_email_message='" . $varAddMsg . "', company_social_medialinks='" . $varMediaLinks . "'";
		}
		$tempResult = mysql_query($tempQuery);

		if ($tempResult) {
			$strMessage = "ELMS_SUCCESS";

			if (isset($_FILES["txtLogo"]) && $_FILES["txtLogo"]["name"]) {
				$strSource = $_FILES["txtLogo"]["tmp_name"];
				$intSize =$_FILES['txtLogo']['size'];
				$strTargetPath = "images/";
				$strFilename = "logo.png";
				$strUploadPath = $strTargetPath . $strFilename;
				if ($intSize>2097152) {
					$strMessage = "<b>Error: </b>Logo image size must be less than 2 MB.";
				} else {
					if (move_uploaded_file($strSource, $strUploadPath)) {
						$strMessage = "ELMS_SUCCESS";
					} else {
						$strMessage = "<b>Error: </b>Error occured while uploading Logo.";
					}
				}
			}

			if (isset($_FILES["txtCI"]) && $_FILES["txtCI"]["name"]) {
				$strSource = $_FILES["txtCI"]["tmp_name"];
				$intSize =$_FILES['txtCI']['size'];
				$strTargetPath = "images/";
				$strFilename = "custom_icon.png";
				$strUploadPath = $strTargetPath . $strFilename;
				if ($intSize>2097152) {
					$strMessage = "<b>Error: </b>Custom image size must be less than 2 MB.";
				} else {
					if (move_uploaded_file($strSource, $strUploadPath)) {
						$strMessage = "ELMS_SUCCESS";
					} else {
						$strMessage = "<b>Error: </b>Error occured while uploading Custom image.";
					}
				}
			}
		} else {
			$strMessage = "<b>Error: </b>Error occured while updating the Branding details into the Database.";
		}
		echo $strMessage;
	}
?>