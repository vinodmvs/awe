<?php
	require("elms_top_includes.php");
?>

<?php
	if (isset($_POST["txtCourseID"]) && $_POST["txtCourseID"]) {
		$strLoginId = $_SESSION["Elms_LoggedInId"];
		$strLocation = str_replace("'", "\\'", $_POST["txtLocation"]);
		$strStatus = strtoupper($_POST["txtStatus"]);
		$strCredit = strtoupper($_POST["txtCredit"]);
		$varRawScore = $_POST["txtScoreRaw"];
		$strEntry = "RESUME";
		if (isset($_SESSION["Elms_SCORMCourseStatus"]) && $_SESSION["Elms_SCORMCourseStatus"]=="COMPLETED") {
			$strStatus = $_SESSION["Elms_SCORMCourseStatus"];
			$varRawScore = $_SESSION["Elms_SCORMRawScore"];
		}
		if ($strStatus == "COMPLETED" || $strStatus == "PASSED") {
			if (strtoupper($_POST["txtCredit"]) == "CREDIT") {
				$strCredit = "CREDIT";
			}
		}
		$strSQL = "UPDATE `elms_course_scorm_track`
					SET
					`location` = '" . $strLocation . "',
					`status` = '" . $strStatus . "',
					`entry` = '" . $strEntry . "',
					`score_raw` = '" . $varRawScore . "',
					`score_min` = '" . $_POST["txtScoreMin"] . "',
					`score_max` = '" . $_POST["txtScoreMax"] . "',
					`suspend_data` = '" . $_POST["txtSuspendData"] . "',
					`credit` = '" . $strCredit . "'
					WHERE `course_id` = " . $_SESSION["Elms_CourseId"]  . " AND `user_id` = " . $strLoginId;				
		$rstResult = dbQuery($strSQL);

		$varStatus = "";
		$varCertStatus = "N";
		$varTodayDate = date('Y-m-d');
		$strSQL = "SELECT status, course_certificate_sent FROM `elms_course_scorm_track` WHERE `course_id` = " . $_SESSION["Elms_CourseId"]  . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
		$rstResult = dbQuery($strSQL);
		if (dbNumRows($rstResult)>0) {
			$rstRow = mysql_fetch_array($rstResult);
			$varStatus = $rstRow["status"];
			$varCertStatus = $rstRow["course_certificate_sent"];
		}
		
		if ($varCertStatus=="N" && (strtoupper($varStatus)=="COMPLETED" || strtoupper($varStatus)=="PASSED")) {
			$strSQL = "UPDATE elms_course_scorm_track SET course_certificate_sent='Y',course_completed_date='" . $varTodayDate . "' WHERE course_id=" . $_SESSION["Elms_CourseId"] . " AND user_id=" . $strLoginId;
			$rstResult = dbQuery($strSQL);
			
			$varImageBasePath = "http://demo.mvslms.com/";
			$varLogoHTML = '<img src="' . $varImageBasePath . 'images/logo.png" />';
			$varTodayDate = date('d-m-Y');
			$varUserName = $_SESSION["Elms_LoggedInUserName"];
			$varUserEmail = $_SESSION["Elms_LoggedInEmail"];
			$varCourseName = $_SESSION["Elms_CourseName"];
			$varCourseCatName = $_SESSION["Elms_CourseCatName"];
			
			$varArrInCompleteCourseList = array();
			/*$tempQuery = "SELECT * FROM elms_assigned_courses WHERE user_id=" . $strLoginId;
			$tempResult = mysql_query($tempQuery) or die (mysql_error());
			while ($tAssignRow = mysql_fetch_array($tempResult)) {
				$tempQuery = "SELECT course_id FROM elms_course_scorm_track WHERE user_id=" . $strLoginId . " AND course_certificate_sent='Y' AND course_id=" . $tAssignRow["course_id"];
				$tResult = mysql_query($tempQuery) or die (mysql_error());
				if (dbNumRows($tResult)<=0) {
					array_push($varArrInCompleteCourseList, $tAssignRow["course_name"]);
				}
			}*/

			$tempQuery = "SELECT * FROM elms_category_details";
			$tempResult = mysql_query($tempQuery) or die (mysql_error());
			while ($tAssignRow = mysql_fetch_array($tempResult)) {
				array_push($varArrInCompleteCourseList, $tAssignRow["category_name"]);
			}			

			$varLoginDetailsHTML = "";
			if (count($varArrInCompleteCourseList)>0) {
				$varLoginDetailsHTML .= '<br /><br />We further encourage and recommend you to take up more courses that we have offered for you to enrich your knowledge and accumulate your treasure box- after all, knowledge is the ultimate wealth!<br /><br />';
				$varLoginDetailsHTML .= '<br /><br />We offer various courses under the following categories.<br /><br />';
				$varLoginDetailsHTML .= '<table width="100%" cellspacing="0" cellpadding="0" border="0">';
					$varLoginDetailsHTML .= '<tr>';
						$varLoginDetailsHTML .= '<td width="100%" align="left">';
							$varLoginDetailsHTML .= '<div id="divPrintArea" name="divPrintArea" style="border:1px solid #cccccc;">';
								$varLoginDetailsHTML .= '<table width="100%" cellspacing="1" cellpadding="2" bgcolor="#e4e4e4">';
									$varLoginDetailsHTML .= '<tr style="background:#04548f; height:35px; font-family:arial; color:#ffffff; font-size:12px; font-weight:normal; text-align:center; vertical-align:middle;">';
										$varLoginDetailsHTML .= '<td width="2%" align="left">';
											$varLoginDetailsHTML .= '#';
										$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '<td width="98%" align="left">';
											$varLoginDetailsHTML .= 'Course Category';
										$varLoginDetailsHTML .= '</td>';										
									$varLoginDetailsHTML .= '</tr>';
									$varTempInc = 0;
									for ($i=0; $i<count($varArrInCompleteCourseList); $i++) {
										$varTempInc++;
										$varLoginDetailsHTML .= '<tr style="background:#eaffea; height:25px; font-family:arial; color:#000000; font-size:11px; font-weight:normal; text-align:left; vertical-align:middle;">';
											$varLoginDetailsHTML .= '<td width="2%" align="left" valign="middle">';
												$varLoginDetailsHTML .= $varTempInc;
											$varLoginDetailsHTML .= '</td>';										
											$varLoginDetailsHTML .= '<td width="98%" align="left" valign="middle">';
												$varLoginDetailsHTML .= $varArrInCompleteCourseList[$i];
											$varLoginDetailsHTML .= '</td>';
										$varLoginDetailsHTML .= '</tr>';
									}
								$varLoginDetailsHTML .= '</table>';
							$varLoginDetailsHTML .= '</div>';
						$varLoginDetailsHTML .= '</td>';
					$varLoginDetailsHTML .= '</tr>';
				$varLoginDetailsHTML .= '</table>';
				$varLoginDetailsHTML .= '<br /><br />';
			} else {
				$varLoginDetailsHTML .= '<br /><br />';
			}

			$varSubject = "MVSLMS: Course Completion Notification";
			$varMessage = <<<EOF
<html>
	<head></head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<table width="100%" cellspacing="0" cellpadding="0" bordercolor="#004080" border="5">
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%" align="left" valign="center">
									$varLogoHTML
								</td>
							</tr>
							<tr height="5" bgcolor="#ffcc00">
								<td></td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
							<tr>
								<td width="100%" align="center" valign="top">
									<table width="98%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="100%" align="right" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Date: $varTodayDate</b>
												</font>
											</td>
										</tr>
										<tr height="5">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Dear $varUserName,</b>
												</font>
												<br /><br />
												<font face="arial" size="2" color="#000000">
													Congratulations! You have successfully completed the course <b>$varCourseName</b> under <b>$varCourseCatName</b> curriculum on MVSLMS and have added one more feather to your cap.
													$varLoginDetailsHTML
													Happy Learning!!
													<br /><br />
													Regards,
													<br /><br />
													MVSLMS
													<br />
													<a href="http://www.mvslms.com" target="_blank">www.mvslms.com</a>
												</font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>
EOF;
			$varEmailTo = $varUserEmail;
			$varEmailFrom = "";
			$varEmailFromName = "";
			$tQuery = "SELECT company_name, company_reply_email FROM elms_branding_details";
			$tResult = mysql_query($tQuery) or die (mysql_error());
			if ($tRow = mysql_fetch_array($tResult)) {
				$varEmailFrom = $tRow["company_reply_email"];
				$varEmailFromName = $tRow["company_name"];
			}
			$varEmailFromName = "MVSLMS";
			$mail = new PHPMailer();
			$mail->From = $varEmailFrom;
			$mail->FromName = $varEmailFromName;
			$mail->AddAddress($varEmailTo, $varUserName);
			$mail->AddCC($varEmailFrom, $varEmailFromName);
			$mail->AddReplyTo($varEmailFrom, $varEmailFromName);
			$mail->IsHTML(true);
			$mail->Subject = $varSubject;
			$mail->Body = $varMessage;
			$mail->AltBody = "Here is your Course completion notification.";
			$mail->Send();
		}		
	}
?>
<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script type="text/javascript">
			var intTempTimer = null;
			function doGetSessionTime() {
				$.ajax({
					type: "post",
					url:  "elms_scorm_course_player_single_scormdata_update_session_total_time.php",
					data: ""
				}).done(function(responseText) {
					strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
				});
				intBgLoopAniTimer = setTimeout("doGetSessionTime()", 1000);
			}	
		</script>		
	</head>
	<body onload="javascript:doGetSessionTime();">
		<form id="frmSCORMData" name="frmSCORMData" method="post" action="elms_scorm_course_player_single_scormdata.php">
			<input type="hidden" id="txtCourseID" name="txtCourseID" value="" />
			<input type="hidden" id="txtLocation" name="txtLocation" value="" />
			<input type="hidden" id="txtStatus" name="txtStatus" value="" />
			<input type="hidden" id="txtCredit" name="txtCredit" value="" />
			<input type="hidden" id="txtEntry" name="txtEntry" value="" />
			<input type="hidden" id="txtScoreRaw" name="txtScoreRaw" value="" />
			<input type="hidden" id="txtTotalTime" name="txtTotalTime" value="" />
			<input type="hidden" id="txtSessionTime" name="txtSessionTime" value="" />
			<input type="hidden" id="txtSuspendData" name="txtSuspendData" value="" />
			<input type="hidden" id="txtScoreMin" name="txtScoreMin" value="" />
			<input type="hidden" id="txtScoreMax" name="txtScoreMax" value="" />
			<input type="hidden" id="txtCurPageID" name="txtCurPageID" value="" />
		</form>
	</body>
</html>