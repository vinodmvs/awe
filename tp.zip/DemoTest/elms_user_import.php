<?php
	require("elms_top_includes.php");
?>

<?php
	$varUserType = "User";
	$varUserHead = $_SESSION["Elms_LoggedInId"];
	$varUserIEType = "Internal";
	$varMemType = "";
	$varDisplayGroup = "Yes";
	
	if (isset($_POST["ddUserType"])) {
		$varUserType = $_POST["ddUserType"];
	}
	
	if (isset($_POST["ddManager"])) {
		$varUserHead = $_POST["ddManager"];
	}

	if (isset($_POST["ddUserIEType"])) {
		$varUserIEType = $_POST["ddUserIEType"];
	}

	if (isset($_POST["ddUserMemType"])) {
		$varMemType = $_POST["ddUserMemType"];
	}
	
	if ($varUserType=="User") {
		$varDisplayGroup = "Yes";
	} else {
		$varDisplayGroup = "No";
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			var strValidFileExtensions = [".xlsx"];
			
			function doInitialize() {
				document.frmMain.ddUserType.focus();
				var options = {
					beforeSubmit:showRequest,
					success:showResponse
				};
				$('#frmMain').ajaxForm(options);
			}
			
			function showRequest(formData, jqForm, options) {
				doShowProccessIcon();
			}

			function showResponse(responseText, statusText, xhr, $form) {
				strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
				if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
					document.location.href = "elms_user_list.php";
				} else {
					doShowAlertPanel(strAjaxReturnTrimed, '');
				}
				doHideProccessIcon();
			}			

			function doFormValidation() {
				if (document.frmMain.ddUserMemType.value=="") {
					doShowAlertPanel("Membership Name cannot be blank. Please select the Membership.", document.frmMain.ddUserMemType);
					return false;
				} else {			
				if (document.frmMain.ddUserType.value=="User" && document.frmMain.ddGroup.value=="") {
					doShowAlertPanel("Please select the Group. Read the information for more details.", document.frmMain.ddGroup);
					return false;
				} else {
				if (document.frmMain.txtExcelFile.value=="") {
					doShowAlertPanel("Please choose the User Details Excel file and then upload.", document.frmMain.txtExcelFile);
					return false;
				} else {
				if (document.frmMain.txtExcelFile.value!="" && !doValidFileExtension(document.frmMain.txtExcelFile.value)) {
					doShowAlertPanel("Invalid Excel file. Please choose the valid file. Read the information for more details.", document.frmMain.txtExcelFile);
					return false;
				} else {
					return true;
				} } } }
			}
			
			function doGetGroupDetailsRecords() {
				doShowProccessIcon();
				document.frmMain.action = "elms_user_import.php";
				document.frmMain.submit();
			}
			
			function doValidFileExtension(strTemp){
				var varRetVal = false;
				var sCurExtension = "";
				for (var i=0; i<strValidFileExtensions.length; i++) {
					sCurExtension = strValidFileExtensions[i];
					if (strTemp.substr(strTemp.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
						varRetVal = true;
						break;
					}
				}
				return varRetVal;
			}			
		</script>
	</head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0" onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0" border="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_user_import_update.php" onsubmit="javascript:return doFormValidation();">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%">Import User(s)</td>
																						</tr>
																						<tr height="30">
																							<th width="100%" align="center" valign="middle" class="clsTableSubHeadingText">Excel Manager or Learner Data Upload Instructions</th>
																						</tr>
																						<tr>
																							<td width="100%" align="" valign="middle">
																								<table width="98%" cellspacing="2" cellpadding="2" align="center">
																									<tr>
																										<td width="100%" align="left" valign="top">
																											<p>Fields marked with <font color="red">*</font> are mandatory</p>
																											<p>
																												Importing multiple users to the LMS system was never this easy. Administrator can import both Manages and Learners to the LMS System and Managers can only import Learners into the LMS System. If you are an Administrator, Choose Role first, if you Select Role as User then select under which Manager they should come finally select the Group to which the User should be associated.
																											</p>
																											</p>
																												<img src="images/img_import_user.png" />
																											<p>
																											<p>
																												Please ensure that your excel document has column name in the above order. Also the Lastname column is optional but FirstName and Email is mandatory.
																											</p>
																										</tr>
																									</td>
																								</table>
																							</td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="top">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="left" valign="middle">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="100%" align="left" valign="middle">
																														<font color="red">*</font> Role:
																														<select id="ddUserType" name="ddUserType" size="1" class="clsTextField" style="width:300px;" onchange="javascript:doGetGroupDetailsRecords();">
																															<?php if ($varUserType=="Manager") { ?>
																																<option selected value="Manager">Manager</option>
																															<?php } else { ?>
																																<option value="Manager">Manager</option>
																															<?php } ?>
																															
																															<?php if ($varUserType=="User") { ?>
																																<option selected value="User">User</option>
																															<?php } else { ?>
																																<option value="User">User</option>
																															<?php } ?>																															
																														</select>																													
																														<span id="spanManagerList" name="spanManagerList" style="display:inline-block;">
																															&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																															<font color="red">*</font> Select Manager:
																															<select id="ddManager" name="ddManager" size="1" class="clsTextField" style="width:300px;" onchange="javascript:doGetGroupDetailsRecords();">
																																<option selected value="<?php echo $_SESSION['Elms_LoggedInId']; ?>">Admin as Manager</option>
																																<?php
																																	$tempTQuery = "SELECT user_id, user_fname FROM elms_user_details WHERE user_head=" . $_SESSION["Elms_LoggedInId"] . " AND user_role='Manager' AND user_status='A' ORDER BY user_id";
																																	$managerResult = mysql_query($tempTQuery) or die (mysql_error());
																																	while ($tempRow = mysql_fetch_array($managerResult)) {
																																?>
																																		<?php if ($tempRow["user_id"]==$varUserHead) { ?>
																																			<option selected value="<?php echo $tempRow["user_id"]; ?>"><?php echo $tempRow["user_fname"]; ?></option>
																																		<?php } else { ?>
																																			<option value="<?php echo $tempRow["user_id"]; ?>"><?php echo $tempRow["user_fname"]; ?></option>
																																		<?php } ?>
																																<?php
																																	}
																																?>
																															</select>
																														</span>
																													</td>
																												</tr>
																												<tr height="25">
																													<td></td>
																												</tr>
																												<tr>
																													<td width="100%" align="left" valign="middle">
																														<font color="red">*</font> User Type:
																														<select id="ddUserIEType" name="ddUserIEType" size="1" class="clsTextField" style="width:150px;" onchange="javascript:doGetGroupDetailsRecords();">
																															<?php if ($varUserIEType=="Internal") { ?>
																																<option selected value="Internal">Internal</option>
																															<?php } else { ?>
																																<option value="Internal">Internal</option>
																															<?php } ?>
																															
																															<?php if ($varUserIEType=="External") { ?>
																																<option selected value="External">External</option>
																															<?php } else { ?>
																																<option value="External">External</option>
																															<?php } ?>
																														</select>
																														&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																														<font color="red">*</font> Membership:&nbsp;
																														<select id="ddUserMemType" name="ddUserMemType" size="1" class="clsTextField" style="width:200px;">
																															<option selected value="">---Select Membership---</option>
																														<?php
																															$tQuery = "SELECT * FROM elms_membership_details WHERE mem_type='" . $varUserIEType . "'";
																															$tResult = mysql_query($tQuery) or die (mysql_error());
																															while ($tRow = mysql_fetch_array($tResult)) {
																														?>
																																<?php if ($tRow["mem_id"]==$varMemType) { ?>
																																	<option selected value="<?php echo $tRow["mem_id"]; ?>"><?php echo $tRow["mem_name"]; ?></option>
																																<?php } else { ?>
																																	<option value="<?php echo $tRow["mem_id"]; ?>"><?php echo $tRow["mem_name"]; ?></option>
																																<?php } ?>
																														<?php
																															}
																														?>																											
																														</select>
																														<?php if ($varDisplayGroup=="Yes") { ?>
																															<span id="spanGroupList" name="spanGroupList" style="display:inline-block;">
																														<?php } else { ?>
																															<span id="spanGroupList" name="spanGroupList" style="display:none;">
																														<?php } ?>
																															&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																															<font color="red">*</font> Group:
																															<select id="ddGroup" name="ddGroup" size="1" class="clsTextField" style="width:400px;">
																																<option selected value="">---Select Group---</option>
																																<?php
																																	$tQuery = "SELECT ELMSGD.group_id AS group_id, ELMSGD.group_type AS group_type, ELMSAG.user_id AS user_id, ELMSAG.group_id AS group_id, ELMSAG.group_name AS group_name FROM elms_group_details ELMSGD INNER JOIN elms_assigned_groups ELMSAG ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSGD.group_type='" . $varUserIEType . "' AND ELMSAG.user_id=" . $varUserHead;
																																	$tGroupResult = mysql_query($tQuery) or die (mysql_error());
																																	while ($tRow = mysql_fetch_array($tGroupResult)) {
																																?>
																																		<option value="<?php echo $tRow["group_id"]; ?>~<?php echo $tRow["group_name"]; ?>"><?php echo $tRow["group_name"]; ?></option>
																																<?php
																																	}
																																?>																																
																															</select>
																														</span>
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																									<tr>
																										<td width="100%" align="left" valign="top">
																											<br />
																											<font color="red">*</font> Browse Excel File:&nbsp;<input id="txtExcelFile" name="txtExcelFile" type="file"  />
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr>
																							<td width="100%" align="center" valign="top">
																								<table width="98%" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="100%" align="center">
																											<table width="100%" cellspacing="0" cellpadding="0">
																												<tr>
																													<td width="100%" align="right" valign="middle">
																														<input type="submit" id="btnFinish" name="btnFinish" value="&nbsp;Upload&nbsp;" class="clsActionButton" />
																														<input type="button" id="btnCancel" name="btnCancel" value="Cancel" class="clsActionButton" onclick="javascript:doCancel('elms_user_list.php');" />
																													</td>
																												</tr>
																											</table>
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="10">
																							<td></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="100">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>