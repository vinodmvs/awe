<?php
	require("elms_top_includes.php");
?>

<?php
	$varUserId = "";
	if (!isset($_POST["txtUserId"])) {
		header("Location:elms_login.php");
	} else {
		$varUserId = $_POST["txtUserId"];
		$tempQuery = "SELECT * FROM elms_user_details WHERE user_id=" . $varUserId;
		$userResult = mysql_query($tempQuery) or die (mysql_error());
		$userRow = mysql_fetch_array($userResult);
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doInitialize() {
				$("#txtDOB").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true,changeYear: true, yearRange: "-75:+0"});
			}

			function doFormValidation() {
				if (document.frmMain.txtFName.value=="") {
					doShowAlertPanel("First Name cannot be blank. Please enter the First Name.", document.frmMain.txtFName);
				} else {
				if (document.frmMain.txtPass.value=="") {
					doShowAlertPanel("Password cannot be blank. Please enter the Password.", document.frmMain.txtPass);
				//} else {				
				//if (document.getElementsByName('lstGroupsAssigned[]').length<=0) {
					//if (document.frmMain.ddUserType.value=="User") {
						//doShowAlertPanel("Please assign the Group to the User.", '');
					//} else {
						//doShowAlertPanel("Please assign the Group to the Manager.", '');
					//}
				} else {
					for (var i=0; i<document.getElementsByName('lstGroupsAssigned[]').length; i++) {
						document.getElementsByName('lstGroupsAssigned[]')[i].checked = true;
					}				
					for (var i=0; i<document.getElementsByName('lstCoursesAssigned[]').length; i++) {
						document.getElementsByName('lstCoursesAssigned[]')[i].checked = true;
					}
					var strPOSTURL = "elms_user_edit_update.php";
					var objFormData = $( "#frmMain" ).serialize();					
					doPOSTNormalFormData(strPOSTURL, objFormData);
				} } //}
			}

			function doPOSTNormalFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
							document.location.href = "elms_user_list.php";
						} else {
							doShowAlertPanel(strAjaxReturnTrimed, '');
						}
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}
			
			/* Group Handling */
			function doAddSelectedGroup() {
				if (document.getElementsByName('lstGroupsAssigned[]').length<=0) {
					document.getElementById('divGroupsAssignedPanel').innerHTML = "";
				}			
				var tempCount = document.getElementsByName('lstGroupsAvail[]').length;
				var tempSelectedCount = 0;
				var tempInnerHTML = "";
				var tempInc = 0;				
				for (var i=0; i<tempCount; i++) {
					if (document.getElementsByName('lstGroupsAvail[]')[i].checked==true) {
						tempSelectedCount++;
						break;
					}
				}
				if (tempSelectedCount<=0) {
					doShowAlertPanel("You have not selected any of the Group. Please select atleast one Group to assign.", '');
				} else {
					for (var i=0; i<tempCount; i++) {
						if (document.getElementsByName('lstGroupsAvail[]')[i].checked==true) {
							if (tempInnerHTML=="") {
								tempInnerHTML = '<div id="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');">';
								tempInnerHTML = tempInnerHTML + '<table width="100%" cellspacing="0" cellpadding="0" border="0">';
								tempInnerHTML = tempInnerHTML + '<tr>';
								tempInnerHTML = tempInnerHTML + '<td width="2%" align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + '<input type="checkbox" id="lstGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="lstGroupsAssigned[]" value="' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');" style="cursor:pointer;" />';
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '<td align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + document.getElementsByName('lstGroupsAvail[]')[i].getAttribute('groupname');
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '</tr>';
								tempInnerHTML = tempInnerHTML + '</table>';
								tempInnerHTML = tempInnerHTML + '</div>';
								tempInnerHTML = tempInnerHTML + '<div id="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="height:3px;"></div>';
							} else {
								tempInnerHTML = tempInnerHTML + '<div id="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');">';
								tempInnerHTML = tempInnerHTML + '<table width="100%" cellspacing="0" cellpadding="0" border="0">';
								tempInnerHTML = tempInnerHTML + '<tr>';
								tempInnerHTML = tempInnerHTML + '<td width="2%" align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + '<input type="checkbox" id="lstGroupsAssigned_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="lstGroupsAssigned[]" value="' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" onclick="javascript:doCheckORUncheckGroupsAssigned(' + document.getElementsByName('lstGroupsAvail[]')[i].value + ');" style="cursor:pointer;" />';
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '<td align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + document.getElementsByName('lstGroupsAvail[]')[i].getAttribute('groupname');
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '</tr>';
								tempInnerHTML = tempInnerHTML + '</table>';
								tempInnerHTML = tempInnerHTML + '</div>';
								tempInnerHTML = tempInnerHTML + '<div id="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" name="divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAvail[]')[i].value + '" style="height:3px;"></div>';						
							}
							tempInc++;
						}
					}
					if (document.frmMain.ddUserType.value=="User") {
						if (tempInc>1 || document.getElementsByName('lstGroupsAssigned[]').length>=1) {
							doShowAlertPanel("You can not assign more then one Group to the User.", '');
						} else {
							document.getElementById('divGroupsAssignedPanel').innerHTML = tempInnerHTML;
						}
					} else {
						var flgGroupFound = false;
						for (var i=0; i<document.getElementsByName('lstGroupsAvail[]').length; i++) {
							for (var j=0; j<document.getElementsByName('lstGroupsAssigned[]').length; j++) {
								if (document.getElementsByName('lstGroupsAvail[]')[i].checked==true && document.getElementsByName('lstGroupsAvail[]')[i].value==document.getElementsByName('lstGroupsAssigned[]')[j].value) {
									flgGroupFound = true;
									break;
								}
							}
						}
						if (flgGroupFound) {
							doShowAlertPanel("Any one of the selected Group already assigned to the User. Please try again with the correct selection.", '');
						} else {
							document.getElementById('divGroupsAssignedPanel').innerHTML = document.getElementById('divGroupsAssignedPanel').innerHTML + tempInnerHTML;
						}
					}
				}
			}
			
			function doRemoveSelectedGroup() {
				var tempCount = document.getElementsByName('lstGroupsAssigned[]').length;
				var tempSelectedCount = 0;
				for (var i=0; i<tempCount; i++) {
					if (document.getElementsByName('lstGroupsAssigned[]')[i].checked==true) {
						tempSelectedCount++;
						break;
					}
				}
				if (tempSelectedCount<=0) {
					doShowAlertPanel("You have not selected any of the Group. Please select atleast one Group to remove.", '');
				} else {
					for (var j=tempCount-1; j>=0; j--) {
						if (document.getElementsByName('lstGroupsAssigned[]')[j].checked==true) {
							if (document.getElementById('divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAssigned[]')[j].value)!=null && document.getElementById('divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAssigned[]')[j].value)!=undefined) {
								document.getElementById('divGroupsAssignedPanel').removeChild(document.getElementById('divGroupsAssignedDummy_' + document.getElementsByName('lstGroupsAssigned[]')[j].value));
							}
							if (document.getElementById('divGroupsAssigned_' + document.getElementsByName('lstGroupsAssigned[]')[j].value)!=null && document.getElementById('divGroupsAssigned_' + document.getElementsByName('lstGroupsAssigned[]')[j].value)!=undefined) {
								document.getElementById('divGroupsAssignedPanel').removeChild(document.getElementById('divGroupsAssigned_' + document.getElementsByName('lstGroupsAssigned[]')[j].value));
							}
						}
					}
					doCheckAllAssignedGroupsSelected();
				}
			}			

			function doCheckORUncheckGroupsAvail(varTemp) {
				var objTemp = document.getElementById("divGroupsAvail_" + varTemp);
				var objThis = document.getElementById("lstGroupsAvail_" + varTemp);
				if (objThis.checked==true) {
					objThis.checked=false;
					objTemp.style.backgroundColor = "#ffffff";
				} else {
					objThis.checked=true;
					objTemp.style.backgroundColor = "#d4d4d4";
				}
				doCheckAllAvailGroupsSelected();
			}
			
			function doCheckORUncheckGroupsAssigned(varTemp) {
				var objTemp = document.getElementById("divGroupsAssigned_" + varTemp);
				var objThis = document.getElementById("lstGroupsAssigned_" + varTemp);
				if (objThis.checked==true) {
					objThis.checked=false;
					objTemp.style.backgroundColor = "#ffffff";
				} else {
					objThis.checked=true;
					objTemp.style.backgroundColor = "#d4d4d4";
				}
				doCheckAllAssignedGroupsSelected();
			}
			
			function doCheckORUncheckAllAvailGroups(objThis) {
				var objTemp = null;
				var tempCount = document.getElementsByName('lstGroupsAvail[]').length;
				if (objThis.checked==true) {
					objThis.checked=false;
				} else {
					objThis.checked=true;
				}
				for (var i=0; i<tempCount; i++) {
					objTemp = document.getElementById(document.getElementsByName('lstGroupsAvail[]')[i].id.split("lst").join("div"));
					if (objThis.checked==true) {
						document.getElementsByName('lstGroupsAvail[]')[i].checked = true;
						objTemp.style.backgroundColor = "#d4d4d4";
					} else {
						document.getElementsByName('lstGroupsAvail[]')[i].checked = false;
						objTemp.style.backgroundColor = "#ffffff";
					}
				}
				doCheckAllAvailGroupsSelected();
			}
			
			function doCheckAllAvailGroupsSelected() {
				var boolAllSelected = true;
				if (document.getElementsByName("lstGroupsAvail[]").length<=0) {
					boolAllSelected = false;
				} else {
					for (var i=0; i<document.getElementsByName("lstGroupsAvail[]").length; i++) {
						if (document.getElementsByName("lstGroupsAvail[]")[i].checked==false) {
							boolAllSelected = false;
							break;
						}
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkCheckOrUncheckAllAvailGroups").checked = true;
				} else {
					document.getElementById("chkCheckOrUncheckAllAvailGroups").checked = false;
				}
			}			
			
			function doCheckORUncheckAllAssignedGroups(objThis) {
				var objTemp = null;
				var tempCount = document.getElementsByName('lstGroupsAssigned[]').length;
				if (objThis.checked==true) {
					objThis.checked=false;
				} else {
					objThis.checked=true;
				}
				for (var i=0; i<tempCount; i++) {
					objTemp = document.getElementById(document.getElementsByName('lstGroupsAssigned[]')[i].id.split("lst").join("div"));
					if (objThis.checked==true) {
						document.getElementsByName('lstGroupsAssigned[]')[i].checked = true;
						objTemp.style.backgroundColor = "#d4d4d4";
					} else {
						document.getElementsByName('lstGroupsAssigned[]')[i].checked = false;
						objTemp.style.backgroundColor = "#ffffff";
					}
				}
				doCheckAllAssignedGroupsSelected();
			}

			function doCheckAllAssignedGroupsSelected() {
				var boolAllSelected = true;
				if (document.getElementsByName("lstGroupsAssigned[]").length<=0) {
					boolAllSelected = false;
				} else {
					for (var i=0; i<document.getElementsByName("lstGroupsAssigned[]").length; i++) {
						if (document.getElementsByName("lstGroupsAssigned[]")[i].checked==false) {
							boolAllSelected = false;
							break;
						}
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkCheckOrUncheckAllAssignedGroups").checked = true;
				} else {
					document.getElementById("chkCheckOrUncheckAllAssignedGroups").checked = false;
				}
			}
			/* Group Handling */
			
			/* Course Handling */
			function doAddSelectedCourse() {
				if (document.getElementsByName('lstCoursesAssigned[]').length<=0) {
					document.getElementById('divCoursesAssignedPanel').innerHTML = "";
				}
				var tempCount = document.getElementsByName('lstCoursesAvail[]').length;
				var tempSelectedCount = 0;
				var tempInnerHTML = "";
				var tempInc = 0;				
				for (var i=0; i<tempCount; i++) {
					if (document.getElementsByName('lstCoursesAvail[]')[i].checked==true) {
						tempSelectedCount++;
						break;
					}
				}
				if (tempSelectedCount<=0) {
					doShowAlertPanel("You have not selected any of the Course. Please select atleast one Course to assign.", '');
				} else {
					for (var i=0; i<tempCount; i++) {
						if (document.getElementsByName('lstCoursesAvail[]')[i].checked==true) {
							if (tempInnerHTML=="") {
								tempInnerHTML = '<div id="divCoursesAssigned_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" name="divCoursesAssigned_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckCoursesAssigned(' + document.getElementsByName('lstCoursesAvail[]')[i].value + ');">';
								tempInnerHTML = tempInnerHTML + '<table width="100%" cellspacing="0" cellpadding="0" border="0">';
								tempInnerHTML = tempInnerHTML + '<tr>';
								tempInnerHTML = tempInnerHTML + '<td width="2%" align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + '<input type="checkbox" id="lstCoursesAssigned_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" name="lstCoursesAssigned[]" value="' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" onclick="javascript:doCheckORUncheckCoursesAssigned(' + document.getElementsByName('lstCoursesAvail[]')[i].value + ');" style="cursor:pointer;" />';
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '<td align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + document.getElementsByName('lstCoursesAvail[]')[i].getAttribute('coursename');
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '</tr>';
								tempInnerHTML = tempInnerHTML + '</table>';
								tempInnerHTML = tempInnerHTML + '</div>';
								tempInnerHTML = tempInnerHTML + '<div id="divCoursesAssignedDummy_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" name="divCoursesAssignedDummy_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" style="height:3px;"></div>';
							} else {
								tempInnerHTML = tempInnerHTML + '<div id="divCoursesAssigned_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" name="divCoursesAssigned_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckCoursesAssigned(' + document.getElementsByName('lstCoursesAvail[]')[i].value + ');">';
								tempInnerHTML = tempInnerHTML + '<table width="100%" cellspacing="0" cellpadding="0" border="0">';
								tempInnerHTML = tempInnerHTML + '<tr>';
								tempInnerHTML = tempInnerHTML + '<td width="2%" align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + '<input type="checkbox" id="lstCoursesAssigned_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" name="lstCoursesAssigned[]" value="' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" onclick="javascript:doCheckORUncheckCoursesAssigned(' + document.getElementsByName('lstCoursesAvail[]')[i].value + ');" style="cursor:pointer;" />';
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '<td align="left" valign="top">';
								tempInnerHTML = tempInnerHTML + document.getElementsByName('lstCoursesAvail[]')[i].getAttribute('coursename');
								tempInnerHTML = tempInnerHTML + '</td>';
								tempInnerHTML = tempInnerHTML + '</tr>';
								tempInnerHTML = tempInnerHTML + '</table>';
								tempInnerHTML = tempInnerHTML + '</div>';
								tempInnerHTML = tempInnerHTML + '<div id="divCoursesAssignedDummy_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" name="divCoursesAssignedDummy_' + document.getElementsByName('lstCoursesAvail[]')[i].value + '" style="height:3px;"></div>';
							}
							tempInc++;
						}
					}

					var flgCourseFound = false;
					for (var i=0; i<document.getElementsByName('lstCoursesAvail[]').length; i++) {
						for (var j=0; j<document.getElementsByName('lstCoursesAssigned[]').length; j++) {
							if (document.getElementsByName('lstCoursesAvail[]')[i].checked==true && document.getElementsByName('lstCoursesAvail[]')[i].value==document.getElementsByName('lstCoursesAssigned[]')[j].value) {
								flgCourseFound = true;
								break;
							}
						}
					}
					if (flgCourseFound) {
						doShowAlertPanel("Any one of the selected Course already assigned to the User. Please try again with the correct selection.", '');
					} else {
						document.getElementById('divCoursesAssignedPanel').innerHTML = document.getElementById('divCoursesAssignedPanel').innerHTML + tempInnerHTML;
					}
				}
				document.getElementById('divTAC').innerHTML = document.getElementsByName('lstCoursesAssigned[]').length;
			}
			
			function doRemoveSelectedCourse() {
				var tempCount = document.getElementsByName('lstCoursesAssigned[]').length;
				var tempSelectedCount = 0;
				for (var i=0; i<tempCount; i++) {
					if (document.getElementsByName('lstCoursesAssigned[]')[i].checked==true) {
						tempSelectedCount++;
						break;
					}
				}
				if (tempSelectedCount<=0) {
					doShowAlertPanel("You have not selected any of the Course. Please select atleast one Course to remove.", '');
				} else {
					for (var j=tempCount-1; j>=0; j--) {
						if (document.getElementsByName('lstCoursesAssigned[]')[j].checked==true) {
							if (document.getElementById('divCoursesAssignedDummy_' + document.getElementsByName('lstCoursesAssigned[]')[j].value)!=null && document.getElementById('divCoursesAssignedDummy_' + document.getElementsByName('lstCoursesAssigned[]')[j].value)!=undefined) {
								document.getElementById('divCoursesAssignedPanel').removeChild(document.getElementById('divCoursesAssignedDummy_' + document.getElementsByName('lstCoursesAssigned[]')[j].value));
							}
							if (document.getElementById('divCoursesAssigned_' + document.getElementsByName('lstCoursesAssigned[]')[j].value)!=null && document.getElementById('divCoursesAssigned_' + document.getElementsByName('lstCoursesAssigned[]')[j].value)!=undefined) {
								document.getElementById('divCoursesAssignedPanel').removeChild(document.getElementById('divCoursesAssigned_' + document.getElementsByName('lstCoursesAssigned[]')[j].value));
							}
						}
					}
					doCheckAllAssignedCoursesSelected();
				}
				document.getElementById('divTAC').innerHTML = document.getElementsByName('lstCoursesAssigned[]').length;
			}			

			function doCheckORUncheckCoursesAvail(varTemp) {
				var objTemp = document.getElementById("divCoursesAvail_" + varTemp);
				var objThis = document.getElementById("lstCoursesAvail_" + varTemp);
				if (objThis.checked==true) {
					objThis.checked=false;
					objTemp.style.backgroundColor = "#ffffff";
				} else {
					objThis.checked=true;
					objTemp.style.backgroundColor = "#d4d4d4";
				}
				doCheckAllAvailCoursesSelected();
			}
			
			function doCheckORUncheckCoursesAssigned(varTemp) {
				var objTemp = document.getElementById("divCoursesAssigned_" + varTemp);
				var objThis = document.getElementById("lstCoursesAssigned_" + varTemp);
				if (objThis.checked==true) {
					objThis.checked=false;
					objTemp.style.backgroundColor = "#ffffff";
				} else {
					objThis.checked=true;
					objTemp.style.backgroundColor = "#d4d4d4";
				}
				doCheckAllAssignedCoursesSelected();
			}
			
			function doCheckORUncheckAllAvailCourses(objThis) {
				var objTemp = null;
				var tempCount = document.getElementsByName('lstCoursesAvail[]').length;
				if (objThis.checked==true) {
					objThis.checked=false;
				} else {
					objThis.checked=true;
				}
				for (var i=0; i<tempCount; i++) {
					objTemp = document.getElementById(document.getElementsByName('lstCoursesAvail[]')[i].id.split("lst").join("div"));
					if (objThis.checked==true) {
						document.getElementsByName('lstCoursesAvail[]')[i].checked = true;
						objTemp.style.backgroundColor = "#d4d4d4";
					} else {
						document.getElementsByName('lstCoursesAvail[]')[i].checked = false;
						objTemp.style.backgroundColor = "#ffffff";
					}
				}
				doCheckAllAvailCoursesSelected();
			}
			
			function doCheckAllAvailCoursesSelected() {
				var boolAllSelected = true;
				if (document.getElementsByName("lstCoursesAvail[]").length<=0) {
					boolAllSelected = false;
				} else {
					for (var i=0; i<document.getElementsByName("lstCoursesAvail[]").length; i++) {
						if (document.getElementsByName("lstCoursesAvail[]")[i].checked==false) {
							boolAllSelected = false;
							break;
						}
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkCheckOrUncheckAllAvailCourses").checked = true;
				} else {
					document.getElementById("chkCheckOrUncheckAllAvailCourses").checked = false;
				}
			}			
			
			function doCheckORUncheckAllAssignedCourses(objThis) {
				var objTemp = null;
				var tempCount = document.getElementsByName('lstCoursesAssigned[]').length;
				if (objThis.checked==true) {
					objThis.checked=false;
				} else {
					objThis.checked=true;
				}
				for (var i=0; i<tempCount; i++) {
					objTemp = document.getElementById(document.getElementsByName('lstCoursesAssigned[]')[i].id.split("lst").join("div"));
					if (objThis.checked==true) {
						document.getElementsByName('lstCoursesAssigned[]')[i].checked = true;
						objTemp.style.backgroundColor = "#d4d4d4";
					} else {
						document.getElementsByName('lstCoursesAssigned[]')[i].checked = false;
						objTemp.style.backgroundColor = "#ffffff";
					}
				}
				doCheckAllAssignedCoursesSelected();
			}

			function doCheckAllAssignedCoursesSelected() {
				var boolAllSelected = true;
				if (document.getElementsByName("lstCoursesAssigned[]").length<=0) {
					boolAllSelected = false;
				} else {
					for (var i=0; i<document.getElementsByName("lstCoursesAssigned[]").length; i++) {
						if (document.getElementsByName("lstCoursesAssigned[]")[i].checked==false) {
							boolAllSelected = false;
							break;
						}
					}
				}
				if (boolAllSelected==true) {
					document.getElementById("chkCheckOrUncheckAllAssignedCourses").checked = true;
				} else {
					document.getElementById("chkCheckOrUncheckAllAssignedCourses").checked = false;
				}
			}
			/* Course Handling */			
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_user_edit_update.php">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="2">Edit User</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="2">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<tr>
																							<td width="100%" align="left" valign="top">
																								<table width="100%" align="center" cellspacing="2" cellpadding="2">
																									<tr>
																										<td width="14%" align="right">
																											<font color="red">*</font> User Type:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<?php echo $userRow["user_type"]; ?>
																											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																											<font color="red">*</font> Membership:&nbsp;
																											<?php
																												$tQuery = "SELECT * FROM elms_membership_details WHERE mem_id='" . $userRow["user_mem_type"] . "'";
																												$tResult = mysql_query($tQuery) or die (mysql_error());
																												$tRow = mysql_fetch_array($tResult);
																											?>
																											<?php echo $tRow["mem_name"]; ?>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											<font color="red">*</font> Title:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<?php
																												$varUserTitle = $userRow["user_title"];
																											?>
																											<select id="ddUserTitle" name="ddUserTitle" size="1" class="clsTextField" style="width:8%;">
																												<?php if ($varUserTitle=="Mr.") { ?>
																													<option selected value="Mr.">Mr.</option>
																												<?php } else { ?>
																													<option value="Mr.">Mr.</option>
																												<?php } ?>
																												
																												<?php if ($varUserTitle=="Miss") { ?>
																													<option selected value="Miss">Miss</option>
																												<?php } else { ?>
																													<option value="Miss">Miss</option>
																												<?php } ?>
																												
																												<?php if ($varUserTitle=="Mrs.") { ?>
																													<option selected value="Mrs.">Mrs.</option>
																												<?php } else { ?>
																													<option value="Mrs.">Mrs.</option>
																												<?php } ?>

																												<?php if ($varUserTitle=="Dr.") { ?>
																													<option selected value="Dr.">Dr.</option>
																												<?php } else { ?>
																													<option value="Dr.">Dr.</option>
																												<?php } ?>																												
																											</select>
																										</td>																										
																									</tr>																									
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											<font color="red">*</font> First Name:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<input type="text" id="txtFName" name="txtFName" class="clsTextField" style="width:40%" value="<?php echo $userRow["user_fname"]; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>																									
																									<tr>
																										<td width="14%" align="right">
																											Last Name:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<input type="text" id="txtLName" name="txtLName" class="clsTextField" style="width:40%" value="<?php echo $userRow["user_lname"]; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											Date of Birth:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<input type="text" id="txtDOB" name="txtDOB" class="clsTextField" style="width:15%" value="<?php echo $userRow["user_dob"]; ?>" />
																											<div style="display:inline-block;vertical-align:middle;" onclick="javascript:$('#txtDOB').datepicker('show');"><img width="25" height="25" src="images/calendar_icon.png" style="cursor:pointer" /></div>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											<font color="red">*</font> E-mail (Login Id):
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<?php echo $userRow["user_email"]; ?>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											<font color="red">*</font> Password:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<input type="text" id="txtPass" name="txtPass" class="clsTextField" style="width:40%" value="<?php echo $userRow["user_pass"]; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											Mobile:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<input type="text" id="txtPhone" name="txtPhone" class="clsTextField" style="width:25%" value="<?php echo $userRow["user_phone"]; ?>" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											<font color="red">*</font> User Role:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<?php
																												$varTempDisplay = "Learner";
																												if ($userRow["user_role"]=="Manager") {
																													$varTempDisplay = "Manager";
																												} else {
																													$varTempDisplay = "Learner";
																												}
																												echo $varTempDisplay;
																											?>
																											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																											Reports To:&nbsp;
																											<?php
																												$tempTQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $userRow["user_head"];
																												$tResult = mysql_query($tempTQuery) or die (mysql_error());
																												$tRow = mysql_fetch_array($tResult);
																												echo $tRow["user_fname"];
																											?>
																										</td>																										
																									</tr>
																									<?php if ($userRow["user_role"]=="Manager") { ?>
																										<tr height="5">
																											<td width="100%" colspan="3"></td>
																										</tr>
																										<tr>
																											<td width="14%" align="right">
																												Select Manager Permission:
																											</td>
																											<td width="1%">
																											</td>																										
																											<td width="85%" align="left">
																												<span id="spanUserPermissionList" name="spanUserPermissionList" style="width:80%; display:inline-block;">
																													<?php if ($userRow["user_mg_per"]=="Y") { ?>
																														<input type="checkbox" id="chkMGPer" name="chkMGPer" checked value="Y" />&nbsp;Manage Groups (Add/Edit/Delete)
																													<?php } else { ?>
																														<input type="checkbox" id="chkMGPer" name="chkMGPer" value="Y" />&nbsp;Manage Groups (Add/Edit/Delete)
																													<?php } ?>
																													&nbsp;&nbsp;
																													<?php if ($userRow["user_mu_per"]=="Y") { ?>
																														<input type="checkbox" id="chkMUPer" name="chkMUPer" checked value="Y" />&nbsp;Manage Users (Add/Edit/Delete)
																													<?php } else { ?>
																														<input type="checkbox" id="chkMUPer" name="chkMUPer" value="Y" />&nbsp;Manage Users (Add/Edit/Delete)
																													<?php } ?>
																												</span>
																											</td>																										
																										</tr>
																									<?php } ?>																									
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right" valign="top">
																											Assign Group:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<div id="divAssignGroup" name="divAssignGroup">
																												<table width="100%" align="center" cellspacing="2" cellpadding="2">
																													<tr>
																														<td width="40%" align="left" valign="middle">
																															<b>Available Group(s):</b>
																															<div style="height:5px;"></div>
																															<div style="width:90px; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckAllAvailGroups(document.getElementById('chkCheckOrUncheckAllAvailGroups'));">
																																<input type="checkbox" id="chkCheckOrUncheckAllAvailGroups" name="chkCheckOrUncheckAllAvailGroups" onclick="javascript:doCheckORUncheckAllAvailGroups(this);" style="cursor:pointer;" />&nbsp;Select All
																															</div>
																															<div style="height:5px;"></div>
																															<div id="divGroupsAvailPanel" name="divGroupsAvailPanel" style="background-color:#f4f4f4; overflow-x:hidden; overflow-y:auto; border:5px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; width:100%; height:160px;">
																																<?php
																																	$strTMessage = "";
																																	$varUserType = $userRow["user_type"];
																																	$varManager = $userRow["user_head"];
																																	$varRole = $userRow["user_role"];
																																	if ($varRole=="Manager") {
																																		$tempTQuery = "SELECT ELMSGD.group_type, ELMSGD.group_assigned, ELMSAG.group_id, ELMSAG.group_name, ELMSAG.user_id FROM elms_group_details ELMSGD INNER JOIN elms_assigned_groups ELMSAG ON ELMSGD.group_id=ELMSAG.group_id WHERE ELMSGD.group_type='" . $varUserType . "' AND (ELMSGD.group_assigned='N' AND ELMSAG.group_id<>11 AND ELMSAG.user_id=" . $varManager . ") ORDER BY ELMSAG.group_name";
																																	} else {
																																		$tempTQuery = "SELECT ELMSGD.group_type, ELMSGD.group_assigned, ELMSAG.group_id, ELMSAG.group_name, ELMSAG.user_id FROM elms_group_details ELMSGD INNER JOIN elms_assigned_groups ELMSAG ON ELMSGD.group_id=ELMSAG.group_id WHERE ELMSGD.group_type='" . $varUserType . "' AND (ELMSAG.group_id<>11 AND ELMSAG.user_id=" . $varManager . ") ORDER BY ELMSAG.group_name";
																																	}
																																	$tResult = mysql_query($tempTQuery) or die (mysql_error());
																																	if (dbNumRows($tResult)<=0) {
																																		$strTMessage =  "No groups available.";
																																	}
																																?>																															
																																<?php if ($strTMessage=="") { ?>
																																	<?php while ($row = mysql_fetch_array($tResult)) { ?>
																																		<div id="divGroupsAvail_<?php echo $row["group_id"]; ?>" name="divGroupsAvail_<?php echo $row["group_id"]; ?>" style="width:100%; height:25px; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckGroupsAvail(<?php echo $row["group_id"]; ?>);">
																																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																																				<tr>
																																					<td width="2%" align="left" valign="top">
																																						<input type="checkbox" id="lstGroupsAvail_<?php echo $row["group_id"]; ?>" name="lstGroupsAvail[]" value="<?php echo $row["group_id"]; ?>" groupname="<?php echo $row["group_name"]; ?>" onclick="javascript:doCheckORUncheckGroupsAvail(<?php echo $row["group_id"]; ?>);" style="cursor:pointer;" />
																																					</td>
																																					<td align="left" valign="top">
																																						<?php echo $row["group_name"]; ?>
																																					</td>
																																				</tr>
																																			</table>																																		
																																		</div>
																																		<div style="height:3px;"></div>
																																	<?php } ?>
																																<?php } else { ?>
																																	<?php echo $strTMessage; ?>
																																<?php } ?>
																															</div>
																														</td>
																														<td width="10%" align="center" valign="middle">
																															<br /><br /><br />
																															<input type="button" value="Assign" class="clsActionButton" onclick="javascript:doAddSelectedGroup();" /><br /><br />
																															<input type="button" value="Remove" class="clsActionButtonRed" onclick="javascript:doRemoveSelectedGroup();" /><br />
																														</td>
																														<td width="40%" align="left" valign="middle">
																															<b>Assigned Group(s):</b>
																															<div style="height:5px;"></div>
																															<div style="width:90px; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckAllAssignedGroups(document.getElementById('chkCheckOrUncheckAllAssignedGroups'));">
																																<input type="checkbox" id="chkCheckOrUncheckAllAssignedGroups" name="chkCheckOrUncheckAllAssignedGroups" onclick="javascript:doCheckORUncheckAllAssignedGroups(this);" style="cursor:pointer;" />&nbsp;Select All
																															</div>																															
																															<div style="height:5px;"></div>																															
																															<div id="divGroupsAssignedPanel" name="divGroupsAssignedPanel" style="background-color:#f4f4f4; overflow-x:hidden; overflow-y:auto; border:5px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; width:98%; height:175px;">
																																<?php
																																	$tempTQuery = "SELECT * FROM elms_assigned_groups WHERE user_id=" . $userRow["user_id"];
																																	$tResult = mysql_query($tempTQuery) or die (mysql_error());
																																	if (dbNumRows($tResult)<=0) {
																																		$strTMessage =  "No groups assigned.";
																																	}
																																?>
																																<?php if ($strTMessage=="") { ?>
																																	<?php while ($row = mysql_fetch_array($tResult)) { ?>
																																		<div id="divGroupsAssigned_<?php echo $row["group_id"]; ?>" name="divGroupsAssigned_<?php echo $row["group_id"]; ?>" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckGroupsAssigned(<?php echo $row["group_id"]; ?>);">
																																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																																				<tr>
																																					<td width="2%" align="left" valign="top">
																																						<input type="checkbox" id="lstGroupsAssigned_<?php echo $row["group_id"]; ?>" name="lstGroupsAssigned[]" value="<?php echo $row["group_id"]; ?>" onclick="javascript:doCheckORUncheckGroupsAssigned(<?php echo $row["group_id"]; ?>);" style="cursor:pointer;" />
																																					</td>
																																					<td align="left" valign="top">
																																						<?php echo $row["group_name"]; ?>
																																					</td>
																																				</tr>
																																			</table>
																																		</div>
																																		<div id="divGroupsAssigned_<?php echo $row["group_id"]; ?>" name="divGroupsAssigned_<?php echo $row["group_id"]; ?>" style="height:3px;"></div>
																																	<?php } ?>
																																<?php } else { ?>
																																	<?php echo $strTMessage; ?>
																																<?php } ?>																																
																															</div>																															
																														</td>
																													</tr>
																												</table>
																											</div>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right" valign="top">
																											Assign Course:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<div id="divAssignCourse" name="divAssignCourse">
																												<table width="100%" align="center" cellspacing="2" cellpadding="2">
																													<tr>
																														<td width="40%" align="left" valign="middle">
																															<b>Available Course(s):</b>
																															<div style="height:5px;"></div>
																															<div style="width:90px; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckAllAvailCourses(document.getElementById('chkCheckOrUncheckAllAvailCourses'));">
																																<input type="checkbox" id="chkCheckOrUncheckAllAvailCourses" name="chkCheckOrUncheckAllAvailCourses" onclick="javascript:doCheckORUncheckAllAvailCourses(this);" style="cursor:pointer;" />&nbsp;Select All
																															</div>
																															<div style="height:5px;"></div>
																															<div id="divCoursesAvailPanel" name="divCoursesAvailPanel" style="background-color:#f4f4f4; overflow-x:hidden; overflow-y:auto; border:5px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; width:100%; height:175px;">
																																<?php
																																	$strTMessage = "";
																																	$varUserType = $userRow["user_type"];
																																	$varManager = $userRow["user_head"];
																																	$varRole = $userRow["user_role"];
																																	$varMemberType = $userRow["user_mem_type"];
																																	/*if ($varUserType=="Internal") {
																																		$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='Both') AND ELMSAC.user_id=" . $varManager . " ORDER BY ELMSAC.course_name";
																																	} else {
																																		$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE (ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND ELMSCD.course_isfree='Y' AND ELMSAC.user_id=" . $varManager . " ORDER BY ELMSAC.course_name";
																																	}*/
																																	
																																	/*if ($varUserType=="All") {
																																		$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND ELMSAC.user_id=" . $varManager . " ORDER BY ELMSAC.course_name";
																																	} else {
																																	if ($varUserType=="Internal") {
																																		$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='Both') AND ELMSAC.user_id=" . $varManager . " ORDER BY ELMSAC.course_name";
																																	} else {
																																		$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND ELMSCD.course_isfree='Y' AND ELMSAC.user_id=" . $varManager . " ORDER BY ELMSAC.course_name";
																																	} }*/
																																	$tempTQuery = "SELECT ELMSCD.course_for, ELMSCD.course_isfree, ELMSCD.course_mem_type, ELMSAC.course_id, ELMSAC.course_name, ELMSAC.user_id FROM elms_course_details ELMSCD INNER JOIN elms_assigned_courses ELMSAC ON ELMSCD.course_id=ELMSAC.course_id WHERE ELMSAC.active_status='A' AND (ELMSCD.course_for='InternalOnly' OR ELMSCD.course_for='ExternalOnly' OR ELMSCD.course_for='Both') AND ELMSAC.user_id=" . $varManager . " ORDER BY ELMSAC.course_name";
																																																																		
																																	$tResult = mysql_query($tempTQuery) or die (mysql_error());
																																	$varTempAvailCount = dbNumRows($tResult);
																																	if (dbNumRows($tResult)<=0) {
																																		$strTMessage =  "No courses available.";
																																	}
																																?>																															
																																<?php if ($strTMessage=="") { ?>
																																	<?php while ($row = mysql_fetch_array($tResult)) { ?>
																																		<div id="divCoursesAvail_<?php echo $row["course_id"]; ?>" name="divCoursesAvail_<?php echo $row["course_id"]; ?>" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckCoursesAvail(<?php echo $row["course_id"]; ?>);">
																																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																																				<tr>
																																					<td width="2%" align="left" valign="top"><input type="checkbox" id="lstCoursesAvail_<?php echo $row["course_id"]; ?>" name="lstCoursesAvail[]" value="<?php echo $row["course_id"]; ?>" coursename="<?php echo $row["course_name"]; ?>" onclick="javascript:doCheckORUncheckCoursesAvail(<?php echo $row["course_id"]; ?>);" style="cursor:pointer;" /></td>
																																					<td align="left" valign="top">
																																						<?php echo $row["course_name"]; ?>
																																					</td>
																																				</tr>
																																			</table>
																																		</div>
																																		<div style="height:3px;"></div>
																																	<?php } ?>
																																<?php } else { ?>
																																	<?php echo $strTMessage; ?>
																																<?php } ?>
																															</div>
																															<b>Total Available Courses:</b> <?php echo $varTempAvailCount; ?>
																														</td>
																														<td width="10%" align="center" valign="middle">
																															<br /><br /><br />
																															<input type="button" value="Assign" class="clsActionButton" onclick="javascript:doAddSelectedCourse();" /><br /><br />
																															<input type="button" value="Remove" class="clsActionButtonRed" onclick="javascript:doRemoveSelectedCourse();" /><br />
																														</td>
																														<td width="40%" align="left" valign="middle">
																															<b>Assigned Course(s):</b>
																															<div style="height:5px;"></div>
																															<div style="width:90px; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckAllAssignedCourses(document.getElementById('chkCheckOrUncheckAllAssignedCourses'));">
																																<input type="checkbox" id="chkCheckOrUncheckAllAssignedCourses" name="chkCheckOrUncheckAllAssignedCourses" onclick="javascript:doCheckORUncheckAllAssignedCourses(this);" style="cursor:pointer;" />&nbsp;Select All
																															</div>																															
																															<div style="height:5px;"></div>																															
																															<div id="divCoursesAssignedPanel" name="divCoursesAssignedPanel" style="background-color:#f4f4f4; overflow-x:hidden; overflow-y:auto; border:5px solid <?php echo $_SESSION["Elms_GeneralBgColor"]; ?>; width:98%; height:175px;">
																																<?php
																																	$strTMessage = "";
																																	$tempTQuery = "SELECT * FROM elms_assigned_courses WHERE active_status='A' AND user_id=" . $userRow["user_id"] . " ORDER BY course_name";
																																	$tResult = mysql_query($tempTQuery) or die (mysql_error());
																																	$varTempAssignedCount = dbNumRows($tResult);
																																	if (dbNumRows($tResult)<=0) {
																																		$strTMessage =  "No courses assigned.";
																																	}
																																?>
																																<?php if ($strTMessage=="") { ?>
																																	<?php while ($row = mysql_fetch_array($tResult)) { ?>
																																		<div id="divCoursesAssigned_<?php echo $row["course_id"]; ?>" name="divCoursesAssigned_<?php echo $row["course_id"]; ?>" style="width:100%; display:block; background-color:#ffffff; text-align:left; vertical-align:middle; cursor:pointer;" onclick="javascript:doCheckORUncheckCoursesAssigned(<?php echo $row["course_id"]; ?>);">
																																			<table width="100%" cellspacing="0" cellpadding="0" border="0">
																																				<tr>
																																					<td width="2%" align="left" valign="top"><input type="checkbox" id="lstCoursesAssigned_<?php echo $row["course_id"]; ?>" name="lstCoursesAssigned[]" value="<?php echo $row["course_id"]; ?>" onclick="javascript:doCheckORUncheckCoursesAssigned(<?php echo $row["course_id"]; ?>);" style="cursor:pointer;" /></td>
																																					<td align="left" valign="top"><?php echo $row["course_name"]; ?></td>
																																				</tr>
																																			</table>
																																		</div>
																																		<div id="divCoursesAssignedDummy_<?php echo $row["course_id"]; ?>" name="divCoursesAssignedDummy_<?php echo $row["course_id"]; ?>" style="height:3px;"></div>
																																	<?php } ?>
																																<?php } else { ?>
																																	<?php echo $strTMessage; ?>
																																<?php } ?>
																															</div>
																															<b>Total Assigned Courses:</b> <div id="divTAC" name="divTAC" style="display:inline-block;"><?php echo $varTempAssignedCount; ?></div>
																														</td>
																													</tr>
																												</table>
																											</div>
																										</td>																										
																									</tr>																									
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="14%" align="right">
																											Status:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="85%" align="left">
																											<?php if ($userRow["user_status"]=="A") { ?>
																												<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusA'), document.getElementById('rdStatusA').value);"><input id="rdStatusA" name="rdStatusA" type="radio" value="A" checked onclick="javascript:doPutStatusVal(this, this.value);" />Active</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusI'), document.getElementById('rdStatusI').value);"><input id="rdStatusI" name="rdStatusI" type="radio" value="I" onclick="javascript:doPutStatusVal(this, this.value);" />Inactive</div>
																											<?php } else { ?>
																												<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusA'), document.getElementById('rdStatusA').value);"><input id="rdStatusA" name="rdStatusA" type="radio" value="A" onclick="javascript:doPutStatusVal(this, this.value);" />Active</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer" onclick="javascript:doPutStatusVal(document.getElementById('rdStatusI'), document.getElementById('rdStatusI').value);"><input id="rdStatusI" name="rdStatusI" type="radio" value="I" checked onclick="javascript:doPutStatusVal(this, this.value);" />Inactive</div>
																											<?php } ?>
																										</td>																										
																									</tr>																									
																									<tr height="10">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="100%" align="center" colspan="3">
																											<input type="button" value="Update" class="clsActionButton" onclick="javascript:doFormValidation();" />
																											<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_user_list.php');" />																										
																										</td>
																									</tr>
																									<tr height="10">
																										<td width="100%" colspan="3"></td>
																									</tr>
																								</table>
																							</td>																						
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtStatus" name="txtStatus" type="hidden" value="<?php echo $userRow["user_status"]; ?>" />
																		<input id="ddUserType" name="ddUserType" type="hidden" value="<?php echo $userRow["user_role"]; ?>" />
																		<input id="txtUserId" name="txtUserId" type="hidden" value="<?php echo $varUserId; ?>" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>