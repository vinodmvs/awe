<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varType = "";
	$varName = "";
	$varDesc = "";
	if (!isset($_POST["txtName"])) {
		header("Location:index.php");
	} else {
		$varName = $_POST["txtName"];
		$varName = trim($varName);
		$varName = str_replace("'", "\\'", $varName);
		$varType = $_POST["ddType"];
		$varDesc = $_POST["txtDesc"];
		$varDesc = str_replace("'", "\\'", $varDesc);

		$tempQuery = "SELECT * FROM elms_membership_details WHERE mem_type='" . $varType . "' AND mem_name='" . trim($varName) . "'";
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
		$tempCheck = mysql_fetch_row($tempResult);
		if ($tempCheck==null || $tempCheck=="") {
			$tempQuery = "INSERT INTO elms_membership_details(mem_type,mem_name,mem_desc) VALUES('" . $varType . "','" . trim($varName) . "','" . $varDesc .  "')";
			$tempResult = mysql_query($tempQuery);

			if ($tempResult) {
				$strMessage = "ELMS_SUCCESS";
			} else {
				$strMessage = "Unfortunately the system could not update the Membership details. Please try again!";
			}
		} else {
			$strMessage = "The entered Membership name already exists. Please enter another Membership.";
		}
		echo $strMessage;
	}
?>