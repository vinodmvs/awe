<?php
	require("elms_top_includes.php");
?>

<?php
	$varTotalCount = 0;
	$varRowSize = 10;
	$varStartLimit = 0;
	$varShowPreNav = "No";
	$varDisablePreNav = "Yes";
	$varShowNextNav = "No";
	$varDisableNextNav = "Yes";
	$varDisplayRowSizeText = "";
	$varCurPage = 1;
	$varPaginationStyle = "PRENEXTDDL"; //"PAGELINK" OR "PRENEXT" OR "PRENEXTDDL"
	
	$varGroupType = "All";
	$varSearchKeyWord = "";
	
	$strMessage = "";
	$intTempNum = 0;	
	
	if (isset($_POST["ddRowSize"])) {
		$varRowSize = $_POST["ddRowSize"];
	}
	
	if (isset($_POST["ddGroupType"])) {
		$varGroupType = $_POST["ddGroupType"];
	}
	
	if (isset($_POST["txtCurPage"])) {
		$varCurPage = $_POST["txtCurPage"];
	}	
	
	if (isset($_POST["txtSearchWord"])) {
		$varSearchKeyWord = trim($_POST["txtSearchWord"]);
		$varSearchKeyWord = str_replace("'", "\\'", $varSearchKeyWord);
	}	
	
	if ($varGroupType=="All") {
		if ($varSearchKeyWord=="") {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSGD.group_id";
		} else {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND () ORDER BY ELMSGD.group_id";
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
		}
	} else {
		if ($varSearchKeyWord=="") {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSGD.group_type='" . $varGroupType . "' ORDER BY ELMSGD.group_id";
		} else {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSGD.group_type='" . $varGroupType . "' AND () ORDER BY ELMSGD.group_id";
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
		}
	}
	$tCountResult = mysql_query($tempQuery) or die (mysql_error());	
	$varTotalCount = dbNumRows($tCountResult);

	if ($varRowSize=="0") {
		$varRowSize = $varTotalCount;
	}	

	if (isset($_POST["txtAction"])) {
		if (isset($_POST["txtStartLimit"])) {
			$varStartLimit = $_POST["txtStartLimit"];
		}
		switch ($_POST["txtAction"]) {
			case "NEXT":
				$varStartLimit = $varStartLimit + $varRowSize;
				break;
			case "LAST":
				$varTempVal = $varTotalCount/$varRowSize;
				$varTempArr = explode(".", $varTempVal);
				$varTempFinalVal = ($varTempArr[0]*$varRowSize);
				if (count($varTempArr)==2) {
					$varStartLimit = $varTempFinalVal;
				} else {
					$varStartLimit = $varTempFinalVal - $varRowSize;
				}
				break;				
			case "PREVIOUS":
				$varStartLimit = $varStartLimit - $varRowSize;
				break;
			case "FIRST":
				$varStartLimit = 0;
				break;			
				
		}
	}	
	
	if ($varGroupType=="All") {
		if ($varSearchKeyWord=="") {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " ORDER BY ELMSGD.group_id LIMIT " . $varStartLimit . ", " . $varRowSize;
		} else {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND () ORDER BY ELMSGD.group_id LIMIT " . $varStartLimit . ", " . $varRowSize;
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
		}
	} else {
		if ($varSearchKeyWord=="") {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSGD.group_type='" . $varGroupType . "' ORDER BY ELMSGD.group_id LIMIT " . $varStartLimit . ", " . $varRowSize;
		} else {
			$tempQuery = "SELECT DISTINCT ELMSAG.group_id, ELMSGD.group_name, ELMSGD.group_type, ELMSGD.group_desc, ELMSGD.group_status, ELMSAG.user_id FROM elms_assigned_groups ELMSAG INNER JOIN elms_group_details ELMSGD ON ELMSAG.group_id=ELMSGD.group_id WHERE ELMSAG.user_id=" . $_SESSION["Elms_LoggedInId"] . " AND ELMSGD.group_type='" . $varGroupType . "' AND () ORDER BY ELMSGD.group_id LIMIT " . $varStartLimit . ", " . $varRowSize;
			$varTempSQL = "";
			$varTempKwyWordArray = explode(" ", $varSearchKeyWord);
			for ($i=0; $i<count($varTempKwyWordArray); $i++) {
				if ($i==0) {
					$varTempSQL = "ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				} else {
					$varTempSQL = $varTempSQL . " OR ELMSGD.group_name LIKE '%" . $varTempKwyWordArray[$i] . "%' OR ELMSGD.group_desc LIKE '%" . $varTempKwyWordArray[$i] . "%'";
				}
			}
			$varTempSQL = "AND (" . $varTempSQL . ")";
			$tempQuery = str_replace("AND ()", $varTempSQL, $tempQuery);			
		}
	}
	$groupResult = mysql_query($tempQuery) or die (mysql_error());
	if (dbNumRows($groupResult)<=0) {
		$strMessage =  "No group(s) available.";
	} else {
		$intTempNum = dbNumRows($groupResult);
		if ($varStartLimit<=0) {
			$varShowPreNav = "No";
			$varDisablePreNav = "Yes";	
		} else {
			$varShowPreNav = "Yes";
			$varDisablePreNav = "No";	
		}		
		
		if ($intTempNum<$varRowSize || ($varStartLimit + $varRowSize)>=$varTotalCount) {
			$varShowNextNav = "No";
			$varDisableNextNav = "Yes";		
		} else {
			$varShowNextNav = "Yes";
			$varDisableNextNav = "No";		
		}		
		$strMessage = "<b> " . $intTempNum . "</b> group(s) available.";
		$varDisplayRowSizeText = "Displaying " . ($varStartLimit + 1) . " - " . ($varStartLimit + $intTempNum) . " of " . $varTotalCount . " (Groups)";
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
	</head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">&nbsp;</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">&nbsp;</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<form id="frmMain" name="frmMain" method="post" action="elms_group_list.php">
																	<td width="100%">
																		<table width="100%" cellspacing="0" cellpadding="0" border="0">
																			<tr>
																				<td width="50%">
																					<div style="display:inline-block;">
																						<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_group_new.php';">Add New Group</div>
																						<?php
																							if ($intTempNum>0) {
																						?>
																								<!--
																								<div class="clsRoleSubLink" onclick="javascript:document.location.href='elms_group_assign.php';">Assign Group</div>
																								-->
																						<?php
																							}
																						?>
																					</div>
																				</td>
																				<td width="50%" align="right">
																					<div style="width:100%; display:inline-block;">
																						Show Groups:&nbsp;
																						<select id="ddRowSize" name="ddRowSize" class="clsTextField" style="width:15%;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<?php if ($varRowSize==10) { ?>
																								<option selected value="10">10</option>
																							<?php } else { ?>
																								<option value="10">10</option>
																							<?php } ?>

																							<?php if ($varRowSize==25) { ?>
																								<option selected value="25">25</option>
																							<?php } else { ?>
																								<option value="25">25</option>
																							<?php } ?>

																							<?php if ($varRowSize==50) { ?>
																								<option selected value="50">50</option>
																							<?php } else { ?>
																								<option value="50">50</option>
																							<?php } ?>

																							<?php if ($varRowSize==100) { ?>
																								<option selected value="100">100</option>
																							<?php } else { ?>
																								<option value="100">100</option>
																							<?php } ?>

																							<?php if ($varRowSize==$varTotalCount) { ?>
																								<option selected value="0">All</option>
																							<?php } else { ?>
																								<option value="0">All</option>
																							<?php } ?>																							
																						</select>
																					</div>
																				</td>
																			</tr>
																			<tr height="25">
																				<td width="100%" colspan="2">
																				</td>
																			</tr>																		
																			<tr>
																				<td width="100%" align="left" colspan="2">
																					<fieldset style="padding:5px 5px 5px 5px; border:1px solid #cccccc">
																						<legend style="position: relative; padding:5px 5px 5px 5px; font-size:12px; top: 0px; left: 0px; color:#000000; border:1px solid #000000;"><b>Filter By</b></legend>																				
																						Group Type:&nbsp;
																						<select id="ddGroupType" name="ddGroupType" size="1" class="clsTextField" style="width:200px;" onchange="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.txtAction.value=''; document.frmMain.submit();">
																							<option selected value="All">All Groups</option>
																							<?php if ($varGroupType=="Internal") { ?>
																								<option selected value="Internal">Internal</option>
																							<?php } else { ?>
																								<option value="Internal">Internal</option>
																							<?php } ?>
																							
																							<?php if ($varGroupType=="External") { ?>
																								<option selected value="External">External</option>
																							<?php } else { ?>
																								<option value="External">External</option>
																							<?php } ?>																							
																						</select>
																					</fieldset>
																				</td>
																			</tr>																			
																			<tr height="25">
																				<td width="100%" colspan="2">
																				</td>
																			</tr>																			
																			<tr>
																				<td width="100%" align="right" colspan="2">
																					Search by Name or Description:&nbsp;<input type="text" id="txtSearchWord" name="txtSearchWord" class="clsTextField" style="width:400px;" />
																					<div class="clsActionButton" onclick="javascript:doShowProccessIcon(); document.frmMain.txtStartLimit.value='0'; document.frmMain.submit();">&nbsp;Go&nbsp;</div>																				
																				</td>
																			</tr>																			
																			<?php
																				if ($intTempNum>0) { 
																					if ($varPaginationStyle=="PAGELINK") {
																						doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "TOP");
																					} else {
																					if ($varPaginationStyle=="PRENEXT") {
																						doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} else {
																						doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "TOP");
																					} }
																				}
																			?>																		
																		</table>
																	</td>
																	<input type="hidden" id="txtStartLimit" name="txtStartLimit" value="<?php echo $varStartLimit; ?>" />
																	<input type="hidden" id="txtAction" name="txtAction" value="" />
																	<input type="hidden" id="txtCurPage" name="txtCurPage" value="1" />
																</form>
															</tr>
															<tr height="10">
																<td>
																</td>
															</tr>
															<?php if ($intTempNum<=0) { ?>
																<tr height="25">
																	<td width="100%" align="center" class="clsResErrorMsgText">
																		<?php echo $strMessage; ?>
																	</td>
																</tr>
															<?php } else { ?>															
																<tr>
																	<td width="100%" align="left" valign="top">
																		<div class="clsSingleBorder">
																			<table width="100%" cellspacing="1" cellpadding="2">
																				<tr class="clsTableRowHeadingText">
																					<td width="2%">
																						#
																					</td>
																					<td width="40%">
																						Group Name
																					</td>
																					<td width="14%">
																						Group Type
																					</td>																				
																					<td width="28%">
																						Description
																					</td>
																					<td width="10%">
																						Enrolled Users
																					</td>
																					<td width="6%" colspan="2">
																						Action
																					</td>
																				</tr>
																				<?php
																					$intTempInc = 0;
																					$strColorFilled = "No";
																					while ($row = mysql_fetch_array($groupResult)) {
																						$intTempInc++;
																				?>
																				<?php
																					if ($strColorFilled=="No") {
																						$strColorFilled = "Yes";

																				?>
																					<tr class="clsAlternateFColor">
																				<?php
																					} else {
																						$strColorFilled = "No";

																				?>
																					<tr class="clsAlternateSColor">
																				<?php
																					}
																				?>
																						<td width="2%">
																							<img src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/groups_icon_small.png" alt="" title="" />
																						</td>
																						<td width="40%">
																							<?php echo $row["group_name"]; ?>
																						</td>
																						<td width="14%">
																							<?php echo $row["group_type"]; ?>
																						</td>																					
																						<td width="28%">
																							<?php
																								/*$tQuery = "SELECT elms_assigned_groups.user_id, elms_user_details.user_fname FROM elms_assigned_groups INNER JOIN elms_user_details ON elms_assigned_groups.user_id=elms_user_details.user_id WHERE user_role='Manager' AND elms_assigned_groups.group_id=" . $row["group_id"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								$tRow = mysql_fetch_row($tResult);
																								$strTempDisp = $tRow[1];
																								if ($strTempDisp!="") {
																									echo $strTempDisp;
																								} else {
																									echo "Admin";
																								}*/
																								echo $row["group_desc"];
																							?>
																						</td>
																						<td width="10%">
																							<?php
																								$tQuery = "SELECT elms_assigned_groups.user_id, elms_user_details.user_fname FROM elms_assigned_groups INNER JOIN elms_user_details ON elms_assigned_groups.user_id=elms_user_details.user_id WHERE user_role='User' AND elms_assigned_groups.group_id=" . $row["group_id"];
																								$tResult = mysql_query($tQuery) or die (mysql_error());
																								if (dbNumRows($tResult)>0) {
																									echo dbNumRows($tResult);
																								} else {
																									echo "-";
																								}
																							?>
																						</td>
																						<td width="3%" align="center" valign="middle">
																							<form id="<?php echo "frmEdit_" . $row["group_id"] ?>" name="<?php echo "frmEdit_" . $row["group_id"] ?>" method="post" action="elms_group_edit.php">
																								<a href="javascript:document.<?php echo "frmEdit_" . $row["group_id"] ?>.submit();"><div><img src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/edit_icon.jpg" alt="Edit" title="Edit" /></div></a>
																								<input type="hidden" id="txtGroupId" name="txtGroupId" value="<?php echo $row["group_id"]; ?>">
																							</form>
																							<?php

																							?>
																						</td>
																						<td width="3%" align="center" valign="middle">
																							<a href="javascript:doShowDeletePanel('<?php echo $row["group_id"]; ?>', 'Group', '<?php echo $row["group_name"]; ?>.', 'elms_group_delete_update.php', 'elms_group_list.php');"><div><img src="css/theme/<?php echo $_SESSION["Elms_ThemeColor"]; ?>/images/delete_icon.jpg" alt="Delete" title="Delete" /></div></a>
																						</td>
																					</tr>
																				<?php } ?>
																			</table>
																		</div>
																	</td>
																</tr>
																<?php
																	if ($varPaginationStyle=="PAGELINK") {
																		doRenderListPagination($varTotalCount, $varRowSize, $varCurPage, $varDisplayRowSizeText, "BOTTOM");
																	} else {
																	if ($varPaginationStyle=="PRENEXT") {
																		doRenderListPreNextNavigation($varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																	} else {
																		doRenderListPreNextNavigationWithDDL($varTotalCount, $varRowSize, $varCurPage, $varDisablePreNav, $varDisableNextNav, $varDisplayRowSizeText, "BOTTOM");
																	} }
																?>																
															<?php } ?>
														</table>
													</td>
													<td width="1%">&nbsp;</td>
												</tr>
											</table>
										</td>
										<td width="1%">&nbsp;</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>