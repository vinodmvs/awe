<?php
	require("elms_config.php");
	require("elms_db.php");
?>

<?php
	$varID = 0;
	$varManager = "";
	$varGroup = "";
	$varResult = "";
	$varArrName = "";
	$varArrResult = "";
	$varCourseName = "";
	$varHeadingText = "";

	if (!isset($_POST["Email"])) {
		header("Location:login.php");
	} else {
		$varEmail = $_POST["Email"];
		$varID = $_POST["Course"];
		$varManager = $_POST["Manager"];
		$varGroup = $_POST["Group"];
		$varResult = $_POST["Result"];

		$tQuery = "SELECT course_name FROM elms_course_details WHERE course_id=" . $varID;
		$tResult = mysql_query($tQuery) or die (mysql_error());
		$tRow = mysql_fetch_array($tResult);
		$varCourseName = $tRow["course_name"];
		$varBgColor = "#49c0f0";
		$varFRowColor = "#c0e7f9";
		$varSRowColor = "#c0e7f9";

		switch ($_SESSION["Elms_ThemeColor"]) {
			case "blue":
				$varBgColor = "#49c0f0";
				$varFRowColor = "#c0e7f9";
				$varSRowColor = "#f2f2f2";
				break;
			case "brown":
				$varBgColor = "#c37d03";
				$varFRowColor = "#fee5b8";
				$varSRowColor = "#f2f2f2";
				break;
			case "green":
				$varBgColor = "#38b003";
				$varFRowColor = "#e1fed4";
				$varSRowColor = "#f2f2f2";
				break;
			case "grey":
				$varBgColor = "#626262";
				$varFRowColor = "#edecec";
				$varSRowColor = "#f2f2f2";
				break;
			case "lgreen":
				$varBgColor = "#adc622";
				$varFRowColor = "#fbffe4";
				$varSRowColor = "#f2f2f2";
				break;
			case "orange":
				$varBgColor = "#f98c2d";
				$varFRowColor = "#ffe1d1";
				$varSRowColor = "#f2f2f2";
				break;
			case "violet":
				$varBgColor = "#7a3ba6";
				$varFRowColor = "#f1dcff";
				$varSRowColor = "#f2f2f2";
				break;
		}

		$varHeadingText =  "Result for the Course '" . $varCourseName . "'";

		if ($varManager=="" && $varGroup=="" && $varResult=="") {
			$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
				$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
				while ($tRowSub = mysql_fetch_array($tResultSub)) {
					$varTempUserName = "";
					$varTempResult = "";

					$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempUserName = $tRow["user_fname"];

					$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempResult = $tRow["status"];

					if ($varTempUserName!="" && $varTempResult=="") {
						$varTempResult = "NOT ATTEMPTED";
					}

					if ($varTempUserName!="" && $varTempResult!="") {
						if ($varArrName=="") {
							$varArrName = $varTempUserName;
						} else {
							$varArrName = $varArrName . "~" . $varTempUserName;
						}
						if ($varArrResult=="") {
							$varArrResult = $varTempResult;
						} else {
							$varArrResult = $varArrResult . "~" . $varTempResult;
						}
					}
				}
			}
		} else {
		if ($varManager!="" && $varGroup=="" && $varResult=="") {
			$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
				$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
				while ($tRowSub = mysql_fetch_array($tResultSub)) {
					$varTempUserName = "";
					$varTempResult = "";

					$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempUserName = $tRow["user_fname"];

					$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempResult = $tRow["status"];

					if ($varTempUserName!="" && $varTempResult=="") {
						$varTempResult = "NOT ATTEMPTED";
					}

					if ($varTempUserName!="" && $varTempResult!="") {
						if ($varArrName=="") {
							$varArrName = $varTempUserName;
						} else {
							$varArrName = $varArrName . "~" . $varTempUserName;
						}
						if ($varArrResult=="") {
							$varArrResult = $varTempResult;
						} else {
							$varArrResult = $varArrResult . "~" . $varTempResult;
						}
					}
				}
			}
		} else {
		if ($varManager!="" && $varGroup!="" && $varResult=="") {
			$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
				$tempResult = mysql_query($tempQuery) or die (mysql_error());
				while ($tempRow = mysql_fetch_array($tempResult)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];

						if ($varTempUserName!="" && $varTempResult=="") {
							$varTempResult = "NOT ATTEMPTED";
						}

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			}
		} else {
		if ($varManager!="" && $varGroup!="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];


							if ($varTempUserName!="" && $varTempResult=="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = "NOT ATTEMPTED";
								} else {
									$varArrResult = $varArrResult . "~" . "NOT ATTEMPTED";
								}
							}
						}
					}
				}
			} } }
		} else {
		if ($varManager=="" && $varGroup!="" && $varResult=="") {
			$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
				$tempResult = mysql_query($tempQuery) or die (mysql_error());
				while ($tempRow = mysql_fetch_array($tempResult)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];

						if ($varTempUserName!="" && $varTempResult=="") {
							$varTempResult = "NOT ATTEMPTED";
						}

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			}
		} else {
		if ($varManager=="" && $varGroup=="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];

						if ($varTempUserName!="" && $varTempResult=="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = "NOT ATTEMPTED";
							} else {
								$varArrResult = $varArrResult . "~" . "NOT ATTEMPTED";
							}
						}
					}
				}
			} } }
		} else {
		if ($varManager=="" && $varGroup!="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User'";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];


							if ($varTempUserName!="" && $varTempResult=="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = "NOT ATTEMPTED";
								} else {
									$varArrResult = $varArrResult . "~" . "NOT ATTEMPTED";
								}
							}
						}
					}
				}
			} } }
		} else {
		if ($varManager!="" && $varGroup=="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];


						if ($varTempUserName!="" && $varTempResult=="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = "NOT ATTEMPTED";
							} else {
								$varArrResult = $varArrResult . "~" . "NOT ATTEMPTED";
							}
						}
					}
				}
			} } }
		} } } } } } } }

		$arrTempName = explode("~", $varArrName);
		$arrTempResult = explode("~", $varArrResult);

		$strColorFilled = "No";
		$strResultInnerHTML = '<table cellspacing="0" cellpadding="0" border="0"><tr><td width="100%" align="center" valign="middle"><table cellspacing="1" cellpadding="2" align="center"><tr style="background-color:' . $varBgColor . '; color:#ffffff; font-size:14; font-weight:bold;"><td width="3%" align="center">#</td><td width="49%" align="left">Learner Name</td><td width="48%" align="left">Result</td></tr>';
		for ($i=0; $i<count($arrTempName); $i++) {
			if ($strColorFilled=="No") {
				$strColorFilled = "Yes";
				$strResultInnerHTML = $strResultInnerHTML . '<tr style="background-color:' . $varFRowColor . '; color:#000000; font-size:12; font-weight:normal;"><td width="3%" align="center">' . ($i+1) . '</td><td align="left" valign="top" width="49%">' . $arrTempName[$i] . '</td><td align="left" valign="top" width="48%">' . $arrTempResult[$i] . '</td></tr>';
			} else {
				$strColorFilled = "No";
				$strResultInnerHTML = $strResultInnerHTML . '<tr style="background-color:' . $varSRowColor . '; color:#000000; font-size:12; font-weight:normal;"><td width="3%" align="center">' . ($i+1) . '</td><td align="left" valign="top" width="49%">' . $arrTempName[$i] . '</td><td align="left" valign="top" width="48%">' . $arrTempResult[$i] . '</td></tr>';
			}
		}
		$strResultInnerHTML = $strResultInnerHTML . '</table></td></tr></table>';


		$to = $varEmail;
		$from = $_SESSION["Elms_LoggedInEmail"];
		$subject = "MVS LMS Course Result";

		$message = <<<EOF
<html>
	<body bgcolor="#DCEEFC">
		<b>Hello!</b><br /><br />
		Find the below Course Result<br /><br />
		$strResultInnerHTML<br /><br />
		Regards,<br />
		<a href="mailto:$from">$from</a>
	</body>
</html>
EOF;
		$headers  = "From: $from\r\n";
		$headers .= "Content-type: text/html\r\n";

		if (mail($to, $subject, $message, $headers)) {
			$strMessage = "Email has been sent successfully.";
		} else {
			$strMessage = "<b>Error: </b>Error occured while sending E-mail to <b>" . $to . "</b>";
		}

		echo $strMessage;
	}
?>