<?php
	require("elms_top_includes.php");
?>

<?php
	$varUserId = $_SESSION["Elms_LoggedInId"];
	$tempQuery = "SELECT * FROM elms_user_details WHERE user_id=" . $varUserId;
	$userResult = mysql_query($tempQuery) or die (mysql_error());
	$userRow = mysql_fetch_array($userResult);
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			var strValidFileExtensions = [".jpg", ".jpeg", ".png", ".gif"];
			
			function doInitialize() {
				$("#txtDOB").datepicker({dateFormat: 'dd-mm-yy', changeMonth: true,changeYear: true, yearRange: "-75:+0"});
				document.frmMain.txtFName.focus();
			}

			function doFormValidation() {
				if (document.frmMain.txtFName.value=="") {
					doShowAlertPanel("First Name cannot be blank. Please enter the First Name.", document.frmMain.txtFName);
				} else {
				if (document.frmMain.txtDOB.value=="") {
					doShowAlertPanel("Date of Birth cannot be blank. Please select the Date of Birth.", document.frmMain.txtDOB);
				} else {
				if (document.frmMain.txtLoginId.value=="") {
					doShowAlertPanel("Login Id cannot be blank. Please enter the Login Id.", document.frmMain.txtLoginId);
				} else {
				if (document.frmMain.txtPass.value=="") {
					doShowAlertPanel("Password cannot be blank. Please enter the Password.", document.frmMain.txtPass);
				} else {
				if (document.frmMain.txtProfilePic.value!="" && !doValidFileExtension(document.frmMain.txtProfilePic.value)) {
					doShowAlertPanel("Invalid picture file format! Please choose the valid picture file.", document.frmMain.txtProfilePic);
				} else {
					doShowProccessIcon();
					document.frmMain.submit();
				} } } } }
			}
			
			function doSetThemeColor(strTemp) {
				document.getElementById("txtTheme").value = strTemp;
				$("#blue").css('border', "0px solid #000000")
				$("#green").css('border', "0px solid #000000")
				$("#lgreen").css('border', "0px solid #000000")
				$("#grey").css('border', "0px solid #000000")
				$("#violet").css('border', "0px solid #000000")
				$("#orange").css('border', "0px solid #000000")
				$("#brown").css('border', "0px solid #000000")
				$("#" + strTemp).css('border', "3px solid #ffffff")
			}			
			
			function doValidFileExtension(strTemp){
				var varRetVal = false;
				var sCurExtension = "";
				for (var i=0; i<strValidFileExtensions.length; i++) {
					sCurExtension = strValidFileExtensions[i];
					if (strTemp.substr(strTemp.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
						varRetVal = true;
						break;
					}
				}
				return varRetVal;
			}			
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" enctype="multipart/form-data" action="elms_profile_update.php">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="2">Profile</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="2">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<?php
																							$varDispError = "";
																							if (isset($_SESSION["Elms_ResMsg"])) {
																								switch ($_SESSION["Elms_ResMsg"]) {
																									case "ELMS_SUCCESS":
																										$varDispError = 'Profile details has been updated successfully.';
																										break;																								
																									case "ELMS_UPLOADERROR":
																										$varDispError = 'Unfortunately the system could not upload the Image file. Please try again!';
																										break;
																									case "ELMS_TOOLARGEERROR":
																										$varDispError = 'The upload Image file size is too large. Please try with the size of less than or equal to 2 MB.';
																										break;
																									case "ELMS_DBERROR":
																										$varDispError = 'Unfortunately the system could not update the Profile details. Please try again!';
																										break;
																									case "ELMS_EXISTS":
																										$varDispError = 'The entered Login Id already exists. Please enter another Login Id.';
																										break;																										
																								}
																								$_SESSION["Elms_ResMsg"] = "";
																							}
																						?>
																						<?php if ($varDispError!="") { ?>
																							<tr height="15">
																								<td width="100%" align="center" valign="middle">
																								</td>
																							</tr>																			
																							<tr>
																								<td width="100%" align="center" valign="middle" class="clsResErrorMsgText">
																									<font color="green"><?php echo $varDispError; ?></font>
																								</td>
																							</tr>
																							<tr height="15">
																								<td width="100%" align="center" valign="middle">
																								</td>
																							</tr>
																						<?php } ?>
																						<tr>
																							<td width="100%" align="left" valign="top">
																								<table width="100%" align="center" cellspacing="2" cellpadding="2">
																									<?php if (strtoupper($_SESSION["Elms_LoggedInUserType"])=="ADMIN") { ?>
																										<tr>
																											<td width="24%" align="right">
																											</td>
																											<td width="1%">
																											</td>																										
																											<td width="75%" align="left">
																												<input type="hidden" id="ddUserIEType" name="ddUserIEType" value="<?php echo $userRow["user_type"]; ?>" />
																											</td>																										
																										</tr>
																									<?php } else { ?>
																										<tr>
																											<td width="24%" align="right">
																												User Type:
																											</td>
																											<td width="1%">
																											</td>																										
																											<td width="75%" align="left">
																												<?php echo $userRow["user_type"]; ?>
																												<input type="hidden" id="ddUserIEType" name="ddUserIEType" value="<?php echo $userRow["user_type"]; ?>" />
																											</td>																										
																										</tr>
																									<?php } ?>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> First Name:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtFName" name="txtFName" class="clsTextField" value="<?php echo $userRow["user_fname"]; ?>" style="width:40%" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>																									
																									<tr>
																										<td width="24%" align="right">
																											Last Name:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtLName" name="txtLName" class="clsTextField" value="<?php echo $userRow["user_lname"]; ?>" style="width:40%" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											<font color="red">*</font> Date of Birth:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtDOB" name="txtDOB" class="clsTextField" value="<?php echo $userRow["user_dob"]; ?>" style="width:15%" />
																											<div style="display:inline-block;vertical-align:middle;" onclick="javascript:$('#txtDOB').datepicker('show');"><img width="25" height="25" src="images/calendar_icon.png" style="cursor:pointer" /></div>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											E-mail:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<?php echo $userRow["user_email"]; ?>
																											<input type="hidden" id="txtEmail" name="txtEmail" class="clsTextField" value="<?php echo $userRow["user_email"]; ?>" style="width:40%" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											Phone:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtPhone" name="txtPhone" class="clsTextField" value="<?php echo $userRow["user_phone"]; ?>" style="width:25%" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											User Role:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<?php
																												$varTempDisplay = "Administrator";
																												if ($userRow["user_role"]=="Admin") {
																													$varTempDisplay = "Administrator";
																												} else {																												
																												if ($userRow["user_role"]=="Manager") {
																													$varTempDisplay = "Manager";
																												} else {
																													$varTempDisplay = "Learner";
																												} }
																												echo $varTempDisplay;
																											?>
																											<input type="hidden" id="ddUserType" name="ddUserType" class="clsTextField" value="<?php echo $userRow["user_role"]; ?>" style="width:15%" />
																											<span id="spanReportsTo" name="spanReportsTo" style="width:80%; display:inline-block;">
																												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																												<?php if ($userRow["user_role"]!="Admin") { ?>
																													<b>Reports To:</b>&nbsp;
																												<?php } ?>
																												<?php
																													$tempTQuery = "SELECT user_id, user_fname FROM elms_user_details WHERE user_id=" . $userRow["user_head"];
																													$managerResult = mysql_query($tempTQuery) or die (mysql_error());
																													$tempRow = mysql_fetch_array($managerResult);
																													if ($userRow["user_role"]=="Admin") {
																													} else {
																														echo $tempRow["user_fname"];
																													}
																												?>
																												<input type="hidden" id="ddManager" name="ddManager" class="clsTextField" value="<?php echo $tempRow["user_id"]; ?>" style="width:15%" />																												
																											</span>
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											Login Id:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<?php echo $userRow["user_login"]; ?>
																											<input type="hidden" id="txtLoginId" name="txtLoginId" class="clsTextField" value="<?php echo $userRow["user_login"]; ?>" style="width:40%" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											Password:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input type="text" id="txtPass" name="txtPass" class="clsTextField" value="<?php echo $userRow["user_pass"]; ?>" style="width:40%" />
																										</td>																										
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right" valign="top">
																											Profile Picture:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<font color="red"><b>Note:</b></font> If you wish to add the your profile image, browse the file. The image file should be (jpg, jpeg, png or gif) with DIM of 640x480 or less and file size should be less then or eaqual to 2 MB.
																										</td>																										
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<input id="txtProfilePic" name="txtProfilePic" class="clsTextField" type="file"  />
																										</td>																										
																									</tr>																									
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="24%" align="right">
																											Theme Color:
																										</td>
																										<td width="1%">
																										</td>																										
																										<td width="75%" align="left">
																											<table width="100%">
																												<tr>
																													<td width="30%" align="left" valign="middle">
																														<table width="98%" height="50" cellspacing="3" cellpadding="3">
																															<tr>
																																<td id="blue" name="blue" bgcolor="#49c0f0" style="cursor:pointer;" onclick="javascript:doSetThemeColor(this.id)"></td>
																																<td id="green" name="green" bgcolor="#38b003" style="cursor:pointer;" onclick="javascript:doSetThemeColor(this.id)"></td>
																																<td id="lgreen" name="lgreen" bgcolor="#adc622" style="cursor:pointer;" onclick="javascript:doSetThemeColor(this.id)"></td>
																																<td id="violet" name="violet" bgcolor="#7a3ba6" style="cursor:pointer;" onclick="javascript:doSetThemeColor(this.id)"></td>
																																<td id="grey" name="grey" bgcolor="#626262" style="cursor:pointer;" onclick="javascript:doSetThemeColor(this.id)"></td>
																																<td id="orange" name="orange" bgcolor="#f98c2d" style="cursor:pointer;" onclick="javascript:doSetThemeColor(this.id)"></td>
																																<td id="brown" name="brown" bgcolor="#c37d03" style="cursor:pointer;" onclick="javascript:doSetThemeColor(this.id)"></td>
																															</tr>
																														</table>
																													</td>
																													<td>
																													</td>
																												</tr>
																											</table>
																										</td>																										
																									</tr>																									
																									<tr height="10">
																										<td width="100%" colspan="3"></td>
																									</tr>
																									<tr>
																										<td width="100%" align="center" colspan="3">
																											<input type="button" value="&nbsp;Update&nbsp;" class="clsActionButton" onclick="javascript:doFormValidation();" />
																										</td>
																									</tr>
																									<tr height="5">
																										<td width="100%" colspan="3"></td>
																									</tr>																									
																								</table>
																							</td>																						
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtUserId" name="txtUserId" type="hidden" value="<?php echo $varUserId; ?>" />
																		<input id="txtTheme" name="txtTheme" type="hidden" value="<?php echo $userRow["user_theme"]; ?>" />
																		<input id="txtProfileOldPic" name="txtProfileOldPic" type="hidden" value="<?php echo $userRow["user_profile_pic"]; ?>" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>