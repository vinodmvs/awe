<?php
	require("elms_config.php");
	require("elms_db.php");
	
	$_SESSION["Elms_LoggedInId"] = "";
	$_SESSION["Elms_LoggedInEmail"] = "";
	$_SESSION["Elms_LoggedInUserName"] = "";
	$_SESSION["Elms_LoggedInUserType"] = "";
	$_SESSION["Elms_LoggedInIEUserType"] = "";
	$_SESSION["Elms_LoggedInTrackId"] = "";
	$_SESSION["Elms_LoggedInMUPer"] = "";
	$_SESSION["Elms_LoggedInMGPer"] = "";
	$_SESSION["Elms_LoggedInProfilePic"] = "";
	$_SESSION["Elms_ReplyEmail"] = "";
	$_SESSION["Elms_SiteURL"] = "";
	$_SESSION["Elms_ResMsg"] = "";
	$_SESSION["Elms_SuccessMsg"] = "";
	$_SESSION["Elms_ErrorMsg"] = "";
	$_SESSION["Elms_TrialMsg"] = "";
	$_SESSION["Elms_ThemeColor"] = "blue";
	$_SESSION["Elms_GeneralBgColor"] = "#49c0f0";
	$_SESSION["Elms_AlternateFColor"] = "#c0e7f9";
	$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";
	
	$_SESSION["Elms_SCORMCourseStatus"] = "";
	$_SESSION["Elms_SCORMRawScore"] = 0;
	
	$_SESSION["Elms_CourseName"] = "";
	$_SESSION["Elms_CourseCatName"] = "";
	
	$_SESSION["Elms_CourseEditId"] = "";	
?>

<?php

	$dbHost = 'localhost';
	$dbUser = 'root';
	$dbPass = '';
	$dbName = 'mvslms';
	
	/*
	$dbHost = 'localhost';
	$dbUser = 'mvslmsdbadmin';
	$dbPass = 'MvsLMSDBAdminGoodLuck123';
	$dbName = 'mvslms';
	*/
	
	$strMessage = "";
	$_SESSION["Elms_TrialMsg"] = "";
	
	/*
	$varTrailCount = 14;

	$dbConn = mysql_connect($dbHost, $dbUser, $dbPass);

	if (!$dbConn) {
		$strMessage = "<b>Server Message </b>MYSQL Server Connection Server Message Could not connect to MYSQL SERVER " . mysql_error();
	} else {
		$db = mysql_select_db($dbName);
		if (!$db) {
			$strMessage = "<b>Server Message </b>MYSQL Server Database Server Message Could not select the MYSQL SERVER Database " . mysql_error();
		} else {
			$strCurBaseDirName = dirname(__FILE__);
			$varSPL = explode(DIRECTORY_SEPARATOR, $strCurBaseDirName);
			$strCurDirName = $varSPL[count($varSPL)-1];
			$strCurDirName = "glassacademy";
			$varCurDate = date('Y-m-d');
			$tempQuery = "SELECT * FROM elms_customer_details WHERE customer_lmsdb_name='" . $strCurDirName  . "'";
			$tempResult = mysql_query($tempQuery) or die (mysql_error());
			$tResult = mysql_query($tempQuery) or die (mysql_error());
			$intTempNum = mysql_num_rows($tResult);
			if ($intTempNum>0) {
				while ($tempRow = mysql_fetch_array($tempResult)) {
					if ($tempRow["customer_ispurchased"]=="Y") {
						$strMessage = "ELMS_SUCCESS";
					} else {
					if ($tempRow["customer_isverified"]=="Y" && $varCurDate<=date($tempRow["customer_trial_expdate"])) {
						$varTrailCount = doGetDateTimeDiff($varCurDate, date($tempRow["customer_trial_expdate"]), "D");
						if ($varTrailCount>=0) {
							$strMessage = "ELMS_SUCCESS";
							$_SESSION["Elms_TrialMsg"] = 'Your trial period will expire in <b>' . $varTrailCount . ' day(s)</b>. Please click <a href="http://www.mvslms.com/pricing-plans/">here</a> to purchase.';
						} else {
							$strMessage = 'Your trial period has expired. Please click <a href="http://www.mvslms.com/pricing-plans/">here</a> to purchase.';
						}
					} else {
						$strMessage = "Access denied. Please contact MVS LMS server Administrator.";
					} }
				}
			} else {
				$strMessage = "Access denied. Please contact MVS LMS server Administrator.";
			}
		}
	}
	if ($strMessage!="ELMS_SUCCESS") {
		header("Location:http://www.mvslms.com/elms_customer_show_account_expired_message.php");
	}
	*/
	$strCurDirName = "chironmeditour";
	$db = mysql_select_db($strCurDirName);
?>

<!doctype html>
<html>
	<head>
		<style>
			.clsBgPattern {
				background-image: -ms-linear-gradient(bottom, #ffffff 0%, #50adef 95%, #367fc2 100%);
				background-image: -moz-linear-gradient(bottom, #ffffff 0%, #50adef 95%, #367fc2 100%);
				background-image: -o-linear-gradient(bottom, #ffffff 0%, #50adef 95%, #367fc2 100%);
				background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #ffffff), color-stop(0.9, #50adef), color-stop(1, #367fc2));
				background-image: -webkit-linear-gradient(bottom, #ffffff 0%, #50adef 95%, #367fc2 100%); 
				background-image: linear-gradient(to top, #ffffff 0%, #50adef 95%, #367fc2 100%);
				filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#50adef', endColorstr='#ffffff',GradientType=0);
			}
			.clsBgImageShadow {
				cursor: default;
				-webkit-box-shadow: 0 0 20px rgba(0,0,0, .65);
				-moz-box-shadow: 0 0 20px rgba(0,0,0, .65);
				box-shadow: 0 0 20px rgba(0,0,0, .65);
				/*filter: progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=0,strength=10),
				progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=45,strength=10),
				progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=90,strength=10),
				progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=135,strength=10),
				progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=180,strength=10),
				progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=225,strength=10),
				progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=270,strength=10),
				progid:DXImageTransform.Microsoft.Shadow(color=#000000,direction=315,strength=10);*/
			}
			.clsLoginPanelHeading {
				font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
				font-size: 20px;
				color: #ffffff;
				font-weight: bold;
				background: #00a4f0;
			}
			.clsLoginPanelBody {
				font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
				font-size: 16px;
				color: #ffffff;
				font-weight: normal;
			}			
			.clsMentorePanelHeading {
				font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
				font-size: 20px;
				color: #ffffff;
				font-weight: bold;
			}
			.clsMentorePanelBody {
				font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
				font-size: 15px;
				color: #000000;
				font-weight: normal;
			}
			.clsMentoreHyperLink {
				font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
				font-size: 15px;
				color: green;
				font-weight: normal;
				text-decoration: none;
			}
			a.clsMentoreHyperLink {
				font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
				font-size: 15px;
				color: green;
				font-weight: normal;
				text-decoration: none;
			}
			a.clsMentoreHyperLink:hover {
				font-family: Open Sans, arial, verdana, helvetica, sans-serif, tahoma;
				font-size: 15px;
				color: green;
				font-weight: normal;
				text-decoration: underline;
			}
			.clsDivCaptcha {
				background-image: url('images/captcha_image.png');
				width: 350px; /* for IE 6 */
				height: 40px;
				text-align: center;
				display: block;
			}
			.clsSpanCaptcha {
				font-size: xx-large;
				font-family: Arial;
				font-style: italic;
				font-weight: bold;
				font-size: 20px;
				color: #000000;
				letter-spacing: 5px;
				height: 100px;
				opacity: 0.4;
				filter: alpha(opacity=40);
				vertical-align: middle;
				display: inline-block;
				text-align: center;
			}			
		</style>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doInitialize() {
				doDrawCaptcha();
				document.frmMain.txtEmail.focus();
			}
			
			function doDrawCaptcha() {
				var strAlphaNumericSet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
				//var strAlphaNumericSet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZ";
				var intCaptchaLen = Math.floor((Math.random() * 5) + 2);
				var strCaptcha = '';
				for (i=0; i<intCaptchaLen; i++) {
					var intRndNum = Math.floor(Math.random() * strAlphaNumericSet.length);
					strCaptcha += strAlphaNumericSet.substring(intRndNum, intRndNum + 1);
				}
				$('#spanCaptcha').html(strCaptcha);
			}			

			function doFormValidation() {
				if (document.frmMain.txtEmail.value=="") {
					doShowAlertPanel("User name cannot be blank. Please enter the User name.", document.frmMain.txtEmail);
				} else {
				if (!validEmail(document.frmMain.txtEmail.value)) {
					doShowAlertPanel("Invalid email address format ! \nEvery email address must include one @ sign followed by a domain name. \nEg: User@Server.com.", document.frmMain.txtEmail);
				} else {
				if (document.frmMain.txtPass.value=="") {
					doShowAlertPanel("Password cannot be blank. Please enter the Password.", document.frmMain.txtPass);
				} else {
					var strPOSTURL = "elms_login_check.php";
					var objFormData = $( "#frmMain" ).serialize();					
					doPOSTNormalFormData(strPOSTURL, objFormData);
				} } }
			}
			function doSendNewRegData() {
				if (document.frmNewReg.txtNewRegFName.value=="") {
					doShowAlertPanel("First Name cannot be blank. Please enter the First Name.", document.frmNewReg.txtNewRegFName);
				} else {
				if (document.frmNewReg.txtNewRegEmail.value=="") {
					doShowAlertPanel("E-mail Id cannot be blank. Please enter the E-mail Id.", document.frmNewReg.txtNewRegEmail);
				} else {
				if (!validEmail(document.frmNewReg.txtNewRegEmail.value)) {
					doShowAlertPanel("Invalid e-mail address format! \nEvery e-mail address must include one @ sign followed by a domain ne. \nEg: User@Server.com.", document.frmNewReg.txtNewRegEmail);
				} else {
				if (document.frmNewReg.txtNewRegPhone.value=="") {
					doShowAlertPanel("Mobile number cannot be blank. Please enter the Mobile or Contact number.", document.frmNewReg.txtNewRegPhone);
				} else {
				if (document.frmNewReg.txtCaptcha.value=="") {
					doShowAlertPanel("Verification Code can not be blank. Please enter the Verification Code.", document.frmNewReg.txtCaptcha);
				} else {
				if (document.frmNewReg.txtCaptcha.value!=$("#spanCaptcha").html()) {
					doShowAlertPanel("The Verification Code you entered does not match with the Image Verification Code. Please click Referesh button and retype the Verification Code.", document.frmNewReg.txtCaptcha);
				} else {				
					var strPOSTURL = "elms_user_signup_update.php";
					var objFormData = $( "#frmNewReg" ).serialize();
					doPOSTNewRegFormData(strPOSTURL, objFormData);
				} } } } } }
			}
			function doSendForgotPassData() {
				if (document.frmForgotPass.txtForgotPassEmail.value=="") {
					doShowAlertPanel("E-mail Id cannot be blank. Please enter the E-mail Id.", document.frmForgotPass.txtForgotPassEmail);
				} else {
				if (!validEmail(document.frmForgotPass.txtForgotPassEmail.value)) {
					doShowAlertPanel("Invalid e-mail address format! \nEvery e-mail address must include one @ sign followed by a domain ne. \nEg: User@Server.com.", document.frmForgotPass.txtForgotPassEmail);
				} else {
					var strPOSTURL = "elms_forgot_pass_update.php";
					var objFormData = $( "#frmForgotPass" ).serialize();
					doPOSTForgotPassFormData(strPOSTURL, objFormData);
				} }
			}			
			
			function doPOSTNormalFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_INVALID")>-1) {
							doShowAlertPanel("Invalid Login Id or Password. Please try again!", document.frmMain.txtEmail);
						} else {
						if (strAjaxReturnTrimed.indexOf("ELMS_DEACTIVE")>-1) {
							doShowAlertPanel("Your account has been deactivated. Please contact <b>Glass Academy - Premier Glass Portal</b>.", '');
						} else {
							document.location.href = strAjaxReturnTrimed;
						} }
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}
			function doPOSTNewRegFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
							doHideNewRegForm();
							doShowAlertPanel("Thank you for registering with us and your account has been activated. Your login details has been sent to your registered e-mail. Please check your mailbox.", document.frmMain.txtEmail);
						} else {
							doShowAlertPanel(strAjaxReturnTrimed, '');
						}
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}
			function doPOSTForgotPassFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
							doHideForgotPassForm();
							doShowAlertPanel("Your login details has been sent to your registered E-mail Id. Please check your mailbox.", document.frmMain.txtEmail);
						} else {
							doShowAlertPanel(strAjaxReturnTrimed, '');
						}
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}			
			
			function doResetNewRegForm() {
				document.frmNewReg.txtNewRegFName.value = "";
				document.frmNewReg.txtNewRegLName.value = "";
				document.frmNewReg.txtNewRegEmail.value = "";
				document.frmNewReg.txtNewRegPhone.value = "";
			}
			function doResetForgotPassForm() {
				document.frmForgotPass.txtForgotPassEmail.value = "";
			}

			function doShowNewRegForm() {
				getScrollTop();
				doResetNewRegForm();
				document.getElementById("divLoginDisableBG").style.display = "block";
				document.getElementById("divNewReg").style.display = "block";
				document.frmNewReg.txtNewRegFName.focus();
			}
			function doHideNewRegForm() {
				doResetNewRegForm();
				document.getElementById("divNewReg").style.display = "none";
				document.getElementById("divLoginDisableBG").style.display = "none";
				document.frmMain.txtEmail.focus();
			}

			function doShowForgotPassForm() {
				getScrollTop();
				doResetForgotPassForm();
				document.getElementById("divLoginDisableBG").style.display = "block";
				document.getElementById("divForgotPass").style.display = "block";
				document.frmForgotPass.txtForgotPassEmail.focus();
			}
			function doHideForgotPassForm() {
				doResetForgotPassForm();
				document.getElementById("divForgotPass").style.display = "none";
				document.getElementById("divLoginDisableBG").style.display = "none";
				document.frmMain.txtEmail.focus();
			}
			
			document.onkeypress = keyPress;
			function keyPress(e){
				var x = e || window.event;
				var key = (x.keyCode || x.which);
				if(key == 13 || key == 3){
					doFormValidation();
				}
			}

			function disableSelection(target) {
				//For IE This code will work
				if (typeof target.onselectstart!="undefined")
				target.onselectstart=function(){return false}

				//For Firefox This code will work
				else if (typeof target.style.MozUserSelect!="undefined")
				target.style.MozUserSelect="none"

				//All other  (ie: Opera) This code will work
				else
				target.onmousedown=function(){return false}
				target.style.cursor = "default"
			}			
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
			<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
				<?php
					require('elms_top_panel.php');
				?>
			</div>
			<div class="clsBgPattern">
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel" style="background: url(images/content_bg.png) no-repeat bottom left;">
					<br /><br /><br />
					<table width="90%" align="center" cellspacing="0" cellpadding="0" bgcolor="#0c3960" class="clsBgImageShadow" border="0">
						<tr height="40">
							<td width="100%" colspan="5">
							</td>
						</tr>
						<tr>
							<td width="2%">
							</td>							
							<td width="58%" align="center" valign="top" bgcolor="#ffffff">
								<div style="height:100%; border:1px solid #215f99;">
									<table width="100%" align="center" cellspacing="0" cellpadding="0">
										<tr height="38" bgcolor="#00a4f0">
											<td align="left" valign="middle" class="clsMentorePanelHeading">
												&nbsp;<div style="display:inline-block; test-align:left; vertical-align:middle;"><img src="images/mentote_message.png" alt="" title="" /></div>
												&nbsp;Mentor's message
											</td>
										</tr>
										<tr>
											<td align="center" class="clsMentorePanelBody">
												<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
													<tr height="10">
														<td width="100%" colspan="5"></td>
													</tr>
													<tr class="clsMentorePanelBody">
														<td width="2%"></td>
														<td width="5%" align="left" valign="top">
															<img src="images/male.png" alt="" title="" />
														</td>
														<td width="2%"></td>
														<td align="left" valign="top">
															<b>Building Envelope Design</b>
															<br />
															<font>Building Envelop Design has become a specialised field. With several Codes emphasizing Energy...</font>
															<br />
															<a href="http://glass-academy.com/mentor/#arc-n-raghavendran" target="_blank" class="clsMentoreHyperLink"><font color="#5b7b3c">Read More...</font></a>
														</td>
														<td width="2%"></td>
													</tr>
													<tr height="10">
														<td width="2%"></td>
														<td align="center" valign="middle" colspan="3">
															<hr style="border:#d4d4d4 1px dashed" />
														</td>
														<td width="2%"></td>
													</tr>
													<tr height="10">
														<td width="100%" colspan="5"></td>
													</tr>
													<tr>
														<td width="2%"></td>
														<td width="5%" align="left" valign="top">
															<img src="images/female.png" alt="" title="" />
														</td>
														<td width="2%"></td>
														<td align="left" valign="top">
															<b>Role of Glass in GRIHA Rating System</b>
															<br />
															<font>Glass is one of the key elements that lends aesthetic and functional value to a building...</font>
															<br />
															<a href="http://glass-academy.com/mentor/#msmili-majumdar" target="_blank" class="clsMentoreHyperLink"><font color="#5b7b3c">Read More...</font></a>
														</td>
														<td width="2%"></td>
													</tr>												
												</table>
											</td>
										<tr>
									</table>
								</div>								
							</td>
							<td width="3%">
							</td>
							<td width="35%" align="center" valign="top" bgcolor="#07477e">
								<div style="height:100%; border:0px solid #215f99; background:#07477e;">
									<table width="100%" align="center" cellspacing="0" cellpadding="0">
										<tr height="38" bgcolor="#00a4f0">
											<td class="clsLoginPanelHeading">&nbsp;&nbsp;Login</td>
										</tr>
										<tr>
											<td align="center" class="clsLoginPanelBody">
												<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
													<tr height="25">
														<td width="100%"></td>
													</tr>
													<tr>
														<td width="100%">
															<form name="frmMain" id="frmMain" method="post" action="elms_login_check.php">
																<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
																	<tr>
																		<td width="2%">
																		</td>
																		<td width="11%" align="left" valign="top">
																			<img src="images/login_lock.png" alt="" title="" />
																		</td>
																		<td align="left" valign="top">
																			<table width="100%" align="center" cellspacing="0" cellpadding="0">
																				<tr>
																					<td width="27%" align="right" valign="middle">
																						E-mail Id:
																					</td>
																					<td width="3%">
																					</td>
																					<td width="70%" align="left" valign="middle">
																						<input type="text" id="txtEmail" name="txtEmail" class="clsTextField" style="width:97%; height:20px; font-size:15px;" />
																					</td>																			
																				</tr>
																				<tr height="5">
																					<td colspan="3"></td>
																				</tr>
																				<tr>
																					<td width="27%" align="right" valign="middle" >
																						Password:
																					</td>
																					<td width="3%">
																					</td>
																					<td width="70%" align="left" valign="middle">
																						<input type="password" id="txtPass" name="txtPass" class="clsTextField" style="width:97%; height:20px; font-size:15px;" />
																					</td>																			
																				</tr>
																				<tr height="15">
																					<td colspan="3"></td>
																				</tr>
																				<tr>
																					<td colspan="3">
																						<table width="100%" cellspacing="0" cellpadding="0" border="0">
																							<tr>
																								<td width="100%" align="right">
																									<input type="button" value="" onclick="javascript:doFormValidation();" style="width:120px; height:43px; border:none; background:url(images/sign_in.png); background-repeat: no-repeat; cursor:pointer;" />
																								</td>
																							</tr>
																						</table>
																					</td>												
																				</tr>
																				<tr height="5">
																					<td colspan="3"></td>												
																				</tr>
																				<tr>
																					<td align="right" colspan="3">
																						<a href="javascript:doShowNewRegForm();" class="clsHyperLinkText"><font color="#ffffff">New User</font></a>&nbsp;|&nbsp;<a href="javascript:doShowForgotPassForm();" class="clsHyperLinkText"><font color="#ffffff">Forgot Password</font></a>
																					</td>												
																				</tr>																		
																			</table>
																		</td>																
																		<td width="2%">
																		</td>																
																	</tr>
																</table>
															</form>
														</td>
													</tr>												
												</table>
											</td>
										<tr>									
									</table>
								</div>
							</td>
							<td width="2%">
							</td>							
						</tr>
						<tr height="35">
							<td width="100%" colspan="5">
							</td>
						</tr>
						<tr>
							<td width="100%" align="center" valign="top" colspan="5">
								<div style="height:100%; border:0px solid #215f99;">
									<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
										<tr>
											<td width="2%">
											</td>										
											<td width="40%">
												<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
													<tr height="38" bgcolor="#ffc600" class="clsLoginPanelHeading">
														<td width="100%" align="left">&nbsp;Courses and Videos</td>
													</tr>
													
													<tr height="5" bgcolor="#ffffff"><td width="100%" align="center"></td></tr>
													<tr bgcolor="#ffffff">
														<td align="center" valign="top">
															<a href="http://glass-academy.com/courses/all/" target="_blank"><img width="338" height="260" border="0" src="images/login_courses_icon.png" alt="" title="" /></a>
														</td>
													</tr>													
												</table>
											</td>
											<td width="3%">
											</td>
											<td width="40%">
												<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
													<tr height="38" bgcolor="#ffc600" class="clsLoginPanelHeading">
														<td width="100%" align="left">&nbsp;mLearning</td>
													</tr>
													
													<tr height="5" bgcolor="#ffffff"><td width="100%" align="center"></td></tr>
													<tr bgcolor="#ffffff">
														<td align="center" valign="top">
															<a href="http://glass-academy.com/" target="_blank"><img width="338" height="260" border="0" src="images/login_mLearning_icon.png" alt="" title="" /></a>
														</td>
													</tr>													
												</table>
											</td>											
											<td width="2%">
											</td>											
										</tr>
									</table>
								</div>
							</td>
						</tr>
						<tr height="40">
							<td width="100%" colspan="5">
							</td>
						</tr>						
					</table>
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tr height="122">
							<td></td>
						</tr>
					</table>
				</div>
			</div>
			<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
				<?php
					require('elms_bottom_panel.php');
				?>
			</div>
			<div id="divLoginDisableBG" name="divLoginDisableBG" class="clsDivLoginDisableBG"></div>
			<div id="divNewReg" name="divNewReg" style="position:fixed; left:0px; top:5%; right:0px; margin:auto; display:none;">
				<form name="frmNewReg" id="frmNewReg" method="post" action="elms_user_signup_update.php">
					<table width="45%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>" class="clsSingleBorder">
						<tr class="clsTableSingleRowHeadingText">
							<td width="100%">New User Registration</td>
						</tr>
						<tr height="30">
							<td width="100%" align="center" valign="middle">Fields marked with <font color="red">*</font> are mandatory</td>
						</tr>
						<tr>
							<td width="100%" align="left" valign="top">
								<table width="100%" align="center" cellspacing="2" cellpadding="2">
									<tr>
										<td width="35%" align="right">
											<font color="red">*</font> Membership Type:
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<select id="ddUserMemType" name="ddUserMemType" size="1" class="clsTextField" style="width:80%;">
											<?php
												mysql_select_db($strCurDirName);
												$tQuery = "SELECT * FROM elms_membership_details WHERE mem_type='External'";
												$tResult = mysql_query($tQuery) or die (mysql_error());
												while ($tRow = mysql_fetch_array($tResult)) {
											?>
													<option value="<?php echo $tRow["mem_id"]; ?>"><?php echo $tRow["mem_name"]; ?></option>
											<?php
												}
											?>																											
											</select>
										</td>																										
									</tr>
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>								
									<tr>
										<td width="35%" align="right">
											<font color="red">*</font> Title:
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<select id="ddUserTitle" name="ddUserTitle" size="1" class="clsTextField" style="width:25%;">
												<option selected value="Mr.">Mr.</option>
												<option value="Miss">Miss</option>
												<option value="Mrs.">Mrs.</option>
												<option value="Dr.">Dr.</option>
											</select>
										</td>																										
									</tr>									
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>								
									<tr>
										<td width="35%" align="right">
											<font color="red">*</font> First Name:
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<input type="text" id="txtNewRegFName" name="txtNewRegFName" class="clsTextField" style="width:80%" />
										</td>																										
									</tr>
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>
									<tr>
										<td width="35%" align="right">
											Last Name:
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<input type="text" id="txtNewRegLName" name="txtNewRegLName" class="clsTextField" style="width:80%" />
										</td>																										
									</tr>
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>
									<tr>
										<td width="35%" align="right">
											<font color="red">*</font> E-mail(Login Id):
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<input type="text" id="txtNewRegEmail" name="txtNewRegEmail" class="clsTextField" style="width:80%" />
										</td>																										
									</tr>
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>
									<tr>
										<td width="35%" align="right">
											<font color="red">*</font>  Mobile:
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<input type="text" id="txtNewRegPhone" name="txtNewRegPhone" class="clsTextField" style="width:80%" />
										</td>																										
									</tr>
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>
									<tr>
										<td width="35%" align="right" valign="top">
											<font color="red">*</font>  Verification Code:
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<div id="divCaptcha" name="divCaptcha" class="clsDivCaptcha" style="width:175px; cursor:default;">
												<span id="spanCaptcha" name="spanCaptcha" class="clsSpanCaptcha"></span>
											</div>
											<div style="height:5px;"></div>
											<span>
												<input type="button" value="Refresh" style="position:relative;" onclick="doDrawCaptcha();" />
											</span>											
										</td>																										
									</tr>									
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>
									<tr>
										<td width="35%" align="right">
											<font color="red">*</font>  Enter the Code:
										</td>
										<td width="1%">
										</td>																										
										<td width="64%" align="left">
											<input type="text" id="txtCaptcha" name="txtCaptcha" class="clsTextField" style="width:200px;">											
										</td>																										
									</tr>									
									<tr height="10">
										<td width="100%" colspan="3"></td>
									</tr>
									<tr>
										<td width="100%" align="center" colspan="3">
											<input type="button" value="&nbsp;Register&nbsp;" class="clsActionButton" onclick="javascript:doSendNewRegData();" />
											<input type="button" value="Cancel" class="clsActionButton" onclick="javascript:doHideNewRegForm();" />
										</td>
									</tr>
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>																									
								</table>
							</td>
						</tr>																						
					</table>
				</form>
			</div>
			<div id="divForgotPass" name="divForgotPass" style="position:fixed; left:0px; top:25%; right:0px; margin:auto; display:none;">
				<form name="frmForgotPass" id="frmForgotPass" method="post" action="elms_user_signup_update.php">
					<table width="45%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>" class="clsSingleBorder">
						<tr class="clsTableSingleRowHeadingText">
							<td width="100%">Forgot Password</td>
						</tr>
						<tr>
							<td width="100%" align="left" valign="top">
								<table width="100%" align="center" cellspacing="2" cellpadding="2">
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>								
									<tr>
										<td width="32%" align="right">
											<font color="red">*</font> Registered E-mail Id:
										</td>
										<td width="1%">
										</td>																										
										<td width="67%" align="left">
											<input type="text" id="txtForgotPassEmail" name="txtForgotPassEmail" class="clsTextField" style="width:90%" />
										</td>																										
									</tr>
									<tr height="10">
										<td width="100%" colspan="3"></td>
									</tr>
									<tr>
										<td width="100%" align="center" colspan="3">
											<input type="button" value="&nbsp;Send Password&nbsp;" class="clsActionButton" onclick="javascript:doSendForgotPassData();" />
											<input type="button" value="Cancel" class="clsActionButton" onclick="javascript:doHideForgotPassForm();" />
										</td>
									</tr>
									<tr height="5">
										<td width="100%" colspan="3"></td>
									</tr>																									
								</table>
							</td>
						</tr>																						
					</table>
				</form>
			</div>			
			<?php
				require('elms_common_panel.php');
			?>
		</div>
		<script>
			//Calling the JS function directly just after body load
			disableSelection(document.getElementById('divCaptcha'))
		</script>		
	</body>
</html>

<?php
	function doGetDateTimeDiff($strTemp1, $strTemp2, $strRequired="") {
		$strReturnVal = "";
		$strDate1 = $strTemp1;
		$strDate2 = $strTemp2;
		$strDiff = abs(strtotime($strDate2) - strtotime($strDate1));
		$years = floor($strDiff / (365*60*60*24));
		$months = floor(($strDiff - $years * 365*60*60*24) / (30*60*60*24));
		$days = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
		$hours = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60));
		$minuts = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60);
		$seconds = floor(($strDiff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minuts*60));
		if (strlen($hours)==1) $hours = "0" . $hours;
		if (strlen($minuts)==1) $minuts = "0" . $minuts;
		if (strlen($seconds)==1) $seconds = "0" . $seconds;
		if ($strRequired=="D") {
			$strReturnVal = $days;
		} else {
			$strReturnVal = $hours . ":" . $minuts . ":" . $seconds;
		}
		return $strReturnVal;
	}
?>