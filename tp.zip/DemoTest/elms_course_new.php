<?php
	require("elms_top_includes.php");
?>

<?php
	$tempQuery = "SELECT * FROM elms_category_details ORDER BY category_name";
	$categoryResult = mysql_query($tempQuery) or die (mysql_error());
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			var strValidImageFileExtensions = [".jpg", ".jpeg", ".png", ".gif"];
			var strValidZipFileExtensions = [".zip"];
			
		    function doInitialize() {
		    	document.frmMain.txtName.focus();
			}

			function doFormValidation() {
				if (document.frmMain.txtName.value=="") {
					doShowAlertPanel("Please enter the Course Name.", document.frmMain.txtName);
				} else {
				if (document.frmMain.ddCat.value=="" && document.frmMain.txtCat.value=="") {
					doShowAlertPanel("Please select the Course Category or enter new one.", document.frmMain.txtCat);
				} else {
				if (document.frmMain.txtOfferType.value=="N" && document.frmMain.txtPrice.value=="") {
					doShowAlertPanel("Please enter the Course Price.", document.frmMain.txtPrice);
				} else {
				if (document.frmMain.txtOfferType.value=="N" && parseFloat(document.frmMain.txtPrice.value).toString()=='NaN') {
					doShowAlertPanel("Please enter the valid Course Price.", document.frmMain.txtPrice);
				} else {
				if (document.frmMain.txtThumbImg.value!="" && !doValidFileExtension(document.frmMain.txtThumbImg.value, strValidImageFileExtensions)) {
					doShowAlertPanel("Invalid Image file. Please choose the valid file.", document.frmMain.txtThumbImg);
				} else {				
				if (document.frmMain.txtCourseZip.value=="") {
					doShowAlertPanel("Please choose the SCORM Course Zip Package file.", document.frmMain.txtCourseZip);
				} else {
				if (!doValidFileExtension(document.frmMain.txtCourseZip.value, strValidZipFileExtensions)) {
					doShowAlertPanel("Invalid SCORM Course Zip Package file. Please choose the valid file.", document.frmMain.txtCourseZip);
				} else {
					doShowProccessIcon();
					document.frmMain.submit();
				} } } } } } }
			}
			
			function doCheckORUncheckMemType(strTemp) {
				if (document.getElementById(strTemp).checked==true) {
					document.getElementById(strTemp).checked = false;
				} else {
					document.getElementById(strTemp).checked = true;
				}
			}
			
			function doValidFileExtension(strTemp, arrTemp){
				var varRetVal = false;
				var sCurExtension = "";
				for (var i=0; i<arrTemp.length; i++) {
					sCurExtension = arrTemp[i];
					if (strTemp.substr(strTemp.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
						varRetVal = true;
						break;
					}
				}
				return varRetVal;
			}			
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" enctype="multipart/form-data" action="elms_course_new_update.php">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0" bgcolor="<?php echo $_SESSION["Elms_AlternateFColor"]; ?>">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="3">New Course Upload</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="3">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<?php
																							$varDispError = "";
																							if (isset($_SESSION["Elms_ResMsg"])) {
																								if ($_SESSION["Elms_ResMsg"]!="") { $varDispError = $_SESSION["Elms_ResMsg"]; }
																								$_SESSION["Elms_ResMsg"] = "";
																							}
																						?>
																						<?php if ($varDispError!="") { ?>
																							<tr height="15">
																								<td width="100%" align="center" valign="middle" colspan="3">
																								</td>
																							</tr>																			
																							<tr>
																								<td width="100%" align="center" valign="middle" colspan="3" class="clsResErrorMsgText">
																									<font color="green"><?php echo $varDispError; ?></font>
																								</td>
																							</tr>
																							<tr height="15">
																								<td width="100%" align="center" valign="middle" colspan="3">
																								</td>
																							</tr>
																						<?php } ?>																						
																						<tr>
																							<td width="25%" align="right" valign="middle"><font color="red">*</font> Course Name:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle"><input type="text" id="txtName" name="txtName" class="clsTextField" style="width:70%" /></td>
																						</tr>
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top"><font color="red">*</font> Category:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="top">
																								<font color="red"><b>Note:</b></font> Select the category or enter new
																								<br />
																								<select id="ddCat" name="ddCat" class="clsTextField" style="width:200px;" onchange="javascript:doEnableNewCategory();">
																									<option selected value="">New Category</option>
																									<?php
																										while ($row = mysql_fetch_array($categoryResult)) {
																									?>
																											<option value="<?php echo $row["category_id"]; ?>"><?php echo $row["category_name"]; ?></option>
																									<?php
																										}
																									?>
																								</select>
																								<input type="text" id="txtCat" name="txtCat" class="clsTextField" style="width:47%" />
																							</td>
																						</tr>
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Course Type:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<font color="red"><b>Note:</b></font> If you select Normal Web Package, the launch file name should be <b>player.html</b>. So that if you have any other name for launch file, please rename it as <b>player.html</b> and then upload the course.
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="25%" align="right" valign="top"></td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<select id="ddType" name="ddType" class="clsTextField" style="width:200px;">
																									<option selected value="SCORM">SCORM Package</option>
																									<option value="NONSCORM">Normal Web Package</option>
																								</select>
																							</td>
																						</tr>																						
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Description:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<textarea id="txtDesc" name="txtDesc" class="clsTextField" style="width:75%; height:100px; resize:none;"></textarea>
																							</td>
																						</tr>
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">This Course For:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutUserType(document.getElementById('rdUIO'), document.getElementById('rdUIO').value)"><input id="rdUIO" name="rdUIO" type="radio" value="InternalOnly" checked onclick="javascript:doPutUserType(this, this.value);" />Internal Users Only</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutUserType(document.getElementById('rdUEO'), document.getElementById('rdUEO').value)"><input id="rdUEO" name="rdUEO" type="radio" value="ExternalOnly" onclick="javascript:doPutUserType(this, this.value);" />External Users Only</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutUserType(document.getElementById('rdUBoth'), document.getElementById('rdUBoth').value)"><input id="rdUBoth" name="rdUBoth" type="radio" value="Both" onclick="javascript:doPutUserType(this, this.value);" />Internal and External Users</div>
																							</td>
																						</tr>																						
																						<tr>
																							<td width="100%" colspan="3">
																								<div id="divOffer" name="divOffer" style="display:none;">
																									<table width="100%" cellspacing="0" cellpadding="0">
																										<tr height="25">
																											<td width="100%" colspan="3"></td>
																										</tr>																									
																										<tr height="1">
																											<td width="25%" align="right" valign="top">Offer Type for External Users:</td>
																											<td width="1%"></td>
																											<td width="84%" align="left" valign="middle">
																												<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutOfferType(document.getElementById('rdFree'), document.getElementById('rdFree').value)"><input id="rdFree" name="rdFree" type="radio" value="Y" checked onclick="javascript:doPutOfferType(this, this.value);" />Free</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutOfferType(document.getElementById('rdNoFree'), document.getElementById('rdNoFree').value)"><input id="rdNoFree" name="rdNoFree" type="radio" value="N" onclick="javascript:doPutOfferType(this, this.value);" />Paid</div>
																												<div id="divCourseSubInfo" name="divCourseSubInfo" style="display:none;">
																													<div style="height:5px;"></div>
																													<table cellspacing="0" cellpadding="0" border="0">
																														<tr>
																															<td align="left" valign="middle">
																																Price:
																															</td>
																															<td align="left" valign="middle">
																																&nbsp;
																																<input type="text" id="txtPrice" name="txtPrice" class="clsTextField" style="width:50px; height:15px;" />
																																&nbsp;&nbsp;&nbsp;&nbsp;
																															</td>
																															<td align="left" valign="middle">
																																Discount:
																															</td>
																															<td align="left" valign="middle">
																																&nbsp;
																																<input type="text" id="txtDiscount" name="txtDiscount" class="clsTextField" style="width:50px; height:15px;" />
																															</td>																															
																														</tr>
																													</table>
																												</div>
																											</td>
																										</tr>
																									</table>
																								</div>
																							</td>
																						</tr>
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Select Membership:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<font color="red"><b>Note:</b></font> Select the below listed memberships who are entitled to take this course.
																								<div style="height:5px;"></div>
																								<div id="divInternalMemList" name="divInternalMemList">
																									<div style="height:5px;"></div>
																									<?php
																										$tQuery = "SELECT * FROM elms_membership_details WHERE mem_type='Internal'";
																										$tResult = mysql_query($tQuery) or die (mysql_error());
																										while ($tRow = mysql_fetch_array($tResult)) {
																									?>
																											<div style="display:inline-block; cursor:pointer;" onclick="javascript:doCheckORUncheckMemType('chkUserIMemType_<?php echo $tRow["mem_id"]; ?>')"><input type="checkbox" id="chkUserIMemType_<?php echo $tRow["mem_id"]; ?>" name="chkUserIMemType[]" value="<?php echo $tRow["mem_id"]; ?>" onclick="javascript:doCheckORUncheckMemType(this.id)" />&nbsp;<?php echo $tRow["mem_name"]; ?></div>
																									<?php
																										}
																									?>
																								</div>
																								<div id="divExternalMemList" name="divExternalMemList" style="display:none;">
																									<?php
																										$tQuery = "SELECT * FROM elms_membership_details WHERE mem_type='External'";
																										$tResult = mysql_query($tQuery) or die (mysql_error());
																										while ($tRow = mysql_fetch_array($tResult)) {
																									?>
																											<div style="display:inline-block; cursor:pointer;" onclick="javascript:doCheckORUncheckMemType('chkUserEMemType_<?php echo $tRow["mem_id"]; ?>')"><input type="checkbox" id="chkUserEMemType_<?php echo $tRow["mem_id"]; ?>" name="chkUserEMemType[]" value="<?php echo $tRow["mem_id"]; ?>" onclick="javascript:doCheckORUncheckMemType(this.id)" />&nbsp;<?php echo $tRow["mem_name"]; ?></div>
																									<?php
																										}
																									?>
																								</div>
																								<div id="divInternalAndExternalMemList" name="divInternalAndExternalMemList" style="display:none;">
																									<?php
																										$tQuery = "SELECT * FROM elms_membership_details ORDER BY mem_name";
																										$tResult = mysql_query($tQuery) or die (mysql_error());
																										$varTempChkText = "";
																										$varTempMemListVal = "";
																										$varTempPrevId = 0;
																										while ($tRow = mysql_fetch_array($tResult)) {
																											if ($varTempChkText!=$tRow["mem_name"]) {
																												if ($varTempMemListVal=="") {
																													$varTempMemListVal = $tRow["mem_name"] . "~" . $tRow["mem_id"];
																												} else {
																													$varTempMemListVal = $varTempMemListVal . "SPLMAIN" . $tRow["mem_name"] . "~" . $tRow["mem_id"];
																												}
																											} else {
																												$varTempMemListVal = str_replace($tRow["mem_name"] . "~" . $varTempPrevId, $tRow["mem_name"] . "~" . $varTempPrevId . "~" . $tRow["mem_id"], $varTempMemListVal);
																											}
																											$varTempChkText = $tRow["mem_name"];
																											$varTempPrevId = $tRow["mem_id"];
																										}
																										if ($varTempMemListVal!="") {
																											$varTempMemListValArray = explode("SPLMAIN", $varTempMemListVal);
																									?>
																									<?php
																										for ($k=0; $k<count($varTempMemListValArray); $k++) {
																									?>
																											<?php
																												$varTempSubSpl = explode("~", $varTempMemListValArray[$k]);
																												$varMemName = "";
																												$varMemId = "";
																												if (count($varTempSubSpl)==2) {
																													$varMemName = $varTempSubSpl[0];
																													$varMemId = $varTempSubSpl[1];
																												} else {
																													$varMemName = $varTempSubSpl[0];
																													$varMemId = $varTempSubSpl[1] . "~" . $varTempSubSpl[2];
																												}
																											?>
																											<div style="display:inline-block; cursor:pointer;" onclick="javascript:doCheckORUncheckMemType('chkUserIEMemType_<?php echo $varMemId; ?>')"><input type="checkbox" id="chkUserIEMemType_<?php echo $varMemId; ?>" name="chkUserIEMemType[]" value="<?php echo $varMemId; ?>" onclick="javascript:doCheckORUncheckMemType(this.id)" />&nbsp;<?php echo $varMemName; ?></div>
																									<?php
																											}
																										}
																									?>																									
																								</div>
																							</td>
																						</tr>
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>
																						<tr>
																							<td width="25%" align="right" valign="top">Certificate:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutCertificateYN(document.getElementById('rdCertY'), document.getElementById('rdCertY').value)"><input id="rdCertY" name="rdCertY" type="radio" value="Y" checked onclick="javascript:doPutCertificateYN(this, this.value);" />Yes</div>&nbsp;&nbsp;<div style="display:inline-block; cursor:pointer;" onclick="javascript:doPutCertificateYN(document.getElementById('rdCertN'), document.getElementById('rdCertN').value)"><input id="rdCertN" name="rdCertN" type="radio" value="N" onclick="javascript:doPutCertificateYN(this, this.value);" />No</div>
																							</td>
																						</tr>
																						<tr height="15">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="25%" align="right" valign="top">Thumbnail Picture:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<font color="red"><b>Note:</b></font> If you wish to add thumbnail image browse the file. The image file should be (jpg, jpeg, png or gif) with DIM of 320x240 or less and file size should be less then or eaqual to 2 MB.
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="25%" align="right" valign="top"></td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<input id="txtThumbImg" name="txtThumbImg" class="clsTextField" type="file"  />
																							</td>
																						</tr>
																						<tr height="25">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="25%" align="right" valign="top"><font color="red">*</font> Course Package:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<font color="red"><b>Note:</b></font> Select the SCORM Course ZIP Package
																							</td>
																						</tr>
																						<tr height="10">
																							<td width="100%" colspan="3"></td>
																						</tr>																						
																						<tr>
																							<td width="25%" align="right" valign="top"></td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<input id="txtCourseZip" name="txtCourseZip" class="clsTextField" type="file"  />
																							</td>
																						</tr>																						
																						<tr>
																							<td width="98%" align="left" valign="middle" colspan="3">
																								<table width="99%" cellspacing="0" cellpadding="0">
																									<tr>
																										<td width="99%" align="right" valign="middle">
																											<input type="button" value="&nbsp;Upload&nbsp;" class="clsActionButton" onclick="javascript:doFormValidation();" />
																											<input type="button" value="<< Return" class="clsActionButton" onclick="javascript:doCancel('elms_course_list.php');" />
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="15">
																							<td colspan="3"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtUserType" name="txtUserType" type="hidden" value="InternalOnly" />
																		<input id="txtOfferType" name="txtOfferType" type="hidden" value="Y" />
																		<input id="txtCertYN" name="txtCertYN" type="hidden" value="Y" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>