<?php
	require("elms_config.php");
	require("elms_db.php");
	require("elms_lib.php");
	if (!isset($_POST["txtUserName"])) {
		echo "Unfortunately the system could not generate the PDF.";
		exit();
	} else {
		require_once('tcpdf/config/tcpdf_config.php');
		require_once('tcpdf/tcpdf.php');
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, 'A4', true, 'UTF-8', false);
		$pdf->SetHeaderData("", "", "", "");
		$pdf->setPrintHeader(false);
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		$pdf->SetMargins(0, 5, 0);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		$pdf->AddPage();
		
		$image_file = 'images/Certificate2_a1.jpg';
		$pdf->Image($image_file, 0, 2, 210, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
		
		$varUserName = $_POST["txtUserName"];
		$varCourseName = $_POST["txtCourseName"];
		$varCourseCatName = $_POST["txtCourseCatName"];
		$varCourseSD = $_POST["txtCourseSD"];
		$varCourseCD = $_POST["txtCourseCD"];

		$varCertMsg = '<p>';
		$varCertMsg .= '<b><u>' . $varUserName . '</u></b>&nbsp;In recognition of having successfully completed the course on&nbsp;';
		$varCertMsg .= '<b><u>' . $varCourseName . '</u></b>&nbsp;';
		$varCertMsg .= 'under the category <b><u>' . $varCourseCatName . '</u></b>';
		$varCertMsg .= '<div style="font-size:12px; text-align:left;">';
		$varCertMsg .= 'from <u><b>' . $varCourseSD . '</b></u>';
		$varCertMsg .= '&nbsp;to <u><b>' . $varCourseCD . '</b></u>';
		$varCertMsg .= '</div>';
		$varCertMsg .= '</p>';

		$pdf->writeHTMLCell(175, '', 20, 65, $varCertMsg, 1, 0, 1, true, 'L', true);

		ob_flush();
		$pdf->Output('Completion_Certificate_' . date('Y-m-d') . '.pdf', 'I');
	}
?>