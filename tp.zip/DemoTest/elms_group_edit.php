<?php
	require("elms_top_includes.php");
?>

<?php
	$varID = "";
	if (!isset($_POST["txtGroupId"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["txtGroupId"];
		$tempQuery = "SELECT * FROM elms_group_details WHERE group_id=" . $varID;
		$groupResult = mysql_query($tempQuery) or die (mysql_error());
		$groupRow = mysql_fetch_array($groupResult);
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<script language="javascript">
			function doInitialize() {
				document.frmMain.txtName.focus();
			}
			
			function doFormValidation() {
				if (document.frmMain.txtName.value=="") {
					doShowAlertPanel("Group Name can not be blank. Please enter the Group Name.", document.frmMain.txtName);
				} else {
					var strPOSTURL = "elms_group_edit_update.php";
					var objFormData = $( "#frmMain" ).serialize();					
					doPOSTNormalFormData(strPOSTURL, objFormData);
				}
			}			
			
			function doPOSTNormalFormData(varPOSTURL, varFormData) {
				doShowProccessIcon();
				$.ajax({
					type: "POST",
					url: varPOSTURL,
					data: varFormData,
					success: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						if (strAjaxReturnTrimed.indexOf("ELMS_SUCCESS")>-1) {
							document.location.href = "elms_group_list.php";
						} else {
							doShowAlertPanel(strAjaxReturnTrimed, '');
						}
						
					},
					error: function(responseText) {
						doHideProccessIcon();
						strAjaxReturnTrimed = responseText.replace(/^\s+|\s+$/gm,'');
						doShowAlertPanel(strAjaxReturnTrimed, '');
					}
				});
			}
		</script>
	</head>
	<body onload="javascript:doInitialize();">
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="left" valign="top">
																	<form name="frmMain" id="frmMain" method="post" action="elms_group_edit_update.php">
																		<table width="100%" cellspacing="0" cellpadding="0" class="clsSingleBorder">
																			<tr>
																				<td>
																					<table width="100%" align="center" cellspacing="0" cellpadding="0">
																						<tr class="clsTableSingleRowHeadingText">
																							<td width="100%" colspan="3">Edit Group</td>
																						</tr>
																						<tr height="30">
																							<td width="100%" align="center" valign="middle" colspan="3">Fields marked with <font color="red">*</font> are mandatory</td>
																						</tr>
																						<tr>
																							<td width="15%" align="right" valign="middle"><font color="red">*</font> Group Type:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<?php echo $groupRow["group_type"]; ?>
																							</td>
																						</tr>																						
																						<tr>
																							<td width="15%" align="right" valign="middle"><font color="red">*</font> Group Name:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<input type="text" id="txtName" name="txtName" class="clsTextField" value="<?php echo $groupRow["group_name"]; ?>" style="width:75%" />
																							</td>
																						</tr>
																						<tr>
																							<td width="15%" align="right" valign="top">Description:</td>
																							<td width="1%"></td>
																							<td width="84%" align="left" valign="middle">
																								<textarea id="txtDesc" name="txtDesc" class="clsTextField" style="width:98%; height:100px; resize:none;"><?php echo $groupRow["group_desc"]; ?></textarea>
																							</td>
																						</tr>
																						<tr>
																							<td width="98%" align="left" valign="middle" colspan="3">
																								<table width="99%" cellspacing="0" cellpadding="0">
																									<tr>
																										<td width="99%" align="right" valign="middle">
																											<input type="button" value="Update" class="clsActionButton" onclick="javascript:doFormValidation();" />
																											<input type="button" value="<< Back" class="clsActionButton" onclick="javascript:doCancel('elms_group_list.php');" />
																										</td>
																									</tr>
																								</table>
																							</td>
																						</tr>
																						<tr height="10">
																							<td colspan="3"></td>
																						</tr>
																					</table>
																				</td>
																			</tr>
																		</table>
																		<input id="txtStatus" name="txtStatus" type="hidden" value="<?php echo $groupRow["group_status"]; ?>" />
																		<input id="txtGroupId" name="txtGroupId" type="hidden" value="<?php echo $groupRow["group_id"]; ?>" />
																		<input id="txtGroupType" name="txtGroupType" type="hidden" value="<?php echo $groupRow["group_type"]; ?>" />
																	</form>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>