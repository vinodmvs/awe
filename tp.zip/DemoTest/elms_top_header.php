<?php
	if (isset($_SESSION["Elms_LoggedInId"]) && $_SESSION["Elms_LoggedInId"]!="") {
		$strSTitle = "MVSLMS";
	} else {
		$strSTitle = "MVSLMS";
	}
?>
<title><?php echo $strSTitle; ?></title>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="keywords" 	 content="" />
<meta name="description" content="" />

<link rel="shortcut icon" href="images/logo.png" />
<link rel="stylesheet" type="text/css" href="css/fonts.css" />
<link rel="stylesheet" type="text/css" href="css/jquery_ui.css" />
<link rel="stylesheet" type="text/css" href="css/elms_main.css" />
<?php require("css/elms_style.php"); ?>

<script type="text/javascript" language="javascript" src="js/jquery_1.10.2.min.js"></script>
<script type="text/javascript" language="javascript" src="js/jquery_ui.js"></script>
<script type="text/javascript" language="javascript" src="js/jquery_form.min.js"></script>
<script type="text/javascript" language="javascript" src="js/jquery_print.js"></script>
<script type="text/javascript" language="javascript" src="js/jquery_ui_timepicker_addon.js"></script>
<script type="text/javascript" language="javascript" src="js/elms_js.js"></script>