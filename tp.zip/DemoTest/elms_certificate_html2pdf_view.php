<?php
	require("elms_config.php");
	require("elms_db.php");
?>

<?php
	require_once('tcpdf/config/tcpdf_config.php');
	require_once('tcpdf/tcpdf.php');
?>

<?php

	$varUserName = "";
	$varCourseName = "";
	if (!isset($_POST["txtUserName"])) {
		header("Location: index.php");
	} else {
		$varUserName = $_POST["txtUserName"];
		$varCourseName = $_POST["txtCourseName"];

		$varHeadingText =  "Certificate for the Course '" . $varCourseName . "'";

		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		$pdf->SetHeaderData("", "", $varHeadingText, "");
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		$pdf->AddPage();

		$fontname = $pdf->addTTFfont('css/fonts/ELEGAN_1.TTF', 'TrueTypeUnicode', '', 96);
		$pdf->SetFont('helvetica', 'B', 10);

		$varBgImage = '<img src="images/certificate.jpg" alt="" title="" />';
		$varLogoImage = '<img src="images/logo.png" alt="" title="" />';

		$pdf->writeHTMLCell(0, 0, '15px', '20px', $varBgImage, '', 1, 0, true, 'L', true);
		$pdf->writeHTMLCell(0, 0, '63px', '30px', $varLogoImage, '', 1, 0, true, 'L', true);
		$pdf->writeHTMLCell(0, 0, '65px', '84px', $varUserName, '', 1, 0, true, 'L', true);
		$pdf->writeHTMLCell(0, 0, '98px', '112px', $varCourseName, '', 1, 0, true, 'L', true);

		ob_flush();
		$pdf->Output('Course_Completion_Certificate.pdf', 'I');
	}
?>