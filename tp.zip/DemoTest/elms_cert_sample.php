<?php
	require("elms_top_includes.php");
?>

<?php
	$varUserName = "";
	$varCourseName = "";
	$varCourseCD = "-";
	$varTempDate = "";
	$varRetURL = "elms_learner_course_report.php";
	
	$varUserName = $_SESSION["Elms_LoggedInUserName"];
	$varCourseName = "Test Course";
	$varCourseCatName = "Test Category";
	$varCourseSD = "2013-12-12";
	$varCourseCD = "2014-12-12";
	//$varRetURL = $_POST["txtReturnURL"];	
	
	/*if (!isset($_POST["txtUserName"])) {
		header("Location: index.php");
	} else {
		$varUserName = $_POST["txtUserName"];
		$varCourseName = $_POST["txtCourseName"];
		$varCourseCD = $_POST["txtCompletedDate"];
		$varRetURL = $_POST["txtReturnURL"];
	}*/
	
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<style>
			.clsDivCertificate {
				position: relative;
				width: 1157px;
				height: 818px;
				background: url(images/Certificate2_a1.jpg) no-repeat;
				border: 0px solid #cccccc;
				cursor: default;
			}
			.clsDivMessage {
				position: absolute;
				width: 77%;
				height: 300px;
				padding:0px 130px 0px 130px;
				left: 3px;
				top: 310px;
				font-family: Elegans Script SSi;
				font-size: 30px;
				font-weight: normal;
				text-align: left;
				line-height:150%;
				border: 0px solid #000000;
				display: block;
				cursor: default;
			}			
			.clsDivUserName {
				position: absolute;
				left: 90px;
				top: 330px;
				font-family: Elegans Script SSi;
				font-size: 35px;
				font-weight: bold;
				border: 0px solid #000000;
				display: inline-block;
				cursor: default;
			}
			.clsDivCourseName {
				position: absolute;
				left: 90px;
				top: 422px;
				font-family: Elegans Script SSi;
				font-size: 40px;
				border: 0px solid #000000;
				display: inline-block;
				cursor: default;
			}
			.clsDivCourseCD {
				position: absolute;
				left: 120px;
				top: 515px;
				font-family: Elegans Script SSi;
				font-size: 22px;
				border: 0px solid #000000;
				display: inline-block;
				cursor: default;
			}			
		</style>
		<script language="javascript">
			function doPrintAndDownload() {
				//document.frmPDF.action = "elms_certificate_html2pdf_view.php";
				//document.frmPDF.submit();
			}
		</script>
	</head>
	<body>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="center" valign="top" id="temp">
																	<div id="divCertificate" name="divCertificate" class="clsDivCertificate">
																		<div id="divMessage" name="divMessage" class="clsDivMessage">
																			<p><b><u><?php echo $varUserName; ?></u></b>&nbsp;In recognition of having successfully completed the course on&nbsp;
																			<b><u>Saint Gobain_FRG_Testing & Certification</u></b>&nbsp;
																			under the category <b><u>Saint Gobain_FRG_Product Range & Application</u></b></p>
																			<p align="center">
																			<?php
																				if ($varCourseSD=="-") {
																					echo $varCourseSD;
																				} else {
																					$varTempDate = new DateTime($varCourseSD);
																				}																			
																			?>																			
																			from <font size="5"><u><b><?php echo $varTempDate->format("d-M-Y"); ?></b></u></font>
																			<?php
																				if ($varCourseCD=="-") {
																					echo $varCourseCD;
																				} else {
																					$varTempDate = new DateTime($varCourseCD);
																					
																				}																			
																			?>																			
																			to <font size="5"><u><b><?php echo $varTempDate->format("d-M-Y"); ?></b></u></font>
																			</p>
																		</div>																	
																	</div>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
												<tr height="25">
													<td width="100%" align="center" colspan="3"></td>
												</tr>
												<tr>
													<td width="100%" align="center" colspan="3">
														<!--
														<input type="button" value="E-mail" class="clsActionButton" onclick="javascript:doEmail();" />
														<input type="button" value="Print/Download" class="clsActionButton" onclick="javascript:doPrintAndDownload();" />
														-->
														<input type="button" value="<< Back" class="clsActionButton" onclick="document.location.href='<?php echo $varRetURL; ?>';" />
														<form id="frmPDF" name="frmPDF" method="post" target="_blank">
															<input type="hidden" id="txtUserName" name="txtUserName" value="<?php echo $varUserName; ?>" />
															<input type="hidden" id="txtCourseName" name="txtCourseName" value="<?php echo $varCourseName; ?>" />
														</form>
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>