<?php
	require("elms_top_includes.php");
?>

<?php
	global $strCourseId, $strCourseName, $arrScormMain, $arrScormSco, $strFileName, $strScormReference, $strScormSummary, $strScormVersion, $strScormModified, $strScoManifest, $strScoOrganization, $strScoParent, $strScoIdentifier, $strScoHref, $strScoType, $strScoTitle, $strDoc, $strOrganizations, $strOrganization, $strItems, $strItem, $strTitles, $strTitle;
	global $strResourcesDatas,	$strParentItemIdentifier, $strItemIdentifier, $strItemIdentifierRef, $strItemIParams, $strResourceIdentifier, $strResourceType, $strResourceScormType, $strResourceHref, $strPageTitle, $intIsParent, $strCourseItemsVal, $strResourceIdentifier, $strResourceType, $strResourceScormType;
	global $intTempCount;

	$strCourseType = "SCORM";
	$strMessage = "";
	$strTempDir = "";
	$strUploadMaxFileSize = "";
	$intUploadMaxFileSize = 0;

	$varName = "";
	$varCat = "";
	$strCourseType = "";
	$varDesc = "";
	$varIsFree = "Y";
	$varIsCert = "Y";
	$varPrice = "";
	$varMemTyp = null;
	$varDiscount = "";
	$varThumbImgName = "course_thumb_default.png";
	$varImgUploadError = "";
	
	$varIsAssignCourse = "N";

	if (!isset($_FILES["txtCourseZip"])) {
		header("Location:index.php");
	} else {
		$varName = $_POST["txtName"];
		$varDDCat = $_POST["ddCat"];
		$varTxtCat = $_POST["txtCat"];
		$varTxtCat = str_replace("'", "\\'", trim($varTxtCat));
		$varCat = "";
		if ($varDDCat=="") {
			$tQuery = "SELECT category_id FROM elms_category_details WHERE category_name='" . trim($varTxtCat) . "'";
			$tUpdate = mysql_query($tQuery) or die (mysql_error());
			if (dbNumRows($tUpdate)>0) {
				$tRow = mysql_fetch_array($tUpdate);
				$varCat = $tRow["category_id"];
			} else {
				$strTQuery = "INSERT INTO elms_category_details(category_name,category_created) VALUES('" . $varTxtCat . "','" . date('Y-m-d') . "')";
				$rstTResult = mysql_query($strTQuery) or die (mysql_error());
				$varCat = dbInsertId();
			}
		} else {
			$varCat = $varDDCat;
		}
		$strCourseType = $_POST["ddType"];
		$varDesc = $_POST["txtDesc"];
		$varUserType = $_POST["txtUserType"];
		$varIsFree = $_POST["txtOfferType"];
		$varIsCert = $_POST["txtCertYN"];

		if ($varIsFree=="N") {
			$varPrice = $_POST["txtPrice"];
			$varDiscount = $_POST["txtDiscount"];
		}
		
		if ($varUserType=="InternalOnly") {
			if (isset($_POST["chkUserIMemType"])) {
				$varMemTyp = $_POST["chkUserIMemType"];
			}
		} else {
		if ($varUserType=="ExternalOnly") {
			if (isset($_POST["chkUserEMemType"])) {
				$varMemTyp = $_POST["chkUserEMemType"];
			}
		} else {
			if (isset($_POST["chkUserIEMemType"])) {
				$varMemTyp = $_POST["chkUserIEMemType"];
			}		
		} }

		if ($strCourseType=="SCORM") {
			//SCORM COURSE
			$tempQuery = "SELECT * FROM elms_course_details ORDER BY course_id DESC LIMIT 1";
			$qCheck = mysql_query($tempQuery) or die (mysql_error());
			$rowCheck = mysql_fetch_array($qCheck);
			$tempIncInt = 1;

			if ($rowCheck!=null || $rowCheck!="") {
				$tempIncInt = $tempIncInt+(int)$rowCheck["course_id"];
			}
		
			if (isset($_FILES["txtThumbImg"]) && $_FILES["txtThumbImg"]["name"]) {
				$strTargetPath = dirname(__FILE__) . "/images/course_catalog/";
				$strUploadMaxFileSize = ini_get('upload_max_filesize');
				$intUploadMaxFileSize = (int)substr($strUploadMaxFileSize, 0, -1);
				$intSourceFileSize = (int)(($_FILES['txtThumbImg']['size']/1024)/1024);		
				if ($intSourceFileSize < $intUploadMaxFileSize) {
					$strFilename = $_FILES["txtThumbImg"]["name"];
					$strSource = $_FILES["txtThumbImg"]["tmp_name"];
					$strType = $_FILES["txtThumbImg"]["type"];
					$strName = explode(".", $strFilename);
					$varRndId = doGenerateRNDNum(5, false, 'd');
					$tempFile = "course_thumb_" . $varRndId . "_" . $strName[0] . "." . $strName[1];
					$strUploadPath = $strTargetPath . $tempFile;
					if (move_uploaded_file($strSource, $strUploadPath)) {
						$varThumbImgName = $tempFile;
					} else {
						$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not upload the Image file. Please try again!";
						header("Location:elms_course_new.php");
					}
				} else {
					$_SESSION["Elms_ResMsg"] = "The upload Image file size is too large. Please try with the size of less than or equal to 2 MB.";
					header("Location:elms_course_new.php");
				}
			}
			if ($varImgUploadError=="") {
				$strCourseId = $tempIncInt;
				$strCourseName = $_POST["txtName"];
				$strTempDir = $strCourseId;

				switch (strlen($strCourseId)) {
					case 1:
						$strTempDir = "0000" . $strCourseId;
						break;
					case 2:
						$strTempDir = "000" . $strCourseId;
						break;
					case 3:
						$strTempDir = "00" . $strCourseId;
						break;
					case 4:
						$strTempDir = "0" . $strCourseId;
						break;
				}

				$strCurFilePath = dirname(__FILE__) . "/";
				$strNewDir = $strCurFilePath . "course/course_" . $strTempDir . "/";

				if (is_dir($strNewDir)) {
					doRemove($strNewDir);
				} else {
					mkdir($strNewDir, 0755);
				}

				$strTargetPath = $strNewDir;


				$strUploadMaxFileSize = ini_get('upload_max_filesize');
				$intUploadMaxFileSize = (int)substr($strUploadMaxFileSize, 0, -1);
				$intSourceFileSize = (int)(($_FILES['txtCourseZip']['size']/1024)/1024);

				if($intSourceFileSize < $intUploadMaxFileSize) {
					$strFilename = $_FILES["txtCourseZip"]["name"];
					$strSource = $_FILES["txtCourseZip"]["tmp_name"];
					$strType = $_FILES["txtCourseZip"]["type"];
					$strName = explode(".", $strFilename);
					$arrAcceptedTypes = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');

					foreach($arrAcceptedTypes as $mime_type) {
						if($mime_type == $strType) {
							$boolOK = true;
							break;
						}
					}

					$strUploadPath = $strTargetPath . $strFilename;  // change this to the correct site path

					if(move_uploaded_file($strSource, $strUploadPath)) {
						$zip = new ZipArchive();
						$x = $zip->open($strUploadPath);
						if ($x === true) {
							$zip->extractTo($strTargetPath); // change this to the correct site path
							$zip->close();
							unlink($strUploadPath);

							$intTempCount = 0;
							$arrScormMain = null;
							$arrScormSco = null;
							$strFileName = null;
							$strScormReference = null;
							$strScormSummary = null;
							$strScormVersion = null;
							$strScormModified = null;
							$strScoManifest = null;
							$strScoOrganization = null;
							$strScoParent = null;
							$strScoIdentifier = null;
							$strScoHref = null;
							$strScoType = null;
							$strScoTitle = null;
							$strDoc = null;
							$strOrganizations = null;
							$strOrganization = null;
							$strItems  = null;
							$strItem = null;
							$strTitles = null;
							$strTitle = null;

							$strResourcesDatas = null;
							$strParentItemIdentifier = null;
							$strItemIdentifier = null;
							$strItemIdentifierRef = null;
							$strItemIParams = null;
							$strResourceIdentifier = null;
							$strResourceType = null;
							$strResourceScormType = null;
							$strResourceHref = null;
							$strPageTitle = null;
							$intIsParent = 0;
							$strCourseItemsVal = null;
							$strResourceIdentifier = null;
							$strResourceType = null;
							$strResourceScormType = null;


							$intTempInc = 0;
							$strFileName = "course/course_" . $strTempDir . "/imsmanifest.xml";

							if (!file_exists($strFileName)) {
								doRemoveDir($strTargetPath);
								$_SESSION["Elms_ResMsg"] = "Invalid SCORM Course Package! The imsmanifest.xml not found in your Course Package. Please try again!";
								header("Location:elms_course_new.php");
							} else {
								$strScormReference = $strFileName;
								$strScormSummary = "Scorm Description";

								$strDoc = new DOMDocument();
								$strDoc->load($strFileName);

								$schemaversionNodes = $strDoc->getElementsByTagName('schemaversion');
								if ($schemaversionNodes->length == 0) {
									$strScormVersion =  $strDoc->getElementsByTagName("metadatascheme")->item(0)->nodeValue;
								} else {
									$strScormVersion =  $strDoc->getElementsByTagName("schemaversion")->item(0)->nodeValue;
								}

								$strScoManifest = $strDoc->getElementsByTagName("manifest")->item(0)->getAttribute("identifier");
								$strScormModified = date("m/d/Y");

								for ($i = 0; $i<$strDoc->childNodes->length; $i++) {
									if (strtoupper($strDoc->childNodes->item($i)->nodeName)=="MANIFEST") {
										$strTemp = $strDoc->childNodes->item($i)->childNodes;
									}
								}

								for ($i = 0; $i<$strTemp->length; $i++) {
									if ($strTemp->item($i)->nodeType!="3") {
										if (strtoupper($strTemp->item($i)->nodeName)=="RESOURCES") {
											$strResourcesDatas = $strTemp->item($i)->childNodes;
										}
									}
								}

								for ($i = 0; $i<$strTemp->length; $i++) {
									if ($strTemp->item($i)->nodeType!="3") {
										if (strtoupper($strTemp->item($i)->nodeName)=="ORGANIZATIONS") {
											$strOrganizations = $strTemp->item($i)->childNodes;
											for ($j = 0; $j<$strOrganizations->length; $j++) {
												if ($strOrganizations->item($j)->nodeType!="3") {
													if (strtoupper($strOrganizations->item($j)->nodeName)=="ORGANIZATION") {
														$strOrganization = $strOrganizations->item($j)->childNodes;
														for ($k = 0; $k<$strOrganization->length; $k++) {
															if ($strOrganization->item($k)->nodeType!="3") {
																if ($intTempInc==0) {
																	if (strtoupper($strOrganization->item($k)->nodeName)=="TITLE") {
																		$strTitle = $strOrganization->item($k)->nodeValue;
																		$strScoParent = "N/A";
																		$strScoIdentifier = "N/A";
																		$strScoHref = "N/A";
																		$strScoType = "N/A";
																	}
																} else {
																	doGetItemDetails($strOrganization, $strResourcesDatas);
																	break;
																}
																$intTempInc++;
															}
														}
													}
												}
											}
										}
									}
								}

								$strTitle = str_replace("'", "\\'", $strTitle);
								$strCourseName = str_replace("'", "\\'", $strCourseName);
								$strScormReference = str_replace("'", "\\'", $strScormReference);
								$strScormSummary = str_replace("'", "\\'", $strScormSummary);

								$strQuery = "INSERT INTO elms_scorm_main(course_id,scorm_name,scorm_reference,scorm_summary,scorm_version,scorm_date) VALUES($strCourseId,'$strTitle','$strScormReference','$strScormSummary','$strScormVersion','$strScormModified')";
								$rstQueryResult = mysql_query($strQuery);

								$tempCoursePath = "elms_course_player.php?CourseID=" . $strCourseId;

								$tempQuery = "ALTER TABLE elms_course_details AUTO_INCREMENT=" . $tempIncInt;
								$qAlter = mysql_query($tempQuery) or die (mysql_error());
								
								$varTempMemTypeList = "";
								if ($varMemTyp!=null) {
									for ($k=0; $k<count($varMemTyp); $k++) {
										$varTempMemTypeSpl = explode("~", $varMemTyp[$k]);
										if (count($varTempMemTypeSpl)==1) {
											if ($varTempMemTypeList=="") {
												$varTempMemTypeList = $varTempMemTypeSpl[0];
											} else {
												$varTempMemTypeList = $varTempMemTypeList . "~" . $varTempMemTypeSpl[0];
											}
										} else {
											if ($varTempMemTypeList=="") {
												$varTempMemTypeList = $varTempMemTypeSpl[0] . "~" . $varTempMemTypeSpl[1];
											} else {
												$varTempMemTypeList = $varTempMemTypeList . "~" . $varTempMemTypeSpl[0] . "~" . $varTempMemTypeSpl[1];
											}										
										}
									}
								}
								$tempQuery = "INSERT INTO elms_course_details(course_dis_price,course_cat,course_name,course_desc,course_type,course_isfree,course_iscert,course_price,course_image,course_path,course_for,course_created,course_mem_type) VALUES('" . $varDiscount . "'," . $varCat . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . str_replace("'", "\\'", $_POST["txtDesc"]) . "','" . $strCourseType . "','" . $varIsFree . "','" . $varIsCert . "','" . $varPrice . "','" . $varThumbImgName . "','" . str_replace("'", "\\'", $tempCoursePath) . "','" . $varUserType . "','" . date('Y-m-d') . "','" . $varTempMemTypeList . "')";
								$qUpdate = mysql_query($tempQuery) or die (mysql_error());

								$intTempInsertedId = dbInsertId();
								
								
								/* Course Assigning */
								/* User Section */
								if ($varIsAssignCourse=="Y") {
									if ($varUserType=="InternalOnly") {
										$tQuery = "SELECT user_id FROM elms_user_details WHERE user_role<>'Admin' AND user_type='Internal'";
									} else {
										if ($varIsFree=="Y") {
											$tQuery = "SELECT user_id FROM elms_user_details WHERE user_role<>'Admin'";
										} else {
											$tQuery = "SELECT user_id FROM elms_user_details WHERE user_role<>'Admin' AND user_type='Internal'";
										}
									}
									$varTempJOINSQL = " AND (";
									if ($varMemTyp!=null) {
										for ($k=0; $k<count($varMemTyp); $k++) {
											$varTempMemTypeSpl = explode("~", $varMemTyp[$k]);
											if (count($varTempMemTypeSpl)==1) {
												if ($varTempJOINSQL==" AND (") {
													$varTempJOINSQL = $varTempJOINSQL . "user_mem_type=" . $varTempMemTypeSpl[0];
												} else {
													$varTempJOINSQL = $varTempJOINSQL . " OR user_mem_type=" . $varTempMemTypeSpl[0];
												}
											} else {
												if ($varTempJOINSQL==" AND (") {
													$varTempJOINSQL = $varTempJOINSQL . "user_mem_type=" . $varTempMemTypeSpl[0] . " OR user_mem_type=" . $varTempMemTypeSpl[1];
												} else {
													$varTempJOINSQL = $varTempJOINSQL . " OR user_mem_type=" . $varTempMemTypeSpl[0] . " OR user_mem_type=" . $varTempMemTypeSpl[1];
												}										
											}
										}
									}								
									
									$varTempJOINSQL = $varTempJOINSQL . ")";
									if ($varTempJOINSQL!=" AND ()") {
										$tQuery = $tQuery . $varTempJOINSQL;
									}
									$tResult = mysql_query($tQuery) or die (mysql_error());
									while ($row = mysql_fetch_array($tResult)) {
										$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $row["user_id"] . " AND course_id=" . $intTempInsertedId;
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
										$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $row["user_id"] . " AND course_id=" . $intTempInsertedId;
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());									
										
										$tempQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $row["user_id"] . "," . $intTempInsertedId . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . date('Y-m-d') . "')";
										$qUpdate = mysql_query($tempQuery) or die (mysql_error());
									}
									
									/* Group Wise Section */
									if ($varMemTyp==null) {
										if ($varUserType=="InternalOnly") {
											$tQuery = "SELECT group_id FROM elms_group_details WHERE group_type='Internal'";
										} else {
											if ($varIsFree=="Y") {
												$tQuery = "SELECT group_id FROM elms_group_details WHERE group_type='Internal'";
											} else {
												$tQuery = "SELECT group_id FROM elms_group_details WHERE group_type='Internal'";
											}
										}
										$tResult = mysql_query($tQuery) or die (mysql_error());
										while ($row = mysql_fetch_array($tResult)) {
											$tDelQuery = "DELETE FROM elms_assigned_courses_group_wise WHERE group_id=" . $row["group_id"] . " AND course_id=" . $intTempInsertedId;
											$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
											$tempQuery = "INSERT INTO elms_assigned_courses_group_wise(group_id,course_id,course_name,assigned_date) VALUES(" . $row["group_id"] . "," . $intTempInsertedId . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . date('Y-m-d') . "')";
											$qUpdate = mysql_query($tempQuery) or die (mysql_error());								
										}
									}
								}
								
								/* Admin Section */
								$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $_SESSION["Elms_LoggedInId"] . " AND course_id=" . $intTempInsertedId;
								$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
								$tempQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $_SESSION["Elms_LoggedInId"] . "," . $intTempInsertedId . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . date('Y-m-d') . "')";
								$qUpdate = mysql_query($tempQuery) or die (mysql_error());
								/* Course Assigning */								

								if ($qUpdate) {
									header("Location:elms_course_list.php");
								} else {
									doRemoveDir($strTargetPath);
									$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not update the Course details. Please try again!";
									header("Location:elms_course_new.php");									
								}
							}
						} else {
							doRemoveDir($strTargetPath);
							$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not extract the Course zip file. Please try again.";
							header("Location:elms_course_new.php");							
						}
					} else {
						doRemoveDir($strNewDir);
						$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not upload the Course Zip file. Please try again.";
						header("Location:elms_course_new.php");						
					}
				} else {
					doRemoveDir($strNewDir);
					$_SESSION["Elms_ResMsg"] = "The upload Course Zip file size is too large. Please try with the size of less than or equal to " . ($intUploadMaxFileSize-1) ." MB.";
					header("Location:elms_course_new.php");					
				}
			} else {
			}
		} else {
			//NORMAL WEB COURSE
			$tempQuery = "SELECT * FROM elms_course_details ORDER BY course_id DESC LIMIT 1";
			$qCheck = mysql_query($tempQuery) or die (mysql_error());
			$rowCheck = mysql_fetch_array($qCheck);
			$tempIncInt = 1;

			if ($rowCheck!=null || $rowCheck!="") {
				$tempIncInt = $tempIncInt+(int)$rowCheck["course_id"];
			}
		
			if (isset($_FILES["txtThumbImg"]) && $_FILES["txtThumbImg"]["name"]) {
				$strTargetPath = dirname(__FILE__) . "/images/course_catalog/";
				$strUploadMaxFileSize = ini_get('upload_max_filesize');
				$intUploadMaxFileSize = (int)substr($strUploadMaxFileSize, 0, -1);
				$intSourceFileSize = (int)(($_FILES['txtThumbImg']['size']/1024)/1024);		
				if ($intSourceFileSize < $intUploadMaxFileSize) {
					$strFilename = $_FILES["txtThumbImg"]["name"];
					$strSource = $_FILES["txtThumbImg"]["tmp_name"];
					$strType = $_FILES["txtThumbImg"]["type"];
					$strName = explode(".", $strFilename);
					$varRndId = doGenerateRNDNum(5, false, 'd');
					$tempFile = "course_thumb_" . $varRndId . "_" . $strName[0] . "." . $strName[1];
					$strUploadPath = $strTargetPath . $tempFile;
					if (move_uploaded_file($strSource, $strUploadPath)) {
						$varThumbImgName = $tempFile;
					} else {
						$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not upload the Image file. Please try again!";
						header("Location:elms_course_new.php");
					}
				} else {
					$_SESSION["Elms_ResMsg"] = "The upload Image file size is too large. Please try with the size of less than or equal to 2 MB.";
					header("Location:elms_course_new.php");
				}
			}
			if ($varImgUploadError=="") {
				$strCourseId = $tempIncInt;
				$strCourseName = $_POST["txtName"];
				$strTempDir = $strCourseId;

				switch (strlen($strCourseId)) {
					case 1:
						$strTempDir = "0000" . $strCourseId;
						break;
					case 2:
						$strTempDir = "000" . $strCourseId;
						break;
					case 3:
						$strTempDir = "00" . $strCourseId;
						break;
					case 4:
						$strTempDir = "0" . $strCourseId;
						break;
				}

				$strCurFilePath = dirname(__FILE__) . "/";
				$strNewDir = $strCurFilePath . "course/course_" . $strTempDir . "/";

				if (is_dir($strNewDir)) {
					doRemove($strNewDir);
				} else {
					mkdir($strNewDir, 0755);
				}

				$strTargetPath = $strNewDir;


				$strUploadMaxFileSize = ini_get('upload_max_filesize');
				$intUploadMaxFileSize = (int)substr($strUploadMaxFileSize, 0, -1);
				$intSourceFileSize = (int)(($_FILES['txtCourseZip']['size']/1024)/1024);

				if($intSourceFileSize < $intUploadMaxFileSize) {
					$strFilename = $_FILES["txtCourseZip"]["name"];
					$strSource = $_FILES["txtCourseZip"]["tmp_name"];
					$strType = $_FILES["txtCourseZip"]["type"];
					$strName = explode(".", $strFilename);
					$arrAcceptedTypes = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');

					foreach($arrAcceptedTypes as $mime_type) {
						if($mime_type == $strType) {
							$boolOK = true;
							break;
						}
					}

					$strUploadPath = $strTargetPath . $strFilename;  // change this to the correct site path

					if(move_uploaded_file($strSource, $strUploadPath)) {
						$zip = new ZipArchive();
						$x = $zip->open($strUploadPath);
						if ($x === true) {
							$zip->extractTo($strTargetPath); // change this to the correct site path
							$zip->close();
							unlink($strUploadPath);
							
							$strFileName = "course/course_" . $strTempDir . "/player.html";
							if (!file_exists($strFileName)) {
								doRemoveDir($strTargetPath);
								$_SESSION["Elms_ResMsg"] = "The Launch file <b>player.html</b> not found in your Course Package root. Please try again!";
								header("Location:elms_course_new.php");								
							} else {							
								$tempCoursePath = "elms_course_player.php?CourseID=" . $strCourseId;

								$tempQuery = "ALTER TABLE elms_course_details AUTO_INCREMENT=" . $tempIncInt;
								$qAlter = mysql_query($tempQuery) or die (mysql_error());

								$varTempMemTypeList = "";
								if ($varMemTyp!=null) {
									for ($k=0; $k<count($varMemTyp); $k++) {
										$varTempMemTypeSpl = explode("~", $varMemTyp[$k]);
										if (count($varTempMemTypeSpl)==1) {
											if ($varTempMemTypeList=="") {
												$varTempMemTypeList = $varTempMemTypeSpl[0];
											} else {
												$varTempMemTypeList = $varTempMemTypeList . "~" . $varTempMemTypeSpl[0];
											}
										} else {
											if ($varTempMemTypeList=="") {
												$varTempMemTypeList = $varTempMemTypeSpl[0] . "~" . $varTempMemTypeSpl[1];
											} else {
												$varTempMemTypeList = $varTempMemTypeList . "~" . $varTempMemTypeSpl[0] . "~" . $varTempMemTypeSpl[1];
											}										
										}
									}
								}
								
								$tempQuery = "INSERT INTO elms_course_details(course_dis_price,course_cat,course_name,course_desc,course_type,course_isfree,course_iscert,course_price,course_image,course_path,course_for,course_created,course_mem_type) VALUES('" . $varDiscount . "'," . $varCat . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . str_replace("'", "\\'", $_POST["txtDesc"]) . "','" . $strCourseType . "','" . $varIsFree . "','" . $varIsCert . "','" . $varPrice . "','" . $varThumbImgName . "','" . str_replace("'", "\\'", $tempCoursePath) . "','" . $varUserType . "','" . date('Y-m-d') . "','" . $varTempMemTypeList . "')";
								$qUpdate = mysql_query($tempQuery) or die (mysql_error());

								$intTempInsertedId = dbInsertId();
								
								/* Course Assigning */
								/* User Section */
								if ($varIsAssignCourse=="Y") {
									if ($varUserType=="InternalOnly") {
										$tQuery = "SELECT user_id FROM elms_user_details WHERE user_role<>'Admin' AND user_type='Internal'";
									} else {
										if ($varIsFree=="Y") {
											$tQuery = "SELECT user_id FROM elms_user_details WHERE user_role<>'Admin'";
										} else {
											$tQuery = "SELECT user_id FROM elms_user_details WHERE user_role<>'Admin' AND user_type='Internal'";
										}
									}
									$varTempJOINSQL = " AND (";
									if ($varMemTyp!=null) {
										for ($k=0; $k<count($varMemTyp); $k++) {
											if ($varTempJOINSQL==" AND (") {
												$varTempJOINSQL = $varTempJOINSQL . "user_mem_type=" . $varMemTyp[$k];
											} else {
												$varTempJOINSQL = $varTempJOINSQL . " OR user_mem_type=" . $varMemTyp[$k];
											}
										}
									}
									$varTempJOINSQL = $varTempJOINSQL . ")";
									if ($varTempJOINSQL!=" AND ()") {
										$tQuery = $tQuery . $varTempJOINSQL;
									}
									$tResult = mysql_query($tQuery) or die (mysql_error());
									while ($row = mysql_fetch_array($tResult)) {
										$tDelQuery = "DELETE FROM elms_course_scorm_track WHERE user_id=" . $row["user_id"] . " AND course_id=" . $intTempInsertedId;
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
										$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $row["user_id"] . " AND course_id=" . $intTempInsertedId;
										$tDelResult = mysql_query($tDelQuery) or die (mysql_error());									
										
										$tempQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $row["user_id"] . "," . $intTempInsertedId . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . date('Y-m-d') . "')";
										$qUpdate = mysql_query($tempQuery) or die (mysql_error());
									}
									
									/* Group Wise Section */
									if ($varMemTyp==null) {
										if ($varUserType=="InternalOnly") {
											$tQuery = "SELECT group_id FROM elms_group_details WHERE group_type='Internal'";
										} else {
											if ($varIsFree=="Y") {
												$tQuery = "SELECT group_id FROM elms_group_details WHERE group_type='Internal'";
											} else {
												$tQuery = "SELECT group_id FROM elms_group_details WHERE group_type='Internal'";
											}
										}
										$tResult = mysql_query($tQuery) or die (mysql_error());
										while ($row = mysql_fetch_array($tResult)) {
											$tDelQuery = "DELETE FROM elms_assigned_courses_group_wise WHERE group_id=" . $row["group_id"] . " AND course_id=" . $intTempInsertedId;
											$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
											$tempQuery = "INSERT INTO elms_assigned_courses_group_wise(group_id,course_id,course_name,assigned_date) VALUES(" . $row["group_id"] . "," . $intTempInsertedId . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . date('Y-m-d') . "')";
											$qUpdate = mysql_query($tempQuery) or die (mysql_error());								
										}
									}
								}
								
								/* Admin Section */
								$tDelQuery = "DELETE FROM elms_assigned_courses WHERE user_id=" . $_SESSION["Elms_LoggedInId"] . " AND course_id=" . $intTempInsertedId;
								$tDelResult = mysql_query($tDelQuery) or die (mysql_error());
										
								$tempQuery = "INSERT INTO elms_assigned_courses(user_id,course_id,course_name,assigned_date) VALUES(" . $_SESSION["Elms_LoggedInId"] . "," . $intTempInsertedId . ",'" . str_replace("'", "\\'", $_POST["txtName"]) . "','" . date('Y-m-d') . "')";
								$qUpdate = mysql_query($tempQuery) or die (mysql_error());
								/* Course Assigning */								

								if ($qUpdate) {
									header("Location:elms_course_list.php");
								} else {
									doRemoveDir($strTargetPath);
									$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not update the Course details. Please try again!";
									header("Location:elms_course_new.php");
								}
							}
						} else {
							doRemoveDir($strTargetPath);
							$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not extract the Course zip file. Please try again.";
							header("Location:elms_course_new.php");
						}
					} else {
						doRemoveDir($strNewDir);
						$_SESSION["Elms_ResMsg"] = "Unfortunately the system could not upload the Course Zip file. Please try again.";
						header("Location:elms_course_new.php");
					}
				} else {
					doRemoveDir($strNewDir);
					$_SESSION["Elms_ResMsg"] = "The upload Course Zip file size is too large. Please try with the size of less than or equal to " . ($intUploadMaxFileSize-1) ." MB.";
					header("Location:elms_course_new.php");
				}
			} else {
			}			
		}
	}
?>

<?php
	function doRemoveDir($dirname) {
        if (is_dir($dirname))
        $dir_handle = opendir($dirname);
        if (!$dir_handle)
        return false;
        while($file = readdir($dir_handle)) {
            if ($file != "." && $file != "..") {
                if (!is_dir($dirname."/".$file))
                unlink($dirname."/".$file);
                else
                {
                    $a=$dirname.'/'.$file;
                    doRemoveDir($a);
                }
            }
        }
        closedir($dir_handle);
        rmdir($dirname);
        return true;
    }

	function doRemove($strTempDir) {
		$strMyDir = opendir($strTempDir);
		while(false !== ($file = readdir($strMyDir))) {
			if($file != "." && $file != "..") {
				chmod($strTempDir.$file, 0777);
				if(is_dir($strTempDir.$file)) {
					chdir('.');
					doRemove($strTempDir.$file.'/');
					rmdir($strTempDir.$file) or die("Couldn't delete $strTempDir$file<br />");
				}
				else
					unlink($strTempDir.$file) or die("Couldn't delete $strTempDir$file<br />");
			}
		}
		closedir($strMyDir);
	}

	function doGetItemDetails($strXMLNode, $strTempResourcesDatas) {
		global $intTempCount;
		for ($i = 0; $i<$strXMLNode->length; $i++) {
			global $arrDatas, $strResourcesDatas, $strCourseId, $strParentItemIdentifier, $strItemIdentifier, $strItemIdentifierRef, $strItemIParams, $strResourceIdentifier, $strResourceType, $strResourceScormType, $strResourceHref, $strPageTitle, $intIsParent, $strCourseItemsVal;

			$strResourcesDatas = $strTempResourcesDatas;
			$strParentItemIdentifier = "Undefined";
			$strItemIdentifier = "Undefined";
			$strItemIdentifierRef = "Undefined";
			$strItemIParams = "Undefined";
			$strResourceIdentifier = "Undefined";
			$strResourceType = "Undefined";
			$strResourceScormType = "Undefined";
			$strResourceHref = "Undefined";
			$strPageTitle = "Undefined";
			$intIsParent = 0;
			$strCourseItemsVal = "Undefined";
			if ($strXMLNode->item($i)->nodeType!="3") {
				if (strtoupper($strXMLNode->item($i)->nodeName)=="ITEM") {
					$boolFound = false;
					for ($j = 0; $j<$strXMLNode->item($i)->childNodes->length; $j++) {
						if ($strXMLNode->item($i)->childNodes->item($j)->nodeType!="3") {
							if (strtoupper($strXMLNode->item($i)->childNodes->item($j)->nodeName)=="TITLE") {
								$boolFound = true;
								$strPageTitle = $strXMLNode->item($i)->childNodes->item($j)->nodeValue;
								break;
							}
						}
					}
					if ($boolFound) {
						if ($strXMLNode->item($i)->parentNode!=null) {
							if ($strXMLNode->item($i)->parentNode->nodeType!="3"){
								if (strtoupper($strXMLNode->item($i)->parentNode->nodeName)!="ORGANIZATION") {
									if ($strXMLNode->item($i)->parentNode->getAttribute("identifier")!=null) {
										$strParentItemIdentifier = $strXMLNode->item($i)->parentNode->getAttribute("identifier");
									}
								}
							}
						}

						if ($strXMLNode->item($i)->nodeType!="3"){
							if ($strXMLNode->item($i)->getAttribute("identifier")!=null) {
								$strItemIdentifier = $strXMLNode->item($i)->getAttribute("identifier");
							}
						}
						if ($strXMLNode->item($i)->nodeType!="3"){
							if ($strXMLNode->item($i)->getAttribute("identifierref")!=null) {
								$strItemIdentifierRef = $strXMLNode->item($i)->getAttribute("identifierref");
							}
						}
						if ($strXMLNode->item($i)->nodeType!="3"){
							if ($strXMLNode->item($i)->getAttribute("parameters")!=null) {
								$strItemIParams = $strXMLNode->item($i)->getAttribute("parameters");
							}
						}
						if ($strItemIdentifierRef!="" && $strItemIdentifierRef!="Undefined" && $strItemIdentifierRef!=null) {
							doGetItemResourceValues($strResourcesDatas, $strItemIdentifierRef, $strCourseId);
						}
						if ($strResourceHref=="" || $strResourceHref=="Undefined") {
							$intIsParent = 1;
						}
						$strCourseItemsVal = str_replace("'", "\\'", $strParentItemIdentifier) . "~" . str_replace("'", "\\'", $strCourseId) . "~" . str_replace("'", "\\'", $strItemIdentifier) . "~" . str_replace("'", "\\'", $strItemIdentifierRef) . "~" . str_replace("'", "\\'", $strItemIParams) . "~" . str_replace("'", "\\'", $strResourceIdentifier) . "~" . str_replace("'", "\\'", $strResourceType) . "~" . str_replace("'", "\\'", $strResourceScormType) . "~" . str_replace("'", "\\'", $strResourceHref) . "~" . str_replace("'", "\\'", $strPageTitle) . "~" . $intIsParent . "~" . 0;
						$arrDatas = explode("~", $strCourseItemsVal);

						$rstQueryResult = mysql_query("set names 'utf8'");
						$strQuery = "INSERT INTO elms_course_page_details(parent_item_identifier, course_id, item_identifier, item_identifier_ref, item_params, resource_identifier, resource_type, resource_scorm_type, resource_href, page_title, is_parent, is_browsed) VALUES('$arrDatas[0]', '$arrDatas[1]', '$arrDatas[2]', '$arrDatas[3]', '$arrDatas[4]', '$arrDatas[5]', '$arrDatas[6]', '$arrDatas[7]', '$arrDatas[8]', '$arrDatas[9]', $arrDatas[10], $arrDatas[11])";
						$rstQueryResult = mysql_query($strQuery);
						$intTempCount++;
					}
					doGetItemDetails($strXMLNode->item($i)->childNodes, $strResourcesDatas);
				}
			}
		}
	}

	function doGetItemResourceValues($strXMLNode, $strTempItemRef, $strTempCourseId) {
		$strTempDir = "";
		for ($i = 0; $i<$strXMLNode->length; $i++) {
			if ($strXMLNode->item($i)->nodeType!="3") {
				if (strtoupper($strXMLNode->item($i)->nodeName)=="RESOURCE") {
					if ($strXMLNode->item($i)->getAttribute("identifier")!=null) {
						if ($strXMLNode->item($i)->getAttribute("identifier")==$strTempItemRef) {
							global $strResourceIdentifier, $strResourceType, $strResourceScormType, $strResourceHref;

							$strResourceIdentifier = $strXMLNode->item($i)->getAttribute("identifier");
							if ($strXMLNode->item($i)->getAttribute("type")!=null) {
								$strResourceType = $strXMLNode->item($i)->getAttribute("type");
							}
							if ($strXMLNode->item($i)->getAttribute("adlcp:scormtype")!=null) {
								$strResourceScormType = $strXMLNode->item($i)->getAttribute("adlcp:scormtype");
							}
							if ($strXMLNode->item($i)->getAttribute("href")!=null) {
								$strTempDir = $strTempCourseId;
								switch (strlen($strTempCourseId)) {
									case 1:
										$strTempDir = "0000" . $strTempCourseId;
										break;
									case 2:
										$strTempDir = "000" . $strTempCourseId;
										break;
									case 3:
										$strTempDir = "00" . $strTempCourseId;
										break;
									case 4:
										$strTempDir = "0" . $strTempCourseId;
										break;
								}
								if ($strXMLNode->item($i)->getAttribute("xml:base")!=null) {
									$strResourceHref = "course/course_" . $strTempDir . "/" . $strXMLNode->item($i)->getAttribute("xml:base") . $strXMLNode->item($i)->getAttribute("href");
								} else {
									$strResourceHref = "course/course_" . $strTempDir . "/" . $strXMLNode->item($i)->getAttribute("href");
								}
							}
							break;
						}
					}
				}
			}
		}
	}
?>