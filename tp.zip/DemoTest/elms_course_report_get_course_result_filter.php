<?php
	require("elms_top_includes.php");
?>

<?php
	$strMessage = "";
	$varID = 0;
	$varManager = "";
	$varGroup = "";
	$varResult = "";
	$varArrName = "";
	$varArrResult = "";

	if (!isset($_POST["ID"])) {
		header("Location:index.php");
	} else {
		$varID = $_POST["ID"];
		$varManager = $_POST["Manager"];
		$varGroup = $_POST["Group"];
		$varResult = $_POST["Result"];
		if ($varManager=="" && $varGroup=="" && $varResult=="") {
			$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
				$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
				while ($tRowSub = mysql_fetch_array($tResultSub)) {
					$varTempUserName = "";
					$varTempResult = "";

					$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempUserName = $tRow["user_fname"];

					$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempResult = $tRow["status"];
					switch (strtoupper($varTempResult)) {
						case "COMPLETED":
							$varTempResult = "Completed";
							break;
						case "PASSED":
							$varTempResult = "Completed";
							break;
						case "INCOMPLETE":
							$varTempResult = "In Progress";
							break;
						case "FAILED":
							$varTempResult = "In Progress";
							break;
						case "NOT ATTEMPTED":
							$varTempResult = "Not Started";
							break;						
					}					

					if ($varTempUserName!="" && $varTempResult=="") {
						$varTempResult = "Not Started";
					}

					if ($varTempUserName!="" && $varTempResult!="") {
						if ($varArrName=="") {
							$varArrName = $varTempUserName;
						} else {
							$varArrName = $varArrName . "~" . $varTempUserName;
						}
						if ($varArrResult=="") {
							$varArrResult = $varTempResult;
						} else {
							$varArrResult = $varArrResult . "~" . $varTempResult;
						}
					}
				}
			}
		} else {
		if ($varManager!="" && $varGroup=="" && $varResult=="") {
			$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
				$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
				while ($tRowSub = mysql_fetch_array($tResultSub)) {
					$varTempUserName = "";
					$varTempResult = "";

					$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempUserName = $tRow["user_fname"];

					$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
					$tResult = mysql_query($tQuery) or die (mysql_error());
					$tRow = mysql_fetch_array($tResult);
					$varTempResult = $tRow["status"];
					switch (strtoupper($varTempResult)) {
						case "COMPLETED":
							$varTempResult = "Completed";
							break;
						case "PASSED":
							$varTempResult = "Completed";
							break;
						case "INCOMPLETE":
							$varTempResult = "In Progress";
							break;
						case "FAILED":
							$varTempResult = "In Progress";
							break;
						case "NOT ATTEMPTED":
							$varTempResult = "Not Started";
							break;						
					}					

					if ($varTempUserName!="" && $varTempResult=="") {
						$varTempResult = "Not Started";
					}

					if ($varTempUserName!="" && $varTempResult!="") {
						if ($varArrName=="") {
							$varArrName = $varTempUserName;
						} else {
							$varArrName = $varArrName . "~" . $varTempUserName;
						}
						if ($varArrResult=="") {
							$varArrResult = $varTempResult;
						} else {
							$varArrResult = $varArrResult . "~" . $varTempResult;
						}
					}
				}
			}
		} else {
		if ($varManager!="" && $varGroup!="" && $varResult=="") {
			$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
				$tempResult = mysql_query($tempQuery) or die (mysql_error());
				while ($tempRow = mysql_fetch_array($tempResult)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						

						if ($varTempUserName!="" && $varTempResult=="") {
							$varTempResult = "Not Started";
						}

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			}
		} else {
		if ($varManager!="" && $varGroup!="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];
							switch (strtoupper($varTempResult)) {
								case "COMPLETED":
									$varTempResult = "Completed";
									break;
								case "PASSED":
									$varTempResult = "Completed";
									break;
								case "INCOMPLETE":
									$varTempResult = "In Progress";
									break;
								case "FAILED":
									$varTempResult = "In Progress";
									break;
								case "NOT ATTEMPTED":
									$varTempResult = "Not Started";
									break;						
							}							

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];
							switch (strtoupper($varTempResult)) {
								case "COMPLETED":
									$varTempResult = "Completed";
									break;
								case "PASSED":
									$varTempResult = "Completed";
									break;
								case "INCOMPLETE":
									$varTempResult = "In Progress";
									break;
								case "FAILED":
									$varTempResult = "In Progress";
									break;
								case "NOT ATTEMPTED":
									$varTempResult = "Not Started";
									break;						
							}							

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];
							switch (strtoupper($varTempResult)) {
								case "COMPLETED":
									$varTempResult = "Completed";
									break;
								case "PASSED":
									$varTempResult = "Completed";
									break;
								case "INCOMPLETE":
									$varTempResult = "In Progress";
									break;
								case "FAILED":
									$varTempResult = "In Progress";
									break;
								case "NOT ATTEMPTED":
									$varTempResult = "Not Started";
									break;						
							}							


							if ($varTempUserName!="" && $varTempResult=="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = "Not Started";
								} else {
									$varArrResult = $varArrResult . "~" . "Not Started";
								}
							}
						}
					}
				}
			} } }
		} else {
		if ($varManager=="" && $varGroup!="" && $varResult=="") {
			$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
			$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
			while ($tRowMain = mysql_fetch_array($tResultMain)) {
				$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
				$tempResult = mysql_query($tempQuery) or die (mysql_error());
				while ($tempRow = mysql_fetch_array($tempResult)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID;
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						

						if ($varTempUserName!="" && $varTempResult=="") {
							$varTempResult = "Not Started";
						}

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			}
		} else {
		if ($varManager=="" && $varGroup=="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						

						if ($varTempUserName!="" && $varTempResult=="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = "Not Started";
							} else {
								$varArrResult = $varArrResult . "~" . "Not Started";
							}
						}
					}
				}
			} } }
		} else {
		if ($varManager=="" && $varGroup!="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];
							switch (strtoupper($varTempResult)) {
								case "COMPLETED":
									$varTempResult = "Completed";
									break;
								case "PASSED":
									$varTempResult = "Completed";
									break;
								case "INCOMPLETE":
									$varTempResult = "In Progress";
									break;
								case "FAILED":
									$varTempResult = "In Progress";
									break;
								case "NOT ATTEMPTED":
									$varTempResult = "Not Started";
									break;						
							}							

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];
							switch (strtoupper($varTempResult)) {
								case "COMPLETED":
									$varTempResult = "Completed";
									break;
								case "PASSED":
									$varTempResult = "Completed";
									break;
								case "INCOMPLETE":
									$varTempResult = "In Progress";
									break;
								case "FAILED":
									$varTempResult = "In Progress";
									break;
								case "NOT ATTEMPTED":
									$varTempResult = "Not Started";
									break;						
							}							

							if ($varTempUserName!="" && $varTempResult!="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = $varTempResult;
								} else {
									$varArrResult = $varArrResult . "~" . $varTempResult;
								}
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT DISTINCT ELMSUserDetailsList.user_id AS user_id, ELMSUserDetailsList.user_role AS user_role, ELMSUserDetailsList.user_email AS user_email, ELMSUserDetailsList.user_fname AS user_fname, ELMSUserDetailsList.user_status AS user_status, ELMSUserDetailsList.user_created AS user_created, ELMSUserDetailsReportingTo.user_fname AS reports_to FROM elms_user_details ELMSUserDetailsList INNER JOIN elms_user_details ELMSUserDetailsReportingTo ON ELMSUserDetailsList.user_head = ELMSUserDetailsReportingTo.user_id WHERE (ELMSUserDetailsReportingTo.user_head=" . $_SESSION["Elms_LoggedInId"] . " OR ELMSUserDetailsList.user_head=" . $_SESSION["Elms_LoggedInId"] . ") AND ELMSUserDetailsList.user_role='User' ORDER BY ELMSUserDetailsList.user_fname";
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tempQuery = "SELECT user_id FROM elms_assigned_groups WHERE group_id=" . $varGroup . " AND user_id=" . $tRowMain["user_id"];
					$tempResult = mysql_query($tempQuery) or die (mysql_error());
					while ($tempRow = mysql_fetch_array($tempResult)) {
						$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tempRow["user_id"];
						$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
						while ($tRowSub = mysql_fetch_array($tResultSub)) {
							$varTempUserName = "";
							$varTempResult = "";

							$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempUserName = $tRow["user_fname"];

							$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
							$tResult = mysql_query($tQuery) or die (mysql_error());
							$tRow = mysql_fetch_array($tResult);
							$varTempResult = $tRow["status"];
							switch (strtoupper($varTempResult)) {
								case "COMPLETED":
									$varTempResult = "Completed";
									break;
								case "PASSED":
									$varTempResult = "Completed";
									break;
								case "INCOMPLETE":
									$varTempResult = "In Progress";
									break;
								case "FAILED":
									$varTempResult = "In Progress";
									break;
								case "NOT ATTEMPTED":
									$varTempResult = "Not Started";
									break;						
							}							


							if ($varTempUserName!="" && $varTempResult=="") {
								if ($varArrName=="") {
									$varArrName = $varTempUserName;
								} else {
									$varArrName = $varArrName . "~" . $varTempUserName;
								}
								if ($varArrResult=="") {
									$varArrResult = "Not Started";
								} else {
									$varArrResult = $varArrResult . "~" . "Not Started";
								}
							}
						}
					}
				}
			} } }
		} else {
		if ($varManager!="" && $varGroup=="" && $varResult!="") {
			if ($varResult=="COMPLETED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="INCOMPLETE") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						

						if ($varTempUserName!="" && $varTempResult!="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = $varTempResult;
							} else {
								$varArrResult = $varArrResult . "~" . $varTempResult;
							}
						}
					}
				}
			} else {
			if ($varResult=="NOTATTEMPTED") {
				$tQueryMain = "SELECT user_id FROM elms_user_details WHERE user_role='User' AND user_head=" . $varManager;
				$tResultMain = mysql_query($tQueryMain) or die (mysql_error());
				while ($tRowMain = mysql_fetch_array($tResultMain)) {
					$tQuerySub = "SELECT user_id FROM elms_assigned_courses WHERE course_id=" . $varID . " AND user_id=" . $tRowMain["user_id"];
					$tResultSub = mysql_query($tQuerySub) or die (mysql_error());
					while ($tRowSub = mysql_fetch_array($tResultSub)) {
						$varTempUserName = "";
						$varTempResult = "";

						$tQuery = "SELECT user_fname FROM elms_user_details WHERE user_id=" . $tRowSub["user_id"];
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempUserName = $tRow["user_fname"];

						$tQuery = "SELECT status FROM elms_course_scorm_track WHERE user_id=" . $tRowSub["user_id"] . " AND course_id=" . $varID . " AND (status='COMPLETED' OR status='PASSED' OR status='INCOMPLETE' OR status='FAILED')";
						$tResult = mysql_query($tQuery) or die (mysql_error());
						$tRow = mysql_fetch_array($tResult);
						$varTempResult = $tRow["status"];
						switch (strtoupper($varTempResult)) {
							case "COMPLETED":
								$varTempResult = "Completed";
								break;
							case "PASSED":
								$varTempResult = "Completed";
								break;
							case "INCOMPLETE":
								$varTempResult = "In Progress";
								break;
							case "FAILED":
								$varTempResult = "In Progress";
								break;
							case "NOT ATTEMPTED":
								$varTempResult = "Not Started";
								break;						
						}						


						if ($varTempUserName!="" && $varTempResult=="") {
							if ($varArrName=="") {
								$varArrName = $varTempUserName;
							} else {
								$varArrName = $varArrName . "~" . $varTempUserName;
							}
							if ($varArrResult=="") {
								$varArrResult = "Not Started";
							} else {
								$varArrResult = $varArrResult . "~" . "Not Started";
							}
						}
					}
				}
			} } }
		} } } } } } } }

		if ($varArrName=="") {
			$strMessage = "ELMS_NODATA";
		} else {
			$strMessage = $varArrName . "ELMS_SPL" . $varArrResult;
		}
		echo $strMessage;
	}
?>