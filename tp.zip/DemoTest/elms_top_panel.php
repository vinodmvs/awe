<table width="100%" cellspacing="0" cellpadding="0">
	<!--
	<tr height="5" bgcolor="#666666">
		<td colspan="3"></td>
	</tr>
	-->
	<tr height="5">
		<td colspan="3"></td>
	</tr>
	<tr>
		<td>
			<table width="100%" cellspacing="0" cellpadding="0" border="0">
				<tr>
					<td width="30%" align="left" valign="middle">
						<img src="images/logo.png?x=<?php echo uniqid((double)microtime()*1000000, 0); ?>" border="0" alt="" title="" />
					</td>
					<td align="center" valign="middle">
						<?php
							if (isset($_SESSION["Elms_TrialMsg"])) {
								echo $_SESSION["Elms_TrialMsg"];
							}
						?>
					</td>
					<td width="30%" align="right" valign="top">
						<font color="#000000"><span id="date_time" style="display:none;"></font></span>
						<table cellspacing="0" cellpadding="0">
							<tr height="40">
								<td></td>
								<?php
									$varMediaLinks = "";
									$tempQuery = "SELECT company_social_medialinks FROM elms_branding_details";
									$tResult = mysql_query($tempQuery) or die (mysql_error());
									$tRow = mysql_fetch_row($tResult);
									$varMediaLinks = $tRow[0];
									if ($varMediaLinks!="") {
										$arrTempSplMain = explode("ELMS_SPLMAIN", $varMediaLinks);
										for ($i=0; $i<count($arrTempSplMain); $i++) {
											$arrTempSplSub = explode("ELMS_SPL", $arrTempSplMain[$i]);
								?>
								<?php
											if ($arrTempSplSub[0]=="Y") {
												$YURL = $arrTempSplSub[1];
												$YURL = str_replace("http:\\", "", $YURL);
												$YURL = str_replace("https:\\", "", $YURL);
												$YURL = str_replace("HTTP:\\", "", $YURL);
												$YURL = str_replace("HTTPS:\\", "", $YURL);

												$YURL = str_replace("http://", "", $YURL);
												$YURL = str_replace("https://", "", $YURL);
												$YURL = str_replace("HTTP://", "", $YURL);
												$YURL = str_replace("HTTPS://", "", $YURL);
								?>
												<td width="45" align="right" valign="middle"><a href="http://<?php echo $YURL; ?>" target="_blank"><img src="images/youtube.png" alt="" title=""></a></td>
								<?php
											} else {
											if ($arrTempSplSub[0]=="T") {
												$TURL = $arrTempSplSub[1];
												$TURL = str_replace("http:\\", "", $TURL);
												$TURL = str_replace("https:\\", "", $TURL);
												$TURL = str_replace("HTTP:\\", "", $TURL);
												$TURL = str_replace("HTTPS:\\", "", $TURL);

												$TURL = str_replace("http://", "", $TURL);
												$TURL = str_replace("https://", "", $TURL);
												$TURL = str_replace("HTTP://", "", $TURL);
												$TURL = str_replace("HTTPS://", "", $TURL);
								?>
												<td width="45" align="right" valign="middle"><a href="http://<?php echo $TURL; ?>" target="_blank"><img src="images/mvs_twitter.png" alt="" title=""></a></td>
								<?php
											} else {
											if ($arrTempSplSub[0]=="F") {
												$FURL = $arrTempSplSub[1];
												$FURL = str_replace("http:\\", "", $FURL);
												$FURL = str_replace("https:\\", "", $FURL);
												$FURL = str_replace("HTTP:\\", "", $FURL);
												$FURL = str_replace("HTTPS:\\", "", $FURL);

												$FURL = str_replace("http://", "", $FURL);
												$FURL = str_replace("https://", "", $FURL);
												$FURL = str_replace("HTTP://", "", $FURL);
												$FURL = str_replace("HTTPS://", "", $FURL);
								?>
												<td width="45" align="right" valign="middle"><a href="http://<?php echo $FURL; ?>" target="_blank"><img src="images/mvs_facebook.png" alt="" title=""></a></td>
								<?php
											} else {
											if ($arrTempSplSub[0]=="L") {
												$LURL = $arrTempSplSub[1];
												$LURL = str_replace("http:\\", "", $LURL);
												$LURL = str_replace("https:\\", "", $LURL);
												$LURL = str_replace("HTTP:\\", "", $LURL);
												$LURL = str_replace("HTTPS:\\", "", $LURL);

												$LURL = str_replace("http://", "", $LURL);
												$LURL = str_replace("https://", "", $LURL);
												$LURL = str_replace("HTTP://", "", $LURL);
												$LURL = str_replace("HTTPS://", "", $LURL);
								?>
												<td width="45" align="right" valign="middle"><a href="http://<?php echo $LURL; ?>" target="_blank"><img src="images/mvs_linkedin.png" alt="" title=""></a></td>
								<?php
											} } } }
								?>
								<?php
										}
									}
								?>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</td>
	<tr>
	<tr height="1" bgcolor="#333333">
		<td></td>
	</tr>	
</table>
<script>
	date_time('date_time');
</script>