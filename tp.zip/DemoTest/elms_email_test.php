<?php
	require("class.phpmailer.php");
?>

<?php
	$strMessage = "";
	$varImageBasePath = "http://www.chironmeditourtraining.com/";
	$varLogoHTML = '<img src="' . $varImageBasePath . 'images/logo.png" />';
	$varTodayDate = date('d-m-Y');
	$varUserFname = "Ramachandran";
	$varUserLogin = "User Name";
	$varUserPass = "User Password";

	$varLoginDetailsHTML = "";
	$varLoginDetailsHTML .= '<table width="500" cellspacing="0" cellpadding="0" border="0">';
		$varLoginDetailsHTML .= '<tr>';
			$varLoginDetailsHTML .= '<td width="100%" align="left">';
				$varLoginDetailsHTML .= '<div id="divPrintArea" name="divPrintArea" style="border:1px solid #cccccc;">';
					$varLoginDetailsHTML .= '<table width="100%" cellspacing="1" cellpadding="2" bgcolor="#e4e4e4">';
						$varLoginDetailsHTML .= '<tr style="background:#04548f; height:35px; font-family:arial; color:#ffffff; font-size:12px; font-weight:normal; text-align:center; vertical-align:middle;">';
							$varLoginDetailsHTML .= '<td width="60%">';
								$varLoginDetailsHTML .= 'Login Id';
							$varLoginDetailsHTML .= '</td>';
							$varLoginDetailsHTML .= '<td width="40%">';
								$varLoginDetailsHTML .= 'Password';
							$varLoginDetailsHTML .= '</td>';
						$varLoginDetailsHTML .= '</tr>';
						$varLoginDetailsHTML .= '<tr style="background:#eaffea; height:25px; font-family:arial; color:#000000; font-size:11px; font-weight:normal; text-align:left; vertical-align:middle;">';
							$varLoginDetailsHTML .= '<td width="60%" align="left" valign="middle">';
								$varLoginDetailsHTML .= $varUserLogin;
							$varLoginDetailsHTML .= '</td>';
							$varLoginDetailsHTML .= '<td width="40%" align="left" valign="middle">';
								$varLoginDetailsHTML .= $varUserPass;
							$varLoginDetailsHTML .= '</td>';
						$varLoginDetailsHTML .= '</tr>';
					$varLoginDetailsHTML .= '</table>';
				$varLoginDetailsHTML .= '</div>';
			$varLoginDetailsHTML .= '</td>';
		$varLoginDetailsHTML .= '</tr>';
	$varLoginDetailsHTML .= '</table>';

	$varSubject = "E-mail Testing";
	$varMessage = <<<EOF
<html>
	<head></head>
	<body topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
		<center>
			<table width="100%" cellspacing="0" cellpadding="0" bordercolor="#004080" border="5">
				<tr>
					<td width="100%">
						<table width="100%" cellspacing="0" cellpadding="0">
							<tr>
								<td width="100%" align="left" valign="center">
									$varLogoHTML
								</td>
							</tr>
							<tr height="5" bgcolor="#ffcc00">
								<td></td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
							<tr>
								<td width="100%" align="center" valign="top">
									<table width="98%" cellspacing="0" cellpadding="0">
										<tr>
											<td width="100%" align="right" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Date: $varTodayDate</b>
												</font>
											</td>
										</tr>
										<tr height="5">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="center">
												<font face="arial" size="3" color="#3399ff">
													<b>Dear $varUserFname,</b>
												</font>
											</td>
										</tr>
										<tr height="5">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="center">
												<font face="arial" size="2" color="#000000">
													Thanking you for registering with us and your account has been activated. Below is your <b>Chiron Meditour Training</b> Login details.
												</font>
											</td>
										</tr>
										<tr height="15">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="top">
												$varLoginDetailsHTML
											</td>
										</tr>
										<tr height="15">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="top">
												<font face="arial" size="2" color="#000000">Chiron Meditour Training URL: </font><font face="arial" size="2" color="#0000ff"><a href="http://www.chironmeditourtraining.com">www.chironmeditourtraining.com</a></font>
											</td>
										</tr>										
										<tr height="25">
											<td></td>
										</tr>
										<tr>
											<td width="100%" align="left" valign="top">
												<font face="arial" size="2" color="#3399ff">Regards</font><br /><font face="arial" size="2" color="#000000">Chiron Meditour Training Team</font><br /><font face="arial" size="2" color="#0000ff"><a href="http://www.chironmeditour.com">www.chironmeditour.com</a></font>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr height="5">
								<td></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</center>
	</body>
</html>
EOF;
	$varEmailTo = "support@chironmeditourtraining.com";
	$varEmailFrom = "ram@mvssoftech.com";
	$varEmailFromName = "Administrator";
	$mail = new PHPMailer();
	$mail->From = $varEmailFrom;
	$mail->FromName = $varEmailFromName;
	$mail->AddAddress($varEmailTo, $varUserFname);
	/*
	$mail->AddCC($varEmailFrom, $varEmailFromName);
	$mail->AddCC('admin@chironmeditourtraining.com', 'Ramachandran');
	*/
	$mail->AddReplyTo($varEmailFrom, $varEmailFromName);
	$mail->IsHTML(true);
	$mail->Subject = $varSubject;
	$mail->Body = $varMessage;
	$mail->AltBody = "Here is your test E-mail.";
	
	if($varEmailFrom!="" && $mail->Send()) {
		$strMessage = "E-mail has been sent.";
	} else {
		$strMessage = "E-mail has not been sent.";
	}
	echo $strMessage;
?>