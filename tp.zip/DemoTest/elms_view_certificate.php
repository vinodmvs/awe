<?php
	require("elms_top_includes.php");
?>

<?php
	$varUserName = "";
	$varCourseName = "";
	$varCourseCD = "-";
	$varTempDate = "";
	$varRetURL = "elms_learner_course_report.php";
	
	if (!isset($_POST["txtUserName"])) {
		header("Location: index.php");
	} else {
		$varUserName = $_POST["txtUserName"];
		$varCourseName = $_POST["txtCourseName"];
		$varCourseCatName = $_POST["txtCourseCatName"];
		$varCourseSD = $_POST["txtStartedDate"];
		$varCourseCD = $_POST["txtCompletedDate"];
		$varRetURL = $_POST["txtReturnURL"];
	}
	
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<style>
			.clsDivCertificate {
				position: relative;
				width: 1157px;
				height: 818px;
				background: url(images/Certificate2_a1.jpg) no-repeat;
				border: 0px solid #cccccc;
				cursor: default;
			}
			.clsDivMessage {
				position: absolute;
				width: 77%;
				height: 300px;
				padding:0px 130px 0px 130px;
				left: 3px;
				top: 310px;
				font-family: Elegans Script SSi;
				font-size: 30px;
				font-weight: normal;
				text-align: left;
				border: 0px solid #000000;
				display: block;
				cursor: default;
			}			
		</style>
		<script language="javascript">
			function doConvertPDF() {
				document.frmPDF.action = "elms_view_certificate_print.php";
				document.frmPDF.submit();
			}
		</script>
	</head>
	<body>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td>
								<table width="100%" cellspacing="0" cellpadding="0">
									<tr>
										<td width="1%">
											&nbsp;
										</td>
										<td>
											<table width="100%" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">
														&nbsp;
													</td>
													<td align="left" valign="top">
														<table width="100%" cellspacing="0" cellpadding="0">
															<tr>
																<td width="100%" align="center" valign="top" id="temp">
																	<div id="divCertificate" name="divCertificate" class="clsDivCertificate">
																		<div id="divMessage" name="divMessage" class="clsDivMessage" style="line-height:150%;">
																			<p>
																				<b><u><?php echo $varUserName; ?></u></b>&nbsp;In recognition of having successfully completed the course on&nbsp;
																				<b><u><?php echo $varCourseName; ?></u></b>&nbsp;
																				under the category <b><u><?php echo $varCourseCatName; ?></u></b>
																				<div  style="line-height:75%; text-align:center;">
																					<?php
																						$varTempDateSD = "-";
																						if ($varCourseSD=="-") {
																							$varTempDateSD = $varCourseSD;
																							echo $varCourseSD;
																						} else {
																							$varTempDate = new DateTime($varCourseSD);
																							$varTempDateSD = $varTempDate->format("d-M-Y");
																						}																			
																					?>																			
																					from <font size="5"><u><b><?php echo $varTempDateSD; ?></b></u></font>
																					<?php
																						$varTempDateCD = "-";
																						if ($varCourseCD=="-") {
																							$varTempDateCD = $varCourseCD;
																							echo $varCourseCD;
																						} else {
																							$varTempDate = new DateTime($varCourseCD);
																							$varTempDateCD = $varTempDate->format("d-M-Y");
																							
																						}																			
																					?>																			
																					to <font size="5"><u><b><?php echo $varTempDateCD; ?></b></u></font>
																				</div>
																			</p>
																		</div>																	
																	</div>
																</td>
															</tr>
														</table>
													</td>
													<td width="1%">
														&nbsp;
													</td>
												</tr>
												<tr height="25">
													<td width="100%" align="center" colspan="3"></td>
												</tr>
												<tr>
													<td width="100%" align="center" colspan="3">
														<input type="button" value="Print / Download" class="clsActionButton" onclick="javascript:doConvertPDF();" />
														<input type="button" value="<< Back" class="clsActionButton" onclick="document.location.href='<?php echo $varRetURL; ?>';" />
														<form id="frmPDF" name="frmPDF" method="post" target="_blank">
															<input type="hidden" id="txtUserName" name="txtUserName" value="<?php echo $varUserName; ?>" />
															<input type="hidden" id="txtCourseName" name="txtCourseName" value="<?php echo $varCourseName; ?>" />
															<input type="hidden" id="txtCourseCatName" name="txtCourseCatName" value="<?php echo $varCourseCatName; ?>" />
															<input type="hidden" id="txtCourseSD" name="txtCourseSD" value="<?php echo $varTempDateSD; ?>" />
															<input type="hidden" id="txtCourseCD" name="txtCourseCD" value="<?php echo $varTempDateCD; ?>" />
														</form>
													</td>
												</tr>
											</table>
										</td>
										<td width="1%">
											&nbsp;
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>