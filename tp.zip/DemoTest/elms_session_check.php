<?php
	if (!isset($_SESSION["Elms_LoggedInId"]) || $_SESSION["Elms_LoggedInId"] == "" || $_SESSION["Elms_LoggedInId"] == null) {
		header("Location:index.php");
	} else {
		$tempQuery = "UPDATE elms_login_logout_details SET logout_dt='" . date('Y-m-d H:i:s') . "' WHERE track_id=" . $_SESSION["Elms_LoggedInTrackId"] . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
		$tempResult = mysql_query($tempQuery) or die (mysql_error());
	}
?>