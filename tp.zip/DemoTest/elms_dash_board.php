<?php
	require("elms_top_includes.php");
?>

<?php
	$varRole = "";
	$varGroup = "";
	$varHead = "";
	$varCoursesEnrolled = "";
	$varRegFDate = "";
	$varRegEDate = "";
	$varLoginFDate = "";
	$varLoginEDate = "";

	$varRole = "Manager";
	$tempQuery = "UPDATE elms_admin_user_report_filter SET user_role='" . $varRole . "',user_group='" . $varGroup . "',user_head='" . $varHead . "',user_course='" . $varCoursesEnrolled . "',user_reg_fdate='" . $varRegFDate . "',user_reg_edate='" . $varRegEDate . "',user_login_fdate='" . $varLoginFDate . "',user_login_edate='" . $varLoginEDate . "'";
	$tempResult = mysql_query($tempQuery);

	$varArrMembershipList = array();
	$varArrGList = "";
	$varArrUList = "";
	$intTempNum = 0;
	$intTempPer = 0;
	$intTotCount = 0;
	
	$tQuery = "SELECT * FROM elms_membership_details ORDER BY mem_name";
	$tResult = mysql_query($tQuery) or die (mysql_error());
	$varTempChkText = "";
	$varTempMemListVal = "";
	$varTempPrevId = 0;
	while ($tRow = mysql_fetch_array($tResult)) {
		if ($varTempChkText!=$tRow["mem_name"]) {
			if ($varTempMemListVal=="") {
				$varTempMemListVal = $tRow["mem_name"] . "~" . $tRow["mem_id"];
			} else {
				$varTempMemListVal = $varTempMemListVal . "SPLMAIN" . $tRow["mem_name"] . "~" . $tRow["mem_id"];
			}
		} else {
			$varTempMemListVal = str_replace($tRow["mem_name"] . "~" . $varTempPrevId, $tRow["mem_name"] . "~" . $varTempPrevId . "~" . $tRow["mem_id"], $varTempMemListVal);
		}
		$varTempChkText = $tRow["mem_name"];
		$varTempPrevId = $tRow["mem_id"];
	}
	
	if ($varTempMemListVal!="") {
		$varTempMemListValArray = explode("SPLMAIN", $varTempMemListVal);
		for ($k=0; $k<count($varTempMemListValArray); $k++) {
			$intTotCount = 0;
			$varTempSubSpl = explode("~", $varTempMemListValArray[$k]);
			$varMemName = "";
			$varMemId = "";
			if (count($varTempSubSpl)==2) {
				$varMemName = $varTempSubSpl[0];
				$varMemId = $varTempSubSpl[1];
				$tQuery = "SELECT user_id FROM elms_user_details WHERE user_mem_type=" . $varTempSubSpl[1] . " AND user_role<>'Admin'";
				$tCountResult = mysql_query($tQuery) or die (mysql_error());
				$intTempNum = dbNumRows($tCountResult);
				if ($intTempNum>0) {
					$intTotCount = $intTotCount + $intTempNum;
					array_push($varArrMembershipList, $varMemName . "~" . $intTotCount);
				}				
			} else {
				$varMemName = $varTempSubSpl[0];
				$varMemId = $varTempSubSpl[1] . "~" . $varTempSubSpl[2];
				$tQuery = "SELECT user_id FROM elms_user_details WHERE user_mem_type=" . $varTempSubSpl[1] . " AND user_role<>'Admin'";
				$tCountResult = mysql_query($tQuery) or die (mysql_error());
				$intTempNum = dbNumRows($tCountResult);
				if ($intTempNum>0) {
					$intTotCount = $intTotCount + $intTempNum;
				}
				$tQuery = "SELECT user_id FROM elms_user_details WHERE user_mem_type=" . $varTempSubSpl[2] . " AND user_role<>'Admin'";
				$tCountResult = mysql_query($tQuery) or die (mysql_error());
				$intTempNum = dbNumRows($tCountResult);
				if ($intTempNum>0) {
					$intTotCount = $intTotCount + $intTempNum;
				}				
				array_push($varArrMembershipList, $varMemName . "~" . $intTotCount);
			}		
		}
	}
	if (count($varArrMembershipList)>0) {
		for ($i=0; $i<count($varArrMembershipList); $i++) {
			$varArrTemp = explode("~", $varArrMembershipList[$i]);
			if ($varArrGList=="") {
				$varArrGList = $varArrTemp[0];
			} else {
				$varArrGList = $varArrGList . "~" . $varArrTemp[0];
			}
			if ($varArrUList=="") {
				$varArrUList = $varArrTemp[1];
			} else {
				$varArrUList = $varArrUList . "~" . $varArrTemp[1];
			}
		}
	}
?>

<!doctype html>
<html>
	<head>
		<?php
			require('elms_top_header.php');
		?>
		<style>
		</style>
		<script type="text/javascript" src="https://www.google.com/jsapi"></script>
		<script type="text/javascript">
			var arrG, arrU;
      		google.load("visualization", "1", {packages:["corechart"]});
      		google.setOnLoadCallback(drawChart);
      		function drawChart() {
      			if (document.getElementById('txtArrGData')!=null && document.getElementById('txtArrGData').value!="") {
					arrG = document.getElementById('txtArrGData').value.split("~");
					arrU = document.getElementById('txtArrUData').value.split("~");
					var data = new google.visualization.DataTable();
					data.addColumn('string', 'Task');
					data.addColumn('number', 'User Per Membership');
					data.addRows(arrG.length);
					for (i=0; i<arrG.length; i++) {
						data.setValue(i, 0, arrG[i]);
						data.setValue(i, 1, arrU[i]);
					}
					var options = {
						title: '',
						is3D: true,
						chartArea: {'width': '100%', 'height': '100%', 'left':0, 'top':0},
						pieHole: 1,
						legend: {maxLines: 1, position: 'right', textStyle: {color: '#000000', fontSize: 13}}
					};
					var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
					chart.draw(data, options);
				}
      		}
		</script>
	</head>
	<body>
		<center>
			<div id="divMainContainer" name="divMainContainer" class="clsDivMainContainer">
				<div id="divTopPanel" name="divTopPanel" class="clsDivTopPanel">
					<?php
						require('elms_top_panel.php');
					?>
				</div>
				<div id="divContentPanel" name="divContentPanel" class="clsDivContentPanel">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tr>
							<td align="center" valign="top">
								<?php
									showAdminWelcome();
								?>
							</td>
						</tr>
						<tr>
							<td align="center">
								<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
									<tr>
										<td width="1%">&nbsp;</td>
										<td align="center">
											<table width="100%" align="center" cellspacing="0" cellpadding="0">
												<tr>
													<td width="1%">&nbsp;</td>
													<td align="center" valign="top">
														<table width="100%" align="center" cellspacing="0" cellpadding="0" border="0">
															<tr>
																<td width="100%" align="left">
																	<div class="clsPageTopHeader" style="width:100%; display:inline-block;">
																		Dashboard
																	</div>
																</td>
															</tr>
															<tr height="10">
																<td width="100%" align="left">
																</td>
															</tr>															
															<?php
																if (count($varArrMembershipList)>0) {
															?>
																<tr>
																	<td width="70%" align="left" valign="top">
																		<table width="100%" align="center"  cellspacing="0" cellpadding="0" border="0">
																			<tr>
																				<td width="60%" align="left">
																					<font size="5">Users Enrolled Membership-Wise</font>
																				</td>
																				<td width="40%" align="left">
																				</td>																			
																			</tr>
																			<tr>
																				<td width="60%" align="center" valign="top">
																					<div id="piechart_3d" style="border:0px solid green; margin:0px 0px 0px 0px; padding:0px 0px 0px 0px; text-align:left; width:100%; height:500px; overflow:hidden;"></div>
																				</td>
																				<td width="40%" align="center" valign="top">
																					<div class="clsSingleBorder" style="width:100%;">
																						<table width="100%" cellspacing="1" cellpadding="2">
																							<tr class="clsTableRowHeadingText">
																								<td width="60%" align="left">
																									Membership Name
																								</td>
																								<td width="40%" align="left">
																									Users
																								</td>
																							</tr>
																							<?php
																								$varTotalUsers = 0;
																								$strColorFilled = "No";
																								for ($i=0; $i<count($varArrMembershipList); $i++) {
																									$varArrTemp = explode("~", $varArrMembershipList[$i]);
																							?>
																							<?php
																								if ($strColorFilled=="No") {
																									$strColorFilled = "Yes";

																							?>
																								<tr class="clsAlternateFColor">
																							<?php
																								} else {
																									$strColorFilled = "No";

																							?>
																								<tr class="clsAlternateSColor">
																							<?php
																								}
																							?>
																									<td width="80%">
																										<?php echo $varArrTemp[0]; ?>
																									</td>
																									<td width="20%" align="right">
																										<?php 
																											$varTotalUsers = $varTotalUsers + $varArrTemp[1];
																											echo $varArrTemp[1]; 
																										?>
																									</td>
																								</tr>
																							<?php
																								}
																							?>
																							<tr>
																								<td align="right" colspan="2">Total Number of Users: <b><?php echo $varTotalUsers; ?></b></td>
																							</tr>																				
																						</table>
																					</div>																				
																				</td>																				
																			</tr>
																		</table>
																	</td>
																</tr>
																<tr>
																	<td width="100%" align="center" valign="top">

																	</td>
																</tr>
																<tr height="10">
																</tr>																
																
															<?php
																}
															?>
															<input type="hidden" id="txtArrGData" name="txtArrGData" value="<?php echo $varArrGList; ?>" />
															<input type="hidden" id="txtArrUData" name="txtArrUData" value="<?php echo $varArrUList; ?>" />
														</table>
													</td>
													<td width="1%">&nbsp;</td>
												</tr>
											</table>
										</td>
										<td width="1%">&nbsp;</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr height="25">
							<td></td>
						</tr>
					</table>
				</div>
				<div id="divBottomPanel" name="divBottomPanel" class="clsDivBottomPanel">
					<?php
						require('elms_bottom_panel.php');
					?>
				</div>
				<?php
					require('elms_common_panel.php');
				?>
			</div>
		</center>
	</body>
</html>