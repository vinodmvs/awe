<?php
	require("elms_top_includes.php");
?>

<?php
	$strSQL = "SELECT total_time, session_time FROM `elms_course_scorm_track` WHERE `course_id` = " . $_SESSION["Elms_CourseId"]  . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
	$rstResult = dbQuery($strSQL);
	if (dbNumRows($rstResult)>0) {
		$rstRow = mysql_fetch_array($rstResult);
		if ($rstRow["session_time"]=="") {
			$intSessionTime = 0;
		} else {
			$intSessionTime = (int)$rstRow["session_time"];
			$intSessionTime++;
		}		
		
		if ($rstRow["total_time"]=="") {
			$intTotalTime = 0;
		} else {
			$intTotalTime = (int)$rstRow["total_time"];
			$intTotalTime++;
		}
		$strSQL = "UPDATE elms_course_scorm_track SET total_time='" . $intTotalTime . "',session_time='" . $intSessionTime . "' WHERE course_id=" . $_SESSION["Elms_CourseId"]  . " AND user_id=" . $_SESSION["Elms_LoggedInId"];
		$rstResult = dbQuery($strSQL);
	}
	echo "ELMS_SUCCESS";
?>