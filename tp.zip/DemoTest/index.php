<?php
	require("elms_config.php");
	$_SESSION["Elms_LoggedInId"] = "";
	$_SESSION["Elms_LoggedInEmail"] = "";
	$_SESSION["Elms_LoggedInUserName"] = "";
	$_SESSION["Elms_LoggedInUserType"] = "";
	$_SESSION["Elms_LoggedInIEUserType"] = "";
	$_SESSION["Elms_LoggedInTrackId"] = "";
	$_SESSION["Elms_LoggedInMUPer"] = "";
	$_SESSION["Elms_LoggedInMGPer"] = "";
	$_SESSION["Elms_LoggedInProfilePic"] = "";
	$_SESSION["Elms_ReplyEmail"] = "";
	$_SESSION["Elms_SiteURL"] = "";
	$_SESSION["Elms_ResMsg"] = "";
	$_SESSION["Elms_SuccessMsg"] = "";
	$_SESSION["Elms_ErrorMsg"] = "";
	$_SESSION["Elms_TrialMsg"] = "";
	$_SESSION["Elms_ThemeColor"] = "blue";
	$_SESSION["Elms_GeneralBgColor"] = "#49c0f0";
	$_SESSION["Elms_AlternateFColor"] = "#c0e7f9";
	$_SESSION["Elms_AlternateSColor"] = "#f2f2f2";
	
	$_SESSION["Elms_SCORMCourseStatus"] = "";
	$_SESSION["Elms_SCORMRawScore"] = 0;
	
	$_SESSION["Elms_CourseName"] = "";
	$_SESSION["Elms_CourseCatName"] = "";
	
	$_SESSION["Elms_CourseEditId"] = "";
	
	header("Location:elms_login.php");
?>