<?php
$username = filter_input(INPUT_POST,'username');
$password = filter_input(INPUT_POST,'password');
$email = filter_input(INPUT_POST,'email');


if(!empty($username )){
	if(!empty($password )){
		$host = "localhost";
		$dbusername = "root";
		$dbpassword ="";
		$dbname="test";
		
		$connection = new mysqli($host, $dbusername, $dbpassword, $dbname);
		
			if(mysqli_connect_error()){
				die('Connect Error('.mysqli_connect_errorno().')'
				.mysqli_connect_error());
			}
			else{
				$sql = "INSERT INTO users(username, email, password) values('$username','$email', '$password')";
				if($connection->query($sql)){
					echo"new record added successfully";
					include('page1.html');
				}else{
					echo "Error:".$sql."<br>".$connection->error;
				}
				$connection->close();
				
			}
	}
		
	else{
		echo "password should not be empty";
		die();
		}
	}
else{
	echo"username should not be empty";
	die();
}
?>
